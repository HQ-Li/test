# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Properties.ice'

import Ice, IcePy, __builtin__
import Ice_BuiltinSequences_ice

# Included module Ice
_M_Ice = Ice.openModule('Ice')

# Start of module Ice
__name__ = 'Ice'

if not _M_Ice.__dict__.has_key('_t_PropertyDict'):
    _M_Ice._t_PropertyDict = IcePy.defineDictionary('::Ice::PropertyDict', (), IcePy._t_string, IcePy._t_string)

if not _M_Ice.__dict__.has_key('Properties'):
    _M_Ice.Properties = Ice.createTempClass()
    class Properties(Ice.LocalObject):
        def __init__(self):
            if __builtin__.type(self) == _M_Ice.Properties:
                raise RuntimeError('Ice.Properties is an abstract class')

        #
        # Operation signatures.
        #
        # def getProperty(self, key):
        # def getPropertyWithDefault(self, key, value):
        # def getPropertyAsInt(self, key):
        # def getPropertyAsIntWithDefault(self, key, value):
        # def getPropertiesForPrefix(self, prefix):
        # def setProperty(self, key, value):
        # def getCommandLineOptions(self):
        # def parseCommandLineOptions(self, prefix, options):
        # def parseIceCommandLineOptions(self, options):
        # def load(self, file):
        # def clone(self):

        def __str__(self):
            return IcePy.stringify(self, _M_Ice._t_Properties)

        __repr__ = __str__

    _M_Ice._t_Properties = IcePy.defineClass('::Ice::Properties', Properties, (), True, None, (), ())
    Properties.ice_type = _M_Ice._t_Properties

    _M_Ice.Properties = Properties
    del Properties

# End of module Ice
