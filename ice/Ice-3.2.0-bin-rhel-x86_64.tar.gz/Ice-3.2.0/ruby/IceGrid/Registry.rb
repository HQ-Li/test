# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Registry.ice'

require 'Ice'
require 'IceGrid/Exception.rb'
require 'IceGrid/Session.rb'
require 'IceGrid/Admin.rb'

module IceGrid

    if not defined?(::IceGrid::Registry_mixin)
        module Registry_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::Registry']
            end

            def ice_id(current=nil)
                '::IceGrid::Registry'
            end

            #
            # Operation signatures.
            #
            # def createSession(userId, password, current=nil)
            # def createAdminSession(userId, password, current=nil)
            # def createSessionFromSecureConnection(current=nil)
            # def createAdminSessionFromSecureConnection(current=nil)
            # def getSessionTimeout(current=nil)

            def inspect
                ::Ice::__stringify(self, T_Registry)
            end
        end
        module RegistryPrx_mixin

            def createSession(userId, password, _ctx=nil)
                Registry_mixin::OP_createSession.invoke(self, [userId, password], _ctx)
            end

            def createAdminSession(userId, password, _ctx=nil)
                Registry_mixin::OP_createAdminSession.invoke(self, [userId, password], _ctx)
            end

            def createSessionFromSecureConnection(_ctx=nil)
                Registry_mixin::OP_createSessionFromSecureConnection.invoke(self, [], _ctx)
            end

            def createAdminSessionFromSecureConnection(_ctx=nil)
                Registry_mixin::OP_createAdminSessionFromSecureConnection.invoke(self, [], _ctx)
            end

            def getSessionTimeout(_ctx=nil)
                Registry_mixin::OP_getSessionTimeout.invoke(self, [], _ctx)
            end
        end
        class RegistryPrx < ::Ice::ObjectPrx
            include RegistryPrx_mixin

            def RegistryPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::Registry', facetOrCtx, _ctx)
            end

            def RegistryPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_Registry)
            T_Registry = ::Ice::__declareClass('::IceGrid::Registry')
            T_RegistryPrx = ::Ice::__declareProxy('::IceGrid::Registry')
        end

        T_Registry.defineClass(nil, true, nil, [], [])
        Registry_mixin::ICE_TYPE = T_Registry

        T_RegistryPrx.defineProxy(RegistryPrx, T_Registry)
        RegistryPrx::ICE_TYPE = T_RegistryPrx

        Registry_mixin::OP_createSession = ::Ice::__defineOperation('createSession', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_string], [], ::IceGrid::T_SessionPrx, [::IceGrid::T_PermissionDeniedException])
        Registry_mixin::OP_createAdminSession = ::Ice::__defineOperation('createAdminSession', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_string], [], ::IceGrid::T_AdminSessionPrx, [::IceGrid::T_PermissionDeniedException])
        Registry_mixin::OP_createSessionFromSecureConnection = ::Ice::__defineOperation('createSessionFromSecureConnection', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], ::IceGrid::T_SessionPrx, [::IceGrid::T_PermissionDeniedException])
        Registry_mixin::OP_createAdminSessionFromSecureConnection = ::Ice::__defineOperation('createAdminSessionFromSecureConnection', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], ::IceGrid::T_AdminSessionPrx, [::IceGrid::T_PermissionDeniedException])
        Registry_mixin::OP_getSessionTimeout = ::Ice::__defineOperation('getSessionTimeout', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_int, [])
    end
end
