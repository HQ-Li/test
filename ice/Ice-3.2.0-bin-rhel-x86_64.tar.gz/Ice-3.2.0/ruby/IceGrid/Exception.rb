# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Exception.ice'

require 'Ice'
require 'Ice/Identity.rb'
require 'Ice/BuiltinSequences.rb'

module IceGrid

    if not defined?(::IceGrid::ApplicationNotExistException)
        class ApplicationNotExistException < Ice::UserException
            def initialize(name='')
                @name = name
            end

            def to_s
                'IceGrid::ApplicationNotExistException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name
        end

        T_ApplicationNotExistException = ::Ice::__defineException('::IceGrid::ApplicationNotExistException', ApplicationNotExistException, nil, [["name", ::Ice::T_string]])
        ApplicationNotExistException::ICE_TYPE = T_ApplicationNotExistException
    end

    if not defined?(::IceGrid::ServerNotExistException)
        class ServerNotExistException < Ice::UserException
            def initialize(id='')
                @id = id
            end

            def to_s
                'IceGrid::ServerNotExistException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id
        end

        T_ServerNotExistException = ::Ice::__defineException('::IceGrid::ServerNotExistException', ServerNotExistException, nil, [["id", ::Ice::T_string]])
        ServerNotExistException::ICE_TYPE = T_ServerNotExistException
    end

    if not defined?(::IceGrid::ServerStartException)
        class ServerStartException < Ice::UserException
            def initialize(id='', reason='')
                @id = id
                @reason = reason
            end

            def to_s
                'IceGrid::ServerStartException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id, :reason
        end

        T_ServerStartException = ::Ice::__defineException('::IceGrid::ServerStartException', ServerStartException, nil, [
            ["id", ::Ice::T_string],
            ["reason", ::Ice::T_string]
        ])
        ServerStartException::ICE_TYPE = T_ServerStartException
    end

    if not defined?(::IceGrid::ServerStopException)
        class ServerStopException < Ice::UserException
            def initialize(id='', reason='')
                @id = id
                @reason = reason
            end

            def to_s
                'IceGrid::ServerStopException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id, :reason
        end

        T_ServerStopException = ::Ice::__defineException('::IceGrid::ServerStopException', ServerStopException, nil, [
            ["id", ::Ice::T_string],
            ["reason", ::Ice::T_string]
        ])
        ServerStopException::ICE_TYPE = T_ServerStopException
    end

    if not defined?(::IceGrid::AdapterNotExistException)
        class AdapterNotExistException < Ice::UserException
            def initialize(id='')
                @id = id
            end

            def to_s
                'IceGrid::AdapterNotExistException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id
        end

        T_AdapterNotExistException = ::Ice::__defineException('::IceGrid::AdapterNotExistException', AdapterNotExistException, nil, [["id", ::Ice::T_string]])
        AdapterNotExistException::ICE_TYPE = T_AdapterNotExistException
    end

    if not defined?(::IceGrid::ObjectExistsException)
        class ObjectExistsException < Ice::UserException
            def initialize(id=::Ice::Identity.new)
                @id = id
            end

            def to_s
                'IceGrid::ObjectExistsException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id
        end

        T_ObjectExistsException = ::Ice::__defineException('::IceGrid::ObjectExistsException', ObjectExistsException, nil, [["id", ::Ice::T_Identity]])
        ObjectExistsException::ICE_TYPE = T_ObjectExistsException
    end

    if not defined?(::IceGrid::ObjectNotRegisteredException)
        class ObjectNotRegisteredException < Ice::UserException
            def initialize(id=::Ice::Identity.new)
                @id = id
            end

            def to_s
                'IceGrid::ObjectNotRegisteredException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id
        end

        T_ObjectNotRegisteredException = ::Ice::__defineException('::IceGrid::ObjectNotRegisteredException', ObjectNotRegisteredException, nil, [["id", ::Ice::T_Identity]])
        ObjectNotRegisteredException::ICE_TYPE = T_ObjectNotRegisteredException
    end

    if not defined?(::IceGrid::NodeNotExistException)
        class NodeNotExistException < Ice::UserException
            def initialize(name='')
                @name = name
            end

            def to_s
                'IceGrid::NodeNotExistException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name
        end

        T_NodeNotExistException = ::Ice::__defineException('::IceGrid::NodeNotExistException', NodeNotExistException, nil, [["name", ::Ice::T_string]])
        NodeNotExistException::ICE_TYPE = T_NodeNotExistException
    end

    if not defined?(::IceGrid::RegistryNotExistException)
        class RegistryNotExistException < Ice::UserException
            def initialize(name='')
                @name = name
            end

            def to_s
                'IceGrid::RegistryNotExistException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name
        end

        T_RegistryNotExistException = ::Ice::__defineException('::IceGrid::RegistryNotExistException', RegistryNotExistException, nil, [["name", ::Ice::T_string]])
        RegistryNotExistException::ICE_TYPE = T_RegistryNotExistException
    end

    if not defined?(::IceGrid::DeploymentException)
        class DeploymentException < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'IceGrid::DeploymentException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_DeploymentException = ::Ice::__defineException('::IceGrid::DeploymentException', DeploymentException, nil, [["reason", ::Ice::T_string]])
        DeploymentException::ICE_TYPE = T_DeploymentException
    end

    if not defined?(::IceGrid::NodeUnreachableException)
        class NodeUnreachableException < Ice::UserException
            def initialize(name='', reason='')
                @name = name
                @reason = reason
            end

            def to_s
                'IceGrid::NodeUnreachableException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name, :reason
        end

        T_NodeUnreachableException = ::Ice::__defineException('::IceGrid::NodeUnreachableException', NodeUnreachableException, nil, [
            ["name", ::Ice::T_string],
            ["reason", ::Ice::T_string]
        ])
        NodeUnreachableException::ICE_TYPE = T_NodeUnreachableException
    end

    if not defined?(::IceGrid::RegistryUnreachableException)
        class RegistryUnreachableException < Ice::UserException
            def initialize(name='', reason='')
                @name = name
                @reason = reason
            end

            def to_s
                'IceGrid::RegistryUnreachableException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name, :reason
        end

        T_RegistryUnreachableException = ::Ice::__defineException('::IceGrid::RegistryUnreachableException', RegistryUnreachableException, nil, [
            ["name", ::Ice::T_string],
            ["reason", ::Ice::T_string]
        ])
        RegistryUnreachableException::ICE_TYPE = T_RegistryUnreachableException
    end

    if not defined?(::IceGrid::BadSignalException)
        class BadSignalException < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'IceGrid::BadSignalException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_BadSignalException = ::Ice::__defineException('::IceGrid::BadSignalException', BadSignalException, nil, [["reason", ::Ice::T_string]])
        BadSignalException::ICE_TYPE = T_BadSignalException
    end

    if not defined?(::IceGrid::PatchException)
        class PatchException < Ice::UserException
            def initialize(reasons=nil)
                @reasons = reasons
            end

            def to_s
                'IceGrid::PatchException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reasons
        end

        T_PatchException = ::Ice::__defineException('::IceGrid::PatchException', PatchException, nil, [["reasons", ::Ice::T_StringSeq]])
        PatchException::ICE_TYPE = T_PatchException
    end

    if not defined?(::IceGrid::AccessDeniedException)
        class AccessDeniedException < Ice::UserException
            def initialize(lockUserId='')
                @lockUserId = lockUserId
            end

            def to_s
                'IceGrid::AccessDeniedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :lockUserId
        end

        T_AccessDeniedException = ::Ice::__defineException('::IceGrid::AccessDeniedException', AccessDeniedException, nil, [["lockUserId", ::Ice::T_string]])
        AccessDeniedException::ICE_TYPE = T_AccessDeniedException
    end

    if not defined?(::IceGrid::AllocationException)
        class AllocationException < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'IceGrid::AllocationException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_AllocationException = ::Ice::__defineException('::IceGrid::AllocationException', AllocationException, nil, [["reason", ::Ice::T_string]])
        AllocationException::ICE_TYPE = T_AllocationException
    end

    if not defined?(::IceGrid::AllocationTimeoutException)
        class AllocationTimeoutException < ::IceGrid::AllocationException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'IceGrid::AllocationTimeoutException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_AllocationTimeoutException = ::Ice::__defineException('::IceGrid::AllocationTimeoutException', AllocationTimeoutException, ::IceGrid::T_AllocationException, [])
        AllocationTimeoutException::ICE_TYPE = T_AllocationTimeoutException
    end

    if not defined?(::IceGrid::PermissionDeniedException)
        class PermissionDeniedException < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'IceGrid::PermissionDeniedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_PermissionDeniedException = ::Ice::__defineException('::IceGrid::PermissionDeniedException', PermissionDeniedException, nil, [["reason", ::Ice::T_string]])
        PermissionDeniedException::ICE_TYPE = T_PermissionDeniedException
    end

    if not defined?(::IceGrid::ObserverAlreadyRegisteredException)
        class ObserverAlreadyRegisteredException < Ice::UserException
            def initialize(id=::Ice::Identity.new)
                @id = id
            end

            def to_s
                'IceGrid::ObserverAlreadyRegisteredException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id
        end

        T_ObserverAlreadyRegisteredException = ::Ice::__defineException('::IceGrid::ObserverAlreadyRegisteredException', ObserverAlreadyRegisteredException, nil, [["id", ::Ice::T_Identity]])
        ObserverAlreadyRegisteredException::ICE_TYPE = T_ObserverAlreadyRegisteredException
    end

    if not defined?(::IceGrid::FileNotAvailableException)
        class FileNotAvailableException < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'IceGrid::FileNotAvailableException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_FileNotAvailableException = ::Ice::__defineException('::IceGrid::FileNotAvailableException', FileNotAvailableException, nil, [["reason", ::Ice::T_string]])
        FileNotAvailableException::ICE_TYPE = T_FileNotAvailableException
    end
end
