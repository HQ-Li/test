# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Query.ice'

require 'Ice'
require 'Ice/Identity.rb'
require 'Ice/BuiltinSequences.rb'
require 'IceGrid/Exception.rb'

module IceGrid

    if not defined?(::IceGrid::LoadSample)
        class LoadSample
            include Comparable

            def initialize(val)
                fail("invalid value #{val} for LoadSample") unless(val >= 0 and val < 3)
                @val = val
            end

            def LoadSample.from_int(val)
                raise IndexError, "#{val} is out of range 0..2" if(val < 0 || val > 2)
                @@_values[val]
            end

            def to_s
                @@_names[@val]
            end

            def to_i
                @val
            end

            def <=>(other)
                other.is_a?(LoadSample) or raise ArgumentError, "value must be a LoadSample"
                @val <=> other.to_i
            end

            def hash
                @val.hash
            end

            def inspect
                @@_names[@val] + "(#{@val})"
            end

            def LoadSample.each(&block)
                @@_values.each(&block)
            end

            @@_names = ['LoadSample1', 'LoadSample5', 'LoadSample15']
            @@_values = [LoadSample.new(0), LoadSample.new(1), LoadSample.new(2)]

            LoadSample1 = @@_values[0]
            LoadSample5 = @@_values[1]
            LoadSample15 = @@_values[2]

            private_class_method :new
        end

        T_LoadSample = ::Ice::__defineEnum('::IceGrid::LoadSample', LoadSample, [LoadSample::LoadSample1, LoadSample::LoadSample5, LoadSample::LoadSample15])
    end

    if not defined?(::IceGrid::Query_mixin)
        module Query_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::Query']
            end

            def ice_id(current=nil)
                '::IceGrid::Query'
            end

            #
            # Operation signatures.
            #
            # def findObjectById(id, current=nil)
            # def findObjectByType(type, current=nil)
            # def findObjectByTypeOnLeastLoadedNode(type, sample, current=nil)
            # def findAllObjectsByType(type, current=nil)
            # def findAllReplicas(proxy, current=nil)

            def inspect
                ::Ice::__stringify(self, T_Query)
            end
        end
        module QueryPrx_mixin

            def findObjectById(id, _ctx=nil)
                Query_mixin::OP_findObjectById.invoke(self, [id], _ctx)
            end

            def findObjectById_async(_cb, id, _ctx=nil)
                Query_mixin::OP_findObjectById.invokeAsync(self, _cb, [id, ], _ctx)
            end

            def findObjectByType(type, _ctx=nil)
                Query_mixin::OP_findObjectByType.invoke(self, [type], _ctx)
            end

            def findObjectByType_async(_cb, type, _ctx=nil)
                Query_mixin::OP_findObjectByType.invokeAsync(self, _cb, [type, ], _ctx)
            end

            def findObjectByTypeOnLeastLoadedNode(type, sample, _ctx=nil)
                Query_mixin::OP_findObjectByTypeOnLeastLoadedNode.invoke(self, [type, sample], _ctx)
            end

            def findObjectByTypeOnLeastLoadedNode_async(_cb, type, sample, _ctx=nil)
                Query_mixin::OP_findObjectByTypeOnLeastLoadedNode.invokeAsync(self, _cb, [type, sample], _ctx)
            end

            def findAllObjectsByType(type, _ctx=nil)
                Query_mixin::OP_findAllObjectsByType.invoke(self, [type], _ctx)
            end

            def findAllObjectsByType_async(_cb, type, _ctx=nil)
                Query_mixin::OP_findAllObjectsByType.invokeAsync(self, _cb, [type, ], _ctx)
            end

            def findAllReplicas(proxy, _ctx=nil)
                Query_mixin::OP_findAllReplicas.invoke(self, [proxy], _ctx)
            end

            def findAllReplicas_async(_cb, proxy, _ctx=nil)
                Query_mixin::OP_findAllReplicas.invokeAsync(self, _cb, [proxy, ], _ctx)
            end
        end
        class QueryPrx < ::Ice::ObjectPrx
            include QueryPrx_mixin

            def QueryPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::Query', facetOrCtx, _ctx)
            end

            def QueryPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_Query)
            T_Query = ::Ice::__declareClass('::IceGrid::Query')
            T_QueryPrx = ::Ice::__declareProxy('::IceGrid::Query')
        end

        T_Query.defineClass(nil, true, nil, [], [])
        Query_mixin::ICE_TYPE = T_Query

        T_QueryPrx.defineProxy(QueryPrx, T_Query)
        QueryPrx::ICE_TYPE = T_QueryPrx

        Query_mixin::OP_findObjectById = ::Ice::__defineOperation('findObjectById', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_Identity], [], ::Ice::T_ObjectPrx, [])
        Query_mixin::OP_findObjectByType = ::Ice::__defineOperation('findObjectByType', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::Ice::T_ObjectPrx, [])
        Query_mixin::OP_findObjectByTypeOnLeastLoadedNode = ::Ice::__defineOperation('findObjectByTypeOnLeastLoadedNode', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string, ::IceGrid::T_LoadSample], [], ::Ice::T_ObjectPrx, [])
        Query_mixin::OP_findAllObjectsByType = ::Ice::__defineOperation('findAllObjectsByType', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::Ice::T_ObjectProxySeq, [])
        Query_mixin::OP_findAllReplicas = ::Ice::__defineOperation('findAllReplicas', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_ObjectPrx], [], ::Ice::T_ObjectProxySeq, [])
    end
end
