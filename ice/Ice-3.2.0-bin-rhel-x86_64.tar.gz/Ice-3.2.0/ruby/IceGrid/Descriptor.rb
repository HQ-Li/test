# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Descriptor.ice'

require 'Ice'
require 'Ice/Identity.rb'
require 'Ice/BuiltinSequences.rb'

module IceGrid

    if not defined?(::IceGrid::T_StringStringDict)
        T_StringStringDict = ::Ice::__defineDictionary('::IceGrid::StringStringDict', ::Ice::T_string, ::Ice::T_string)
    end

    if not defined?(::IceGrid::PropertyDescriptor)
        class PropertyDescriptor
            def initialize(name='', value='')
                @name = name
                @value = value
            end

            def hash
                _h = 0
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @value.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @name != other.name or
                    @value != other.value
                true
            end

            def inspect
                ::Ice::__stringify(self, T_PropertyDescriptor)
            end

            attr_accessor :name, :value
        end

        T_PropertyDescriptor = ::Ice::__defineStruct('::IceGrid::PropertyDescriptor', PropertyDescriptor, [
            ["name", ::Ice::T_string],
            ["value", ::Ice::T_string]
        ])
    end

    if not defined?(::IceGrid::T_PropertyDescriptorSeq)
        T_PropertyDescriptorSeq = ::Ice::__defineSequence('::IceGrid::PropertyDescriptorSeq', ::IceGrid::T_PropertyDescriptor)
    end

    if not defined?(::IceGrid::PropertySetDescriptor)
        class PropertySetDescriptor
            def initialize(references=nil, properties=nil)
                @references = references
                @properties = properties
            end

            def hash
                _h = 0
                _h = 5 * _h + @references.hash
                _h = 5 * _h + @properties.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @references != other.references or
                    @properties != other.properties
                true
            end

            def inspect
                ::Ice::__stringify(self, T_PropertySetDescriptor)
            end

            attr_accessor :references, :properties
        end

        T_PropertySetDescriptor = ::Ice::__defineStruct('::IceGrid::PropertySetDescriptor', PropertySetDescriptor, [
            ["references", ::Ice::T_StringSeq],
            ["properties", ::IceGrid::T_PropertyDescriptorSeq]
        ])
    end

    if not defined?(::IceGrid::T_PropertySetDescriptorDict)
        T_PropertySetDescriptorDict = ::Ice::__defineDictionary('::IceGrid::PropertySetDescriptorDict', ::Ice::T_string, ::IceGrid::T_PropertySetDescriptor)
    end

    if not defined?(::IceGrid::ObjectDescriptor)
        class ObjectDescriptor
            def initialize(id=::Ice::Identity.new, type='')
                @id = id
                @type = type
            end

            def hash
                _h = 0
                _h = 5 * _h + @id.hash
                _h = 5 * _h + @type.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @id != other.id or
                    @type != other.type
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ObjectDescriptor)
            end

            attr_accessor :id, :type
        end

        T_ObjectDescriptor = ::Ice::__defineStruct('::IceGrid::ObjectDescriptor', ObjectDescriptor, [
            ["id", ::Ice::T_Identity],
            ["type", ::Ice::T_string]
        ])
    end

    if not defined?(::IceGrid::T_ObjectDescriptorSeq)
        T_ObjectDescriptorSeq = ::Ice::__defineSequence('::IceGrid::ObjectDescriptorSeq', ::IceGrid::T_ObjectDescriptor)
    end

    if not defined?(::IceGrid::AdapterDescriptor)
        class AdapterDescriptor
            def initialize(name='', description='', id='', replicaGroupId='', priority='', registerProcess=false, serverLifetime=false, objects=nil, allocatables=nil)
                @name = name
                @description = description
                @id = id
                @replicaGroupId = replicaGroupId
                @priority = priority
                @registerProcess = registerProcess
                @serverLifetime = serverLifetime
                @objects = objects
                @allocatables = allocatables
            end

            def hash
                _h = 0
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @description.hash
                _h = 5 * _h + @id.hash
                _h = 5 * _h + @replicaGroupId.hash
                _h = 5 * _h + @priority.hash
                _h = 5 * _h + @registerProcess.hash
                _h = 5 * _h + @serverLifetime.hash
                _h = 5 * _h + @objects.hash
                _h = 5 * _h + @allocatables.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @name != other.name or
                    @description != other.description or
                    @id != other.id or
                    @replicaGroupId != other.replicaGroupId or
                    @priority != other.priority or
                    @registerProcess != other.registerProcess or
                    @serverLifetime != other.serverLifetime or
                    @objects != other.objects or
                    @allocatables != other.allocatables
                true
            end

            def inspect
                ::Ice::__stringify(self, T_AdapterDescriptor)
            end

            attr_accessor :name, :description, :id, :replicaGroupId, :priority, :registerProcess, :serverLifetime, :objects, :allocatables
        end

        T_AdapterDescriptor = ::Ice::__defineStruct('::IceGrid::AdapterDescriptor', AdapterDescriptor, [
            ["name", ::Ice::T_string],
            ["description", ::Ice::T_string],
            ["id", ::Ice::T_string],
            ["replicaGroupId", ::Ice::T_string],
            ["priority", ::Ice::T_string],
            ["registerProcess", ::Ice::T_bool],
            ["serverLifetime", ::Ice::T_bool],
            ["objects", ::IceGrid::T_ObjectDescriptorSeq],
            ["allocatables", ::IceGrid::T_ObjectDescriptorSeq]
        ])
    end

    if not defined?(::IceGrid::T_AdapterDescriptorSeq)
        T_AdapterDescriptorSeq = ::Ice::__defineSequence('::IceGrid::AdapterDescriptorSeq', ::IceGrid::T_AdapterDescriptor)
    end

    if not defined?(::IceGrid::DbEnvDescriptor)
        class DbEnvDescriptor
            def initialize(name='', description='', dbHome='', properties=nil)
                @name = name
                @description = description
                @dbHome = dbHome
                @properties = properties
            end

            def hash
                _h = 0
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @description.hash
                _h = 5 * _h + @dbHome.hash
                _h = 5 * _h + @properties.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @name != other.name or
                    @description != other.description or
                    @dbHome != other.dbHome or
                    @properties != other.properties
                true
            end

            def inspect
                ::Ice::__stringify(self, T_DbEnvDescriptor)
            end

            attr_accessor :name, :description, :dbHome, :properties
        end

        T_DbEnvDescriptor = ::Ice::__defineStruct('::IceGrid::DbEnvDescriptor', DbEnvDescriptor, [
            ["name", ::Ice::T_string],
            ["description", ::Ice::T_string],
            ["dbHome", ::Ice::T_string],
            ["properties", ::IceGrid::T_PropertyDescriptorSeq]
        ])
    end

    if not defined?(::IceGrid::T_DbEnvDescriptorSeq)
        T_DbEnvDescriptorSeq = ::Ice::__defineSequence('::IceGrid::DbEnvDescriptorSeq', ::IceGrid::T_DbEnvDescriptor)
    end

    if not defined?(::IceGrid::CommunicatorDescriptor_mixin)
        module CommunicatorDescriptor_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::CommunicatorDescriptor']
            end

            def ice_id(current=nil)
                '::IceGrid::CommunicatorDescriptor'
            end

            def inspect
                ::Ice::__stringify(self, T_CommunicatorDescriptor)
            end

            attr_accessor :adapters, :propertySet, :dbEnvs, :logs, :description
        end
        class CommunicatorDescriptor
            include CommunicatorDescriptor_mixin

            def initialize(adapters=nil, propertySet=::IceGrid::PropertySetDescriptor.new, dbEnvs=nil, logs=nil, description='')
                @adapters = adapters
                @propertySet = propertySet
                @dbEnvs = dbEnvs
                @logs = logs
                @description = description
            end
        end
        module CommunicatorDescriptorPrx_mixin
        end
        class CommunicatorDescriptorPrx < ::Ice::ObjectPrx
            include CommunicatorDescriptorPrx_mixin

            def CommunicatorDescriptorPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::CommunicatorDescriptor', facetOrCtx, _ctx)
            end

            def CommunicatorDescriptorPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_CommunicatorDescriptor)
            T_CommunicatorDescriptor = ::Ice::__declareClass('::IceGrid::CommunicatorDescriptor')
            T_CommunicatorDescriptorPrx = ::Ice::__declareProxy('::IceGrid::CommunicatorDescriptor')
        end

        T_CommunicatorDescriptor.defineClass(CommunicatorDescriptor, false, nil, [], [
            ['adapters', ::IceGrid::T_AdapterDescriptorSeq],
            ['propertySet', ::IceGrid::T_PropertySetDescriptor],
            ['dbEnvs', ::IceGrid::T_DbEnvDescriptorSeq],
            ['logs', ::Ice::T_StringSeq],
            ['description', ::Ice::T_string]
        ])
        CommunicatorDescriptor_mixin::ICE_TYPE = T_CommunicatorDescriptor

        T_CommunicatorDescriptorPrx.defineProxy(CommunicatorDescriptorPrx, T_CommunicatorDescriptor)
        CommunicatorDescriptorPrx::ICE_TYPE = T_CommunicatorDescriptorPrx
    end

    if not defined?(::IceGrid::DistributionDescriptor)
        class DistributionDescriptor
            def initialize(icepatch='', directories=nil)
                @icepatch = icepatch
                @directories = directories
            end

            def hash
                _h = 0
                _h = 5 * _h + @icepatch.hash
                _h = 5 * _h + @directories.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @icepatch != other.icepatch or
                    @directories != other.directories
                true
            end

            def inspect
                ::Ice::__stringify(self, T_DistributionDescriptor)
            end

            attr_accessor :icepatch, :directories
        end

        T_DistributionDescriptor = ::Ice::__defineStruct('::IceGrid::DistributionDescriptor', DistributionDescriptor, [
            ["icepatch", ::Ice::T_string],
            ["directories", ::Ice::T_StringSeq]
        ])
    end

    if not defined?(::IceGrid::ServerDescriptor_mixin)
        module ServerDescriptor_mixin
            include ::IceGrid::CommunicatorDescriptor_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::CommunicatorDescriptor', '::IceGrid::ServerDescriptor']
            end

            def ice_id(current=nil)
                '::IceGrid::ServerDescriptor'
            end

            def inspect
                ::Ice::__stringify(self, T_ServerDescriptor)
            end

            attr_accessor :id, :exe, :pwd, :options, :envs, :activation, :activationTimeout, :deactivationTimeout, :applicationDistrib, :distrib, :allocatable, :user
        end
        class ServerDescriptor < ::IceGrid::CommunicatorDescriptor
            include ServerDescriptor_mixin

            def initialize(adapters=nil, propertySet=::IceGrid::PropertySetDescriptor.new, dbEnvs=nil, logs=nil, description='', id='', exe='', pwd='', options=nil, envs=nil, activation='', activationTimeout='', deactivationTimeout='', applicationDistrib=false, distrib=::IceGrid::DistributionDescriptor.new, allocatable=false, user='')
                super(adapters, propertySet, dbEnvs, logs, description)
                @id = id
                @exe = exe
                @pwd = pwd
                @options = options
                @envs = envs
                @activation = activation
                @activationTimeout = activationTimeout
                @deactivationTimeout = deactivationTimeout
                @applicationDistrib = applicationDistrib
                @distrib = distrib
                @allocatable = allocatable
                @user = user
            end
        end
        module ServerDescriptorPrx_mixin
            include ::IceGrid::CommunicatorDescriptorPrx_mixin
        end
        class ServerDescriptorPrx < ::Ice::ObjectPrx
            include ServerDescriptorPrx_mixin

            def ServerDescriptorPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::ServerDescriptor', facetOrCtx, _ctx)
            end

            def ServerDescriptorPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_ServerDescriptor)
            T_ServerDescriptor = ::Ice::__declareClass('::IceGrid::ServerDescriptor')
            T_ServerDescriptorPrx = ::Ice::__declareProxy('::IceGrid::ServerDescriptor')
        end

        T_ServerDescriptor.defineClass(ServerDescriptor, false, ::IceGrid::T_CommunicatorDescriptor, [], [
            ['id', ::Ice::T_string],
            ['exe', ::Ice::T_string],
            ['pwd', ::Ice::T_string],
            ['options', ::Ice::T_StringSeq],
            ['envs', ::Ice::T_StringSeq],
            ['activation', ::Ice::T_string],
            ['activationTimeout', ::Ice::T_string],
            ['deactivationTimeout', ::Ice::T_string],
            ['applicationDistrib', ::Ice::T_bool],
            ['distrib', ::IceGrid::T_DistributionDescriptor],
            ['allocatable', ::Ice::T_bool],
            ['user', ::Ice::T_string]
        ])
        ServerDescriptor_mixin::ICE_TYPE = T_ServerDescriptor

        T_ServerDescriptorPrx.defineProxy(ServerDescriptorPrx, T_ServerDescriptor)
        ServerDescriptorPrx::ICE_TYPE = T_ServerDescriptorPrx
    end

    if not defined?(::IceGrid::T_ServerDescriptorSeq)
        T_ServerDescriptorSeq = ::Ice::__defineSequence('::IceGrid::ServerDescriptorSeq', ::IceGrid::T_ServerDescriptor)
    end

    if not defined?(::IceGrid::ServiceDescriptor_mixin)
        module ServiceDescriptor_mixin
            include ::IceGrid::CommunicatorDescriptor_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::CommunicatorDescriptor', '::IceGrid::ServiceDescriptor']
            end

            def ice_id(current=nil)
                '::IceGrid::ServiceDescriptor'
            end

            def inspect
                ::Ice::__stringify(self, T_ServiceDescriptor)
            end

            attr_accessor :name, :entry
        end
        class ServiceDescriptor < ::IceGrid::CommunicatorDescriptor
            include ServiceDescriptor_mixin

            def initialize(adapters=nil, propertySet=::IceGrid::PropertySetDescriptor.new, dbEnvs=nil, logs=nil, description='', name='', entry='')
                super(adapters, propertySet, dbEnvs, logs, description)
                @name = name
                @entry = entry
            end
        end
        module ServiceDescriptorPrx_mixin
            include ::IceGrid::CommunicatorDescriptorPrx_mixin
        end
        class ServiceDescriptorPrx < ::Ice::ObjectPrx
            include ServiceDescriptorPrx_mixin

            def ServiceDescriptorPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::ServiceDescriptor', facetOrCtx, _ctx)
            end

            def ServiceDescriptorPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_ServiceDescriptor)
            T_ServiceDescriptor = ::Ice::__declareClass('::IceGrid::ServiceDescriptor')
            T_ServiceDescriptorPrx = ::Ice::__declareProxy('::IceGrid::ServiceDescriptor')
        end

        T_ServiceDescriptor.defineClass(ServiceDescriptor, false, ::IceGrid::T_CommunicatorDescriptor, [], [
            ['name', ::Ice::T_string],
            ['entry', ::Ice::T_string]
        ])
        ServiceDescriptor_mixin::ICE_TYPE = T_ServiceDescriptor

        T_ServiceDescriptorPrx.defineProxy(ServiceDescriptorPrx, T_ServiceDescriptor)
        ServiceDescriptorPrx::ICE_TYPE = T_ServiceDescriptorPrx
    end

    if not defined?(::IceGrid::T_ServiceDescriptorSeq)
        T_ServiceDescriptorSeq = ::Ice::__defineSequence('::IceGrid::ServiceDescriptorSeq', ::IceGrid::T_ServiceDescriptor)
    end

    if not defined?(::IceGrid::ServerInstanceDescriptor)
        class ServerInstanceDescriptor
            def initialize(template='', parameterValues=nil, propertySet=::IceGrid::PropertySetDescriptor.new, servicePropertySets=nil)
                @template = template
                @parameterValues = parameterValues
                @propertySet = propertySet
                @servicePropertySets = servicePropertySets
            end

            def hash
                _h = 0
                _h = 5 * _h + @template.hash
                _h = 5 * _h + @parameterValues.hash
                _h = 5 * _h + @propertySet.hash
                _h = 5 * _h + @servicePropertySets.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @template != other.template or
                    @parameterValues != other.parameterValues or
                    @propertySet != other.propertySet or
                    @servicePropertySets != other.servicePropertySets
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ServerInstanceDescriptor)
            end

            attr_accessor :template, :parameterValues, :propertySet, :servicePropertySets
        end

        T_ServerInstanceDescriptor = ::Ice::__defineStruct('::IceGrid::ServerInstanceDescriptor', ServerInstanceDescriptor, [
            ["template", ::Ice::T_string],
            ["parameterValues", ::IceGrid::T_StringStringDict],
            ["propertySet", ::IceGrid::T_PropertySetDescriptor],
            ["servicePropertySets", ::IceGrid::T_PropertySetDescriptorDict]
        ])
    end

    if not defined?(::IceGrid::T_ServerInstanceDescriptorSeq)
        T_ServerInstanceDescriptorSeq = ::Ice::__defineSequence('::IceGrid::ServerInstanceDescriptorSeq', ::IceGrid::T_ServerInstanceDescriptor)
    end

    if not defined?(::IceGrid::TemplateDescriptor)
        class TemplateDescriptor
            def initialize(descriptor=nil, parameters=nil, parameterDefaults=nil)
                @descriptor = descriptor
                @parameters = parameters
                @parameterDefaults = parameterDefaults
            end

            def hash
                _h = 0
                _h = 5 * _h + @descriptor.hash
                _h = 5 * _h + @parameters.hash
                _h = 5 * _h + @parameterDefaults.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @descriptor != other.descriptor or
                    @parameters != other.parameters or
                    @parameterDefaults != other.parameterDefaults
                true
            end

            def inspect
                ::Ice::__stringify(self, T_TemplateDescriptor)
            end

            attr_accessor :descriptor, :parameters, :parameterDefaults
        end

        T_TemplateDescriptor = ::Ice::__defineStruct('::IceGrid::TemplateDescriptor', TemplateDescriptor, [
            ["descriptor", ::IceGrid::T_CommunicatorDescriptor],
            ["parameters", ::Ice::T_StringSeq],
            ["parameterDefaults", ::IceGrid::T_StringStringDict]
        ])
    end

    if not defined?(::IceGrid::T_TemplateDescriptorDict)
        T_TemplateDescriptorDict = ::Ice::__defineDictionary('::IceGrid::TemplateDescriptorDict', ::Ice::T_string, ::IceGrid::T_TemplateDescriptor)
    end

    if not defined?(::IceGrid::ServiceInstanceDescriptor)
        class ServiceInstanceDescriptor
            def initialize(template='', parameterValues=nil, descriptor=nil, propertySet=::IceGrid::PropertySetDescriptor.new)
                @template = template
                @parameterValues = parameterValues
                @descriptor = descriptor
                @propertySet = propertySet
            end

            def hash
                _h = 0
                _h = 5 * _h + @template.hash
                _h = 5 * _h + @parameterValues.hash
                _h = 5 * _h + @descriptor.hash
                _h = 5 * _h + @propertySet.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @template != other.template or
                    @parameterValues != other.parameterValues or
                    @descriptor != other.descriptor or
                    @propertySet != other.propertySet
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ServiceInstanceDescriptor)
            end

            attr_accessor :template, :parameterValues, :descriptor, :propertySet
        end

        T_ServiceInstanceDescriptor = ::Ice::__defineStruct('::IceGrid::ServiceInstanceDescriptor', ServiceInstanceDescriptor, [
            ["template", ::Ice::T_string],
            ["parameterValues", ::IceGrid::T_StringStringDict],
            ["descriptor", ::IceGrid::T_ServiceDescriptor],
            ["propertySet", ::IceGrid::T_PropertySetDescriptor]
        ])
    end

    if not defined?(::IceGrid::T_ServiceInstanceDescriptorSeq)
        T_ServiceInstanceDescriptorSeq = ::Ice::__defineSequence('::IceGrid::ServiceInstanceDescriptorSeq', ::IceGrid::T_ServiceInstanceDescriptor)
    end

    if not defined?(::IceGrid::IceBoxDescriptor_mixin)
        module IceBoxDescriptor_mixin
            include ::IceGrid::ServerDescriptor_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::CommunicatorDescriptor', '::IceGrid::IceBoxDescriptor', '::IceGrid::ServerDescriptor']
            end

            def ice_id(current=nil)
                '::IceGrid::IceBoxDescriptor'
            end

            def inspect
                ::Ice::__stringify(self, T_IceBoxDescriptor)
            end

            attr_accessor :services
        end
        class IceBoxDescriptor < ::IceGrid::ServerDescriptor
            include IceBoxDescriptor_mixin

            def initialize(adapters=nil, propertySet=::IceGrid::PropertySetDescriptor.new, dbEnvs=nil, logs=nil, description='', id='', exe='', pwd='', options=nil, envs=nil, activation='', activationTimeout='', deactivationTimeout='', applicationDistrib=false, distrib=::IceGrid::DistributionDescriptor.new, allocatable=false, user='', services=nil)
                super(adapters, propertySet, dbEnvs, logs, description, id, exe, pwd, options, envs, activation, activationTimeout, deactivationTimeout, applicationDistrib, distrib, allocatable, user)
                @services = services
            end
        end
        module IceBoxDescriptorPrx_mixin
            include ::IceGrid::ServerDescriptorPrx_mixin
        end
        class IceBoxDescriptorPrx < ::Ice::ObjectPrx
            include IceBoxDescriptorPrx_mixin

            def IceBoxDescriptorPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::IceBoxDescriptor', facetOrCtx, _ctx)
            end

            def IceBoxDescriptorPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_IceBoxDescriptor)
            T_IceBoxDescriptor = ::Ice::__declareClass('::IceGrid::IceBoxDescriptor')
            T_IceBoxDescriptorPrx = ::Ice::__declareProxy('::IceGrid::IceBoxDescriptor')
        end

        T_IceBoxDescriptor.defineClass(IceBoxDescriptor, false, ::IceGrid::T_ServerDescriptor, [], [['services', ::IceGrid::T_ServiceInstanceDescriptorSeq]])
        IceBoxDescriptor_mixin::ICE_TYPE = T_IceBoxDescriptor

        T_IceBoxDescriptorPrx.defineProxy(IceBoxDescriptorPrx, T_IceBoxDescriptor)
        IceBoxDescriptorPrx::ICE_TYPE = T_IceBoxDescriptorPrx
    end

    if not defined?(::IceGrid::NodeDescriptor)
        class NodeDescriptor
            def initialize(variables=nil, serverInstances=nil, servers=nil, loadFactor='', description='', propertySets=nil)
                @variables = variables
                @serverInstances = serverInstances
                @servers = servers
                @loadFactor = loadFactor
                @description = description
                @propertySets = propertySets
            end

            def hash
                _h = 0
                _h = 5 * _h + @variables.hash
                _h = 5 * _h + @serverInstances.hash
                _h = 5 * _h + @servers.hash
                _h = 5 * _h + @loadFactor.hash
                _h = 5 * _h + @description.hash
                _h = 5 * _h + @propertySets.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @variables != other.variables or
                    @serverInstances != other.serverInstances or
                    @servers != other.servers or
                    @loadFactor != other.loadFactor or
                    @description != other.description or
                    @propertySets != other.propertySets
                true
            end

            def inspect
                ::Ice::__stringify(self, T_NodeDescriptor)
            end

            attr_accessor :variables, :serverInstances, :servers, :loadFactor, :description, :propertySets
        end

        T_NodeDescriptor = ::Ice::__defineStruct('::IceGrid::NodeDescriptor', NodeDescriptor, [
            ["variables", ::IceGrid::T_StringStringDict],
            ["serverInstances", ::IceGrid::T_ServerInstanceDescriptorSeq],
            ["servers", ::IceGrid::T_ServerDescriptorSeq],
            ["loadFactor", ::Ice::T_string],
            ["description", ::Ice::T_string],
            ["propertySets", ::IceGrid::T_PropertySetDescriptorDict]
        ])
    end

    if not defined?(::IceGrid::T_NodeDescriptorDict)
        T_NodeDescriptorDict = ::Ice::__defineDictionary('::IceGrid::NodeDescriptorDict', ::Ice::T_string, ::IceGrid::T_NodeDescriptor)
    end

    if not defined?(::IceGrid::LoadBalancingPolicy_mixin)
        module LoadBalancingPolicy_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::LoadBalancingPolicy']
            end

            def ice_id(current=nil)
                '::IceGrid::LoadBalancingPolicy'
            end

            def inspect
                ::Ice::__stringify(self, T_LoadBalancingPolicy)
            end

            attr_accessor :nReplicas
        end
        class LoadBalancingPolicy
            include LoadBalancingPolicy_mixin

            def initialize(nReplicas='')
                @nReplicas = nReplicas
            end
        end
        module LoadBalancingPolicyPrx_mixin
        end
        class LoadBalancingPolicyPrx < ::Ice::ObjectPrx
            include LoadBalancingPolicyPrx_mixin

            def LoadBalancingPolicyPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::LoadBalancingPolicy', facetOrCtx, _ctx)
            end

            def LoadBalancingPolicyPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_LoadBalancingPolicy)
            T_LoadBalancingPolicy = ::Ice::__declareClass('::IceGrid::LoadBalancingPolicy')
            T_LoadBalancingPolicyPrx = ::Ice::__declareProxy('::IceGrid::LoadBalancingPolicy')
        end

        T_LoadBalancingPolicy.defineClass(LoadBalancingPolicy, false, nil, [], [['nReplicas', ::Ice::T_string]])
        LoadBalancingPolicy_mixin::ICE_TYPE = T_LoadBalancingPolicy

        T_LoadBalancingPolicyPrx.defineProxy(LoadBalancingPolicyPrx, T_LoadBalancingPolicy)
        LoadBalancingPolicyPrx::ICE_TYPE = T_LoadBalancingPolicyPrx
    end

    if not defined?(::IceGrid::RandomLoadBalancingPolicy_mixin)
        module RandomLoadBalancingPolicy_mixin
            include ::IceGrid::LoadBalancingPolicy_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::LoadBalancingPolicy', '::IceGrid::RandomLoadBalancingPolicy']
            end

            def ice_id(current=nil)
                '::IceGrid::RandomLoadBalancingPolicy'
            end

            def inspect
                ::Ice::__stringify(self, T_RandomLoadBalancingPolicy)
            end
        end
        class RandomLoadBalancingPolicy < ::IceGrid::LoadBalancingPolicy
            include RandomLoadBalancingPolicy_mixin

            def initialize(nReplicas='')
                super(nReplicas)
            end
        end
        module RandomLoadBalancingPolicyPrx_mixin
            include ::IceGrid::LoadBalancingPolicyPrx_mixin
        end
        class RandomLoadBalancingPolicyPrx < ::Ice::ObjectPrx
            include RandomLoadBalancingPolicyPrx_mixin

            def RandomLoadBalancingPolicyPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::RandomLoadBalancingPolicy', facetOrCtx, _ctx)
            end

            def RandomLoadBalancingPolicyPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_RandomLoadBalancingPolicy)
            T_RandomLoadBalancingPolicy = ::Ice::__declareClass('::IceGrid::RandomLoadBalancingPolicy')
            T_RandomLoadBalancingPolicyPrx = ::Ice::__declareProxy('::IceGrid::RandomLoadBalancingPolicy')
        end

        T_RandomLoadBalancingPolicy.defineClass(RandomLoadBalancingPolicy, false, ::IceGrid::T_LoadBalancingPolicy, [], [])
        RandomLoadBalancingPolicy_mixin::ICE_TYPE = T_RandomLoadBalancingPolicy

        T_RandomLoadBalancingPolicyPrx.defineProxy(RandomLoadBalancingPolicyPrx, T_RandomLoadBalancingPolicy)
        RandomLoadBalancingPolicyPrx::ICE_TYPE = T_RandomLoadBalancingPolicyPrx
    end

    if not defined?(::IceGrid::OrderedLoadBalancingPolicy_mixin)
        module OrderedLoadBalancingPolicy_mixin
            include ::IceGrid::LoadBalancingPolicy_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::LoadBalancingPolicy', '::IceGrid::OrderedLoadBalancingPolicy']
            end

            def ice_id(current=nil)
                '::IceGrid::OrderedLoadBalancingPolicy'
            end

            def inspect
                ::Ice::__stringify(self, T_OrderedLoadBalancingPolicy)
            end
        end
        class OrderedLoadBalancingPolicy < ::IceGrid::LoadBalancingPolicy
            include OrderedLoadBalancingPolicy_mixin

            def initialize(nReplicas='')
                super(nReplicas)
            end
        end
        module OrderedLoadBalancingPolicyPrx_mixin
            include ::IceGrid::LoadBalancingPolicyPrx_mixin
        end
        class OrderedLoadBalancingPolicyPrx < ::Ice::ObjectPrx
            include OrderedLoadBalancingPolicyPrx_mixin

            def OrderedLoadBalancingPolicyPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::OrderedLoadBalancingPolicy', facetOrCtx, _ctx)
            end

            def OrderedLoadBalancingPolicyPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_OrderedLoadBalancingPolicy)
            T_OrderedLoadBalancingPolicy = ::Ice::__declareClass('::IceGrid::OrderedLoadBalancingPolicy')
            T_OrderedLoadBalancingPolicyPrx = ::Ice::__declareProxy('::IceGrid::OrderedLoadBalancingPolicy')
        end

        T_OrderedLoadBalancingPolicy.defineClass(OrderedLoadBalancingPolicy, false, ::IceGrid::T_LoadBalancingPolicy, [], [])
        OrderedLoadBalancingPolicy_mixin::ICE_TYPE = T_OrderedLoadBalancingPolicy

        T_OrderedLoadBalancingPolicyPrx.defineProxy(OrderedLoadBalancingPolicyPrx, T_OrderedLoadBalancingPolicy)
        OrderedLoadBalancingPolicyPrx::ICE_TYPE = T_OrderedLoadBalancingPolicyPrx
    end

    if not defined?(::IceGrid::RoundRobinLoadBalancingPolicy_mixin)
        module RoundRobinLoadBalancingPolicy_mixin
            include ::IceGrid::LoadBalancingPolicy_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::LoadBalancingPolicy', '::IceGrid::RoundRobinLoadBalancingPolicy']
            end

            def ice_id(current=nil)
                '::IceGrid::RoundRobinLoadBalancingPolicy'
            end

            def inspect
                ::Ice::__stringify(self, T_RoundRobinLoadBalancingPolicy)
            end
        end
        class RoundRobinLoadBalancingPolicy < ::IceGrid::LoadBalancingPolicy
            include RoundRobinLoadBalancingPolicy_mixin

            def initialize(nReplicas='')
                super(nReplicas)
            end
        end
        module RoundRobinLoadBalancingPolicyPrx_mixin
            include ::IceGrid::LoadBalancingPolicyPrx_mixin
        end
        class RoundRobinLoadBalancingPolicyPrx < ::Ice::ObjectPrx
            include RoundRobinLoadBalancingPolicyPrx_mixin

            def RoundRobinLoadBalancingPolicyPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::RoundRobinLoadBalancingPolicy', facetOrCtx, _ctx)
            end

            def RoundRobinLoadBalancingPolicyPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_RoundRobinLoadBalancingPolicy)
            T_RoundRobinLoadBalancingPolicy = ::Ice::__declareClass('::IceGrid::RoundRobinLoadBalancingPolicy')
            T_RoundRobinLoadBalancingPolicyPrx = ::Ice::__declareProxy('::IceGrid::RoundRobinLoadBalancingPolicy')
        end

        T_RoundRobinLoadBalancingPolicy.defineClass(RoundRobinLoadBalancingPolicy, false, ::IceGrid::T_LoadBalancingPolicy, [], [])
        RoundRobinLoadBalancingPolicy_mixin::ICE_TYPE = T_RoundRobinLoadBalancingPolicy

        T_RoundRobinLoadBalancingPolicyPrx.defineProxy(RoundRobinLoadBalancingPolicyPrx, T_RoundRobinLoadBalancingPolicy)
        RoundRobinLoadBalancingPolicyPrx::ICE_TYPE = T_RoundRobinLoadBalancingPolicyPrx
    end

    if not defined?(::IceGrid::AdaptiveLoadBalancingPolicy_mixin)
        module AdaptiveLoadBalancingPolicy_mixin
            include ::IceGrid::LoadBalancingPolicy_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::AdaptiveLoadBalancingPolicy', '::IceGrid::LoadBalancingPolicy']
            end

            def ice_id(current=nil)
                '::IceGrid::AdaptiveLoadBalancingPolicy'
            end

            def inspect
                ::Ice::__stringify(self, T_AdaptiveLoadBalancingPolicy)
            end

            attr_accessor :loadSample
        end
        class AdaptiveLoadBalancingPolicy < ::IceGrid::LoadBalancingPolicy
            include AdaptiveLoadBalancingPolicy_mixin

            def initialize(nReplicas='', loadSample='')
                super(nReplicas)
                @loadSample = loadSample
            end
        end
        module AdaptiveLoadBalancingPolicyPrx_mixin
            include ::IceGrid::LoadBalancingPolicyPrx_mixin
        end
        class AdaptiveLoadBalancingPolicyPrx < ::Ice::ObjectPrx
            include AdaptiveLoadBalancingPolicyPrx_mixin

            def AdaptiveLoadBalancingPolicyPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::AdaptiveLoadBalancingPolicy', facetOrCtx, _ctx)
            end

            def AdaptiveLoadBalancingPolicyPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_AdaptiveLoadBalancingPolicy)
            T_AdaptiveLoadBalancingPolicy = ::Ice::__declareClass('::IceGrid::AdaptiveLoadBalancingPolicy')
            T_AdaptiveLoadBalancingPolicyPrx = ::Ice::__declareProxy('::IceGrid::AdaptiveLoadBalancingPolicy')
        end

        T_AdaptiveLoadBalancingPolicy.defineClass(AdaptiveLoadBalancingPolicy, false, ::IceGrid::T_LoadBalancingPolicy, [], [['loadSample', ::Ice::T_string]])
        AdaptiveLoadBalancingPolicy_mixin::ICE_TYPE = T_AdaptiveLoadBalancingPolicy

        T_AdaptiveLoadBalancingPolicyPrx.defineProxy(AdaptiveLoadBalancingPolicyPrx, T_AdaptiveLoadBalancingPolicy)
        AdaptiveLoadBalancingPolicyPrx::ICE_TYPE = T_AdaptiveLoadBalancingPolicyPrx
    end

    if not defined?(::IceGrid::ReplicaGroupDescriptor)
        class ReplicaGroupDescriptor
            def initialize(id='', loadBalancing=nil, objects=nil, description='')
                @id = id
                @loadBalancing = loadBalancing
                @objects = objects
                @description = description
            end

            def hash
                _h = 0
                _h = 5 * _h + @id.hash
                _h = 5 * _h + @loadBalancing.hash
                _h = 5 * _h + @objects.hash
                _h = 5 * _h + @description.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @id != other.id or
                    @loadBalancing != other.loadBalancing or
                    @objects != other.objects or
                    @description != other.description
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ReplicaGroupDescriptor)
            end

            attr_accessor :id, :loadBalancing, :objects, :description
        end

        T_ReplicaGroupDescriptor = ::Ice::__defineStruct('::IceGrid::ReplicaGroupDescriptor', ReplicaGroupDescriptor, [
            ["id", ::Ice::T_string],
            ["loadBalancing", ::IceGrid::T_LoadBalancingPolicy],
            ["objects", ::IceGrid::T_ObjectDescriptorSeq],
            ["description", ::Ice::T_string]
        ])
    end

    if not defined?(::IceGrid::T_ReplicaGroupDescriptorSeq)
        T_ReplicaGroupDescriptorSeq = ::Ice::__defineSequence('::IceGrid::ReplicaGroupDescriptorSeq', ::IceGrid::T_ReplicaGroupDescriptor)
    end

    if not defined?(::IceGrid::ApplicationDescriptor)
        class ApplicationDescriptor
            def initialize(name='', variables=nil, replicaGroups=nil, serverTemplates=nil, serviceTemplates=nil, nodes=nil, distrib=::IceGrid::DistributionDescriptor.new, description='', propertySets=nil)
                @name = name
                @variables = variables
                @replicaGroups = replicaGroups
                @serverTemplates = serverTemplates
                @serviceTemplates = serviceTemplates
                @nodes = nodes
                @distrib = distrib
                @description = description
                @propertySets = propertySets
            end

            def hash
                _h = 0
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @variables.hash
                _h = 5 * _h + @replicaGroups.hash
                _h = 5 * _h + @serverTemplates.hash
                _h = 5 * _h + @serviceTemplates.hash
                _h = 5 * _h + @nodes.hash
                _h = 5 * _h + @distrib.hash
                _h = 5 * _h + @description.hash
                _h = 5 * _h + @propertySets.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @name != other.name or
                    @variables != other.variables or
                    @replicaGroups != other.replicaGroups or
                    @serverTemplates != other.serverTemplates or
                    @serviceTemplates != other.serviceTemplates or
                    @nodes != other.nodes or
                    @distrib != other.distrib or
                    @description != other.description or
                    @propertySets != other.propertySets
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ApplicationDescriptor)
            end

            attr_accessor :name, :variables, :replicaGroups, :serverTemplates, :serviceTemplates, :nodes, :distrib, :description, :propertySets
        end

        T_ApplicationDescriptor = ::Ice::__defineStruct('::IceGrid::ApplicationDescriptor', ApplicationDescriptor, [
            ["name", ::Ice::T_string],
            ["variables", ::IceGrid::T_StringStringDict],
            ["replicaGroups", ::IceGrid::T_ReplicaGroupDescriptorSeq],
            ["serverTemplates", ::IceGrid::T_TemplateDescriptorDict],
            ["serviceTemplates", ::IceGrid::T_TemplateDescriptorDict],
            ["nodes", ::IceGrid::T_NodeDescriptorDict],
            ["distrib", ::IceGrid::T_DistributionDescriptor],
            ["description", ::Ice::T_string],
            ["propertySets", ::IceGrid::T_PropertySetDescriptorDict]
        ])
    end

    if not defined?(::IceGrid::T_ApplicationDescriptorSeq)
        T_ApplicationDescriptorSeq = ::Ice::__defineSequence('::IceGrid::ApplicationDescriptorSeq', ::IceGrid::T_ApplicationDescriptor)
    end

    if not defined?(::IceGrid::BoxedString_mixin)
        module BoxedString_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::BoxedString']
            end

            def ice_id(current=nil)
                '::IceGrid::BoxedString'
            end

            def inspect
                ::Ice::__stringify(self, T_BoxedString)
            end

            attr_accessor :value
        end
        class BoxedString
            include BoxedString_mixin

            def initialize(value='')
                @value = value
            end
        end
        module BoxedStringPrx_mixin
        end
        class BoxedStringPrx < ::Ice::ObjectPrx
            include BoxedStringPrx_mixin

            def BoxedStringPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::BoxedString', facetOrCtx, _ctx)
            end

            def BoxedStringPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_BoxedString)
            T_BoxedString = ::Ice::__declareClass('::IceGrid::BoxedString')
            T_BoxedStringPrx = ::Ice::__declareProxy('::IceGrid::BoxedString')
        end

        T_BoxedString.defineClass(BoxedString, false, nil, [], [['value', ::Ice::T_string]])
        BoxedString_mixin::ICE_TYPE = T_BoxedString

        T_BoxedStringPrx.defineProxy(BoxedStringPrx, T_BoxedString)
        BoxedStringPrx::ICE_TYPE = T_BoxedStringPrx
    end

    if not defined?(::IceGrid::NodeUpdateDescriptor)
        class NodeUpdateDescriptor
            def initialize(name='', description=nil, variables=nil, removeVariables=nil, propertySets=nil, removePropertySets=nil, serverInstances=nil, servers=nil, removeServers=nil, loadFactor=nil)
                @name = name
                @description = description
                @variables = variables
                @removeVariables = removeVariables
                @propertySets = propertySets
                @removePropertySets = removePropertySets
                @serverInstances = serverInstances
                @servers = servers
                @removeServers = removeServers
                @loadFactor = loadFactor
            end

            def hash
                _h = 0
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @description.hash
                _h = 5 * _h + @variables.hash
                _h = 5 * _h + @removeVariables.hash
                _h = 5 * _h + @propertySets.hash
                _h = 5 * _h + @removePropertySets.hash
                _h = 5 * _h + @serverInstances.hash
                _h = 5 * _h + @servers.hash
                _h = 5 * _h + @removeServers.hash
                _h = 5 * _h + @loadFactor.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @name != other.name or
                    @description != other.description or
                    @variables != other.variables or
                    @removeVariables != other.removeVariables or
                    @propertySets != other.propertySets or
                    @removePropertySets != other.removePropertySets or
                    @serverInstances != other.serverInstances or
                    @servers != other.servers or
                    @removeServers != other.removeServers or
                    @loadFactor != other.loadFactor
                true
            end

            def inspect
                ::Ice::__stringify(self, T_NodeUpdateDescriptor)
            end

            attr_accessor :name, :description, :variables, :removeVariables, :propertySets, :removePropertySets, :serverInstances, :servers, :removeServers, :loadFactor
        end

        T_NodeUpdateDescriptor = ::Ice::__defineStruct('::IceGrid::NodeUpdateDescriptor', NodeUpdateDescriptor, [
            ["name", ::Ice::T_string],
            ["description", ::IceGrid::T_BoxedString],
            ["variables", ::IceGrid::T_StringStringDict],
            ["removeVariables", ::Ice::T_StringSeq],
            ["propertySets", ::IceGrid::T_PropertySetDescriptorDict],
            ["removePropertySets", ::Ice::T_StringSeq],
            ["serverInstances", ::IceGrid::T_ServerInstanceDescriptorSeq],
            ["servers", ::IceGrid::T_ServerDescriptorSeq],
            ["removeServers", ::Ice::T_StringSeq],
            ["loadFactor", ::IceGrid::T_BoxedString]
        ])
    end

    if not defined?(::IceGrid::T_NodeUpdateDescriptorSeq)
        T_NodeUpdateDescriptorSeq = ::Ice::__defineSequence('::IceGrid::NodeUpdateDescriptorSeq', ::IceGrid::T_NodeUpdateDescriptor)
    end

    if not defined?(::IceGrid::BoxedDistributionDescriptor_mixin)
        module BoxedDistributionDescriptor_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::BoxedDistributionDescriptor']
            end

            def ice_id(current=nil)
                '::IceGrid::BoxedDistributionDescriptor'
            end

            def inspect
                ::Ice::__stringify(self, T_BoxedDistributionDescriptor)
            end

            attr_accessor :value
        end
        class BoxedDistributionDescriptor
            include BoxedDistributionDescriptor_mixin

            def initialize(value=::IceGrid::DistributionDescriptor.new)
                @value = value
            end
        end
        module BoxedDistributionDescriptorPrx_mixin
        end
        class BoxedDistributionDescriptorPrx < ::Ice::ObjectPrx
            include BoxedDistributionDescriptorPrx_mixin

            def BoxedDistributionDescriptorPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::BoxedDistributionDescriptor', facetOrCtx, _ctx)
            end

            def BoxedDistributionDescriptorPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_BoxedDistributionDescriptor)
            T_BoxedDistributionDescriptor = ::Ice::__declareClass('::IceGrid::BoxedDistributionDescriptor')
            T_BoxedDistributionDescriptorPrx = ::Ice::__declareProxy('::IceGrid::BoxedDistributionDescriptor')
        end

        T_BoxedDistributionDescriptor.defineClass(BoxedDistributionDescriptor, false, nil, [], [['value', ::IceGrid::T_DistributionDescriptor]])
        BoxedDistributionDescriptor_mixin::ICE_TYPE = T_BoxedDistributionDescriptor

        T_BoxedDistributionDescriptorPrx.defineProxy(BoxedDistributionDescriptorPrx, T_BoxedDistributionDescriptor)
        BoxedDistributionDescriptorPrx::ICE_TYPE = T_BoxedDistributionDescriptorPrx
    end

    if not defined?(::IceGrid::ApplicationUpdateDescriptor)
        class ApplicationUpdateDescriptor
            def initialize(name='', description=nil, distrib=nil, variables=nil, removeVariables=nil, propertySets=nil, removePropertySets=nil, replicaGroups=nil, removeReplicaGroups=nil, serverTemplates=nil, removeServerTemplates=nil, serviceTemplates=nil, removeServiceTemplates=nil, nodes=nil, removeNodes=nil)
                @name = name
                @description = description
                @distrib = distrib
                @variables = variables
                @removeVariables = removeVariables
                @propertySets = propertySets
                @removePropertySets = removePropertySets
                @replicaGroups = replicaGroups
                @removeReplicaGroups = removeReplicaGroups
                @serverTemplates = serverTemplates
                @removeServerTemplates = removeServerTemplates
                @serviceTemplates = serviceTemplates
                @removeServiceTemplates = removeServiceTemplates
                @nodes = nodes
                @removeNodes = removeNodes
            end

            def hash
                _h = 0
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @description.hash
                _h = 5 * _h + @distrib.hash
                _h = 5 * _h + @variables.hash
                _h = 5 * _h + @removeVariables.hash
                _h = 5 * _h + @propertySets.hash
                _h = 5 * _h + @removePropertySets.hash
                _h = 5 * _h + @replicaGroups.hash
                _h = 5 * _h + @removeReplicaGroups.hash
                _h = 5 * _h + @serverTemplates.hash
                _h = 5 * _h + @removeServerTemplates.hash
                _h = 5 * _h + @serviceTemplates.hash
                _h = 5 * _h + @removeServiceTemplates.hash
                _h = 5 * _h + @nodes.hash
                _h = 5 * _h + @removeNodes.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @name != other.name or
                    @description != other.description or
                    @distrib != other.distrib or
                    @variables != other.variables or
                    @removeVariables != other.removeVariables or
                    @propertySets != other.propertySets or
                    @removePropertySets != other.removePropertySets or
                    @replicaGroups != other.replicaGroups or
                    @removeReplicaGroups != other.removeReplicaGroups or
                    @serverTemplates != other.serverTemplates or
                    @removeServerTemplates != other.removeServerTemplates or
                    @serviceTemplates != other.serviceTemplates or
                    @removeServiceTemplates != other.removeServiceTemplates or
                    @nodes != other.nodes or
                    @removeNodes != other.removeNodes
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ApplicationUpdateDescriptor)
            end

            attr_accessor :name, :description, :distrib, :variables, :removeVariables, :propertySets, :removePropertySets, :replicaGroups, :removeReplicaGroups, :serverTemplates, :removeServerTemplates, :serviceTemplates, :removeServiceTemplates, :nodes, :removeNodes
        end

        T_ApplicationUpdateDescriptor = ::Ice::__defineStruct('::IceGrid::ApplicationUpdateDescriptor', ApplicationUpdateDescriptor, [
            ["name", ::Ice::T_string],
            ["description", ::IceGrid::T_BoxedString],
            ["distrib", ::IceGrid::T_BoxedDistributionDescriptor],
            ["variables", ::IceGrid::T_StringStringDict],
            ["removeVariables", ::Ice::T_StringSeq],
            ["propertySets", ::IceGrid::T_PropertySetDescriptorDict],
            ["removePropertySets", ::Ice::T_StringSeq],
            ["replicaGroups", ::IceGrid::T_ReplicaGroupDescriptorSeq],
            ["removeReplicaGroups", ::Ice::T_StringSeq],
            ["serverTemplates", ::IceGrid::T_TemplateDescriptorDict],
            ["removeServerTemplates", ::Ice::T_StringSeq],
            ["serviceTemplates", ::IceGrid::T_TemplateDescriptorDict],
            ["removeServiceTemplates", ::Ice::T_StringSeq],
            ["nodes", ::IceGrid::T_NodeUpdateDescriptorSeq],
            ["removeNodes", ::Ice::T_StringSeq]
        ])
    end
end
