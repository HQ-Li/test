# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Observer.ice'

require 'Ice'
require 'Glacier2/Session.rb'
require 'IceGrid/Exception.rb'
require 'IceGrid/Descriptor.rb'
require 'IceGrid/Admin.rb'

module IceGrid

    if not defined?(::IceGrid::ServerDynamicInfo)
        class ServerDynamicInfo
            def initialize(id='', state=::IceGrid::ServerState::Inactive, pid=0, enabled=false)
                @id = id
                @state = state
                @pid = pid
                @enabled = enabled
            end

            def hash
                _h = 0
                _h = 5 * _h + @id.hash
                _h = 5 * _h + @state.hash
                _h = 5 * _h + @pid.hash
                _h = 5 * _h + @enabled.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @id != other.id or
                    @state != other.state or
                    @pid != other.pid or
                    @enabled != other.enabled
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ServerDynamicInfo)
            end

            attr_accessor :id, :state, :pid, :enabled
        end

        T_ServerDynamicInfo = ::Ice::__defineStruct('::IceGrid::ServerDynamicInfo', ServerDynamicInfo, [
            ["id", ::Ice::T_string],
            ["state", ::IceGrid::T_ServerState],
            ["pid", ::Ice::T_int],
            ["enabled", ::Ice::T_bool]
        ])
    end

    if not defined?(::IceGrid::T_ServerDynamicInfoSeq)
        T_ServerDynamicInfoSeq = ::Ice::__defineSequence('::IceGrid::ServerDynamicInfoSeq', ::IceGrid::T_ServerDynamicInfo)
    end

    if not defined?(::IceGrid::AdapterDynamicInfo)
        class AdapterDynamicInfo
            def initialize(id='', proxy=nil)
                @id = id
                @proxy = proxy
            end

            def hash
                _h = 0
                _h = 5 * _h + @id.hash
                _h = 5 * _h + @proxy.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @id != other.id or
                    @proxy != other.proxy
                true
            end

            def inspect
                ::Ice::__stringify(self, T_AdapterDynamicInfo)
            end

            attr_accessor :id, :proxy
        end

        T_AdapterDynamicInfo = ::Ice::__defineStruct('::IceGrid::AdapterDynamicInfo', AdapterDynamicInfo, [
            ["id", ::Ice::T_string],
            ["proxy", ::Ice::T_ObjectPrx]
        ])
    end

    if not defined?(::IceGrid::T_AdapterDynamicInfoSeq)
        T_AdapterDynamicInfoSeq = ::Ice::__defineSequence('::IceGrid::AdapterDynamicInfoSeq', ::IceGrid::T_AdapterDynamicInfo)
    end

    if not defined?(::IceGrid::NodeDynamicInfo)
        class NodeDynamicInfo
            def initialize(info=::IceGrid::NodeInfo.new, servers=nil, adapters=nil)
                @info = info
                @servers = servers
                @adapters = adapters
            end

            def hash
                _h = 0
                _h = 5 * _h + @info.hash
                _h = 5 * _h + @servers.hash
                _h = 5 * _h + @adapters.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @info != other.info or
                    @servers != other.servers or
                    @adapters != other.adapters
                true
            end

            def inspect
                ::Ice::__stringify(self, T_NodeDynamicInfo)
            end

            attr_accessor :info, :servers, :adapters
        end

        T_NodeDynamicInfo = ::Ice::__defineStruct('::IceGrid::NodeDynamicInfo', NodeDynamicInfo, [
            ["info", ::IceGrid::T_NodeInfo],
            ["servers", ::IceGrid::T_ServerDynamicInfoSeq],
            ["adapters", ::IceGrid::T_AdapterDynamicInfoSeq]
        ])
    end

    if not defined?(::IceGrid::T_NodeDynamicInfoSeq)
        T_NodeDynamicInfoSeq = ::Ice::__defineSequence('::IceGrid::NodeDynamicInfoSeq', ::IceGrid::T_NodeDynamicInfo)
    end

    if not defined?(::IceGrid::NodeObserver_mixin)
        module NodeObserver_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::NodeObserver']
            end

            def ice_id(current=nil)
                '::IceGrid::NodeObserver'
            end

            #
            # Operation signatures.
            #
            # def nodeInit(nodes, current=nil)
            # def nodeUp(node, current=nil)
            # def nodeDown(name, current=nil)
            # def updateServer(node, updatedInfo, current=nil)
            # def updateAdapter(node, updatedInfo, current=nil)

            def inspect
                ::Ice::__stringify(self, T_NodeObserver)
            end
        end
        module NodeObserverPrx_mixin

            def nodeInit(nodes, _ctx=nil)
                NodeObserver_mixin::OP_nodeInit.invoke(self, [nodes], _ctx)
            end

            def nodeInit_async(_cb, nodes, _ctx=nil)
                NodeObserver_mixin::OP_nodeInit.invokeAsync(self, _cb, [nodes, ], _ctx)
            end

            def nodeUp(node, _ctx=nil)
                NodeObserver_mixin::OP_nodeUp.invoke(self, [node], _ctx)
            end

            def nodeDown(name, _ctx=nil)
                NodeObserver_mixin::OP_nodeDown.invoke(self, [name], _ctx)
            end

            def updateServer(node, updatedInfo, _ctx=nil)
                NodeObserver_mixin::OP_updateServer.invoke(self, [node, updatedInfo], _ctx)
            end

            def updateAdapter(node, updatedInfo, _ctx=nil)
                NodeObserver_mixin::OP_updateAdapter.invoke(self, [node, updatedInfo], _ctx)
            end
        end
        class NodeObserverPrx < ::Ice::ObjectPrx
            include NodeObserverPrx_mixin

            def NodeObserverPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::NodeObserver', facetOrCtx, _ctx)
            end

            def NodeObserverPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_NodeObserver)
            T_NodeObserver = ::Ice::__declareClass('::IceGrid::NodeObserver')
            T_NodeObserverPrx = ::Ice::__declareProxy('::IceGrid::NodeObserver')
        end

        T_NodeObserver.defineClass(nil, true, nil, [], [])
        NodeObserver_mixin::ICE_TYPE = T_NodeObserver

        T_NodeObserverPrx.defineProxy(NodeObserverPrx, T_NodeObserver)
        NodeObserverPrx::ICE_TYPE = T_NodeObserverPrx

        NodeObserver_mixin::OP_nodeInit = ::Ice::__defineOperation('nodeInit', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_NodeDynamicInfoSeq], [], nil, [])
        NodeObserver_mixin::OP_nodeUp = ::Ice::__defineOperation('nodeUp', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_NodeDynamicInfo], [], nil, [])
        NodeObserver_mixin::OP_nodeDown = ::Ice::__defineOperation('nodeDown', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [])
        NodeObserver_mixin::OP_updateServer = ::Ice::__defineOperation('updateServer', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::IceGrid::T_ServerDynamicInfo], [], nil, [])
        NodeObserver_mixin::OP_updateAdapter = ::Ice::__defineOperation('updateAdapter', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::IceGrid::T_AdapterDynamicInfo], [], nil, [])
    end

    if not defined?(::IceGrid::ApplicationObserver_mixin)
        module ApplicationObserver_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::ApplicationObserver']
            end

            def ice_id(current=nil)
                '::IceGrid::ApplicationObserver'
            end

            #
            # Operation signatures.
            #
            # def applicationInit(serial, applications, current=nil)
            # def applicationAdded(serial, desc, current=nil)
            # def applicationRemoved(serial, name, current=nil)
            # def applicationUpdated(serial, desc, current=nil)

            def inspect
                ::Ice::__stringify(self, T_ApplicationObserver)
            end
        end
        module ApplicationObserverPrx_mixin

            def applicationInit(serial, applications, _ctx=nil)
                ApplicationObserver_mixin::OP_applicationInit.invoke(self, [serial, applications], _ctx)
            end

            def applicationInit_async(_cb, serial, applications, _ctx=nil)
                ApplicationObserver_mixin::OP_applicationInit.invokeAsync(self, _cb, [serial, applications], _ctx)
            end

            def applicationAdded(serial, desc, _ctx=nil)
                ApplicationObserver_mixin::OP_applicationAdded.invoke(self, [serial, desc], _ctx)
            end

            def applicationRemoved(serial, name, _ctx=nil)
                ApplicationObserver_mixin::OP_applicationRemoved.invoke(self, [serial, name], _ctx)
            end

            def applicationUpdated(serial, desc, _ctx=nil)
                ApplicationObserver_mixin::OP_applicationUpdated.invoke(self, [serial, desc], _ctx)
            end
        end
        class ApplicationObserverPrx < ::Ice::ObjectPrx
            include ApplicationObserverPrx_mixin

            def ApplicationObserverPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::ApplicationObserver', facetOrCtx, _ctx)
            end

            def ApplicationObserverPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_ApplicationObserver)
            T_ApplicationObserver = ::Ice::__declareClass('::IceGrid::ApplicationObserver')
            T_ApplicationObserverPrx = ::Ice::__declareProxy('::IceGrid::ApplicationObserver')
        end

        T_ApplicationObserver.defineClass(nil, true, nil, [], [])
        ApplicationObserver_mixin::ICE_TYPE = T_ApplicationObserver

        T_ApplicationObserverPrx.defineProxy(ApplicationObserverPrx, T_ApplicationObserver)
        ApplicationObserverPrx::ICE_TYPE = T_ApplicationObserverPrx

        ApplicationObserver_mixin::OP_applicationInit = ::Ice::__defineOperation('applicationInit', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_int, ::IceGrid::T_ApplicationInfoSeq], [], nil, [])
        ApplicationObserver_mixin::OP_applicationAdded = ::Ice::__defineOperation('applicationAdded', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_int, ::IceGrid::T_ApplicationInfo], [], nil, [])
        ApplicationObserver_mixin::OP_applicationRemoved = ::Ice::__defineOperation('applicationRemoved', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_int, ::Ice::T_string], [], nil, [])
        ApplicationObserver_mixin::OP_applicationUpdated = ::Ice::__defineOperation('applicationUpdated', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_int, ::IceGrid::T_ApplicationUpdateInfo], [], nil, [])
    end

    if not defined?(::IceGrid::AdapterObserver_mixin)
        module AdapterObserver_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::AdapterObserver']
            end

            def ice_id(current=nil)
                '::IceGrid::AdapterObserver'
            end

            #
            # Operation signatures.
            #
            # def adapterInit(adpts, current=nil)
            # def adapterAdded(info, current=nil)
            # def adapterUpdated(info, current=nil)
            # def adapterRemoved(id, current=nil)

            def inspect
                ::Ice::__stringify(self, T_AdapterObserver)
            end
        end
        module AdapterObserverPrx_mixin

            def adapterInit(adpts, _ctx=nil)
                AdapterObserver_mixin::OP_adapterInit.invoke(self, [adpts], _ctx)
            end

            def adapterInit_async(_cb, adpts, _ctx=nil)
                AdapterObserver_mixin::OP_adapterInit.invokeAsync(self, _cb, [adpts, ], _ctx)
            end

            def adapterAdded(info, _ctx=nil)
                AdapterObserver_mixin::OP_adapterAdded.invoke(self, [info], _ctx)
            end

            def adapterUpdated(info, _ctx=nil)
                AdapterObserver_mixin::OP_adapterUpdated.invoke(self, [info], _ctx)
            end

            def adapterRemoved(id, _ctx=nil)
                AdapterObserver_mixin::OP_adapterRemoved.invoke(self, [id], _ctx)
            end
        end
        class AdapterObserverPrx < ::Ice::ObjectPrx
            include AdapterObserverPrx_mixin

            def AdapterObserverPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::AdapterObserver', facetOrCtx, _ctx)
            end

            def AdapterObserverPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_AdapterObserver)
            T_AdapterObserver = ::Ice::__declareClass('::IceGrid::AdapterObserver')
            T_AdapterObserverPrx = ::Ice::__declareProxy('::IceGrid::AdapterObserver')
        end

        T_AdapterObserver.defineClass(nil, true, nil, [], [])
        AdapterObserver_mixin::ICE_TYPE = T_AdapterObserver

        T_AdapterObserverPrx.defineProxy(AdapterObserverPrx, T_AdapterObserver)
        AdapterObserverPrx::ICE_TYPE = T_AdapterObserverPrx

        AdapterObserver_mixin::OP_adapterInit = ::Ice::__defineOperation('adapterInit', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_AdapterInfoSeq], [], nil, [])
        AdapterObserver_mixin::OP_adapterAdded = ::Ice::__defineOperation('adapterAdded', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_AdapterInfo], [], nil, [])
        AdapterObserver_mixin::OP_adapterUpdated = ::Ice::__defineOperation('adapterUpdated', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_AdapterInfo], [], nil, [])
        AdapterObserver_mixin::OP_adapterRemoved = ::Ice::__defineOperation('adapterRemoved', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [])
    end

    if not defined?(::IceGrid::ObjectObserver_mixin)
        module ObjectObserver_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::ObjectObserver']
            end

            def ice_id(current=nil)
                '::IceGrid::ObjectObserver'
            end

            #
            # Operation signatures.
            #
            # def objectInit(objects, current=nil)
            # def objectAdded(info, current=nil)
            # def objectUpdated(info, current=nil)
            # def objectRemoved(id, current=nil)

            def inspect
                ::Ice::__stringify(self, T_ObjectObserver)
            end
        end
        module ObjectObserverPrx_mixin

            def objectInit(objects, _ctx=nil)
                ObjectObserver_mixin::OP_objectInit.invoke(self, [objects], _ctx)
            end

            def objectInit_async(_cb, objects, _ctx=nil)
                ObjectObserver_mixin::OP_objectInit.invokeAsync(self, _cb, [objects, ], _ctx)
            end

            def objectAdded(info, _ctx=nil)
                ObjectObserver_mixin::OP_objectAdded.invoke(self, [info], _ctx)
            end

            def objectUpdated(info, _ctx=nil)
                ObjectObserver_mixin::OP_objectUpdated.invoke(self, [info], _ctx)
            end

            def objectRemoved(id, _ctx=nil)
                ObjectObserver_mixin::OP_objectRemoved.invoke(self, [id], _ctx)
            end
        end
        class ObjectObserverPrx < ::Ice::ObjectPrx
            include ObjectObserverPrx_mixin

            def ObjectObserverPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::ObjectObserver', facetOrCtx, _ctx)
            end

            def ObjectObserverPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_ObjectObserver)
            T_ObjectObserver = ::Ice::__declareClass('::IceGrid::ObjectObserver')
            T_ObjectObserverPrx = ::Ice::__declareProxy('::IceGrid::ObjectObserver')
        end

        T_ObjectObserver.defineClass(nil, true, nil, [], [])
        ObjectObserver_mixin::ICE_TYPE = T_ObjectObserver

        T_ObjectObserverPrx.defineProxy(ObjectObserverPrx, T_ObjectObserver)
        ObjectObserverPrx::ICE_TYPE = T_ObjectObserverPrx

        ObjectObserver_mixin::OP_objectInit = ::Ice::__defineOperation('objectInit', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_ObjectInfoSeq], [], nil, [])
        ObjectObserver_mixin::OP_objectAdded = ::Ice::__defineOperation('objectAdded', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_ObjectInfo], [], nil, [])
        ObjectObserver_mixin::OP_objectUpdated = ::Ice::__defineOperation('objectUpdated', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_ObjectInfo], [], nil, [])
        ObjectObserver_mixin::OP_objectRemoved = ::Ice::__defineOperation('objectRemoved', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_Identity], [], nil, [])
    end

    if not defined?(::IceGrid::RegistryObserver_mixin)
        module RegistryObserver_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::RegistryObserver']
            end

            def ice_id(current=nil)
                '::IceGrid::RegistryObserver'
            end

            #
            # Operation signatures.
            #
            # def registryInit(registries, current=nil)
            # def registryUp(node, current=nil)
            # def registryDown(name, current=nil)

            def inspect
                ::Ice::__stringify(self, T_RegistryObserver)
            end
        end
        module RegistryObserverPrx_mixin

            def registryInit(registries, _ctx=nil)
                RegistryObserver_mixin::OP_registryInit.invoke(self, [registries], _ctx)
            end

            def registryInit_async(_cb, registries, _ctx=nil)
                RegistryObserver_mixin::OP_registryInit.invokeAsync(self, _cb, [registries, ], _ctx)
            end

            def registryUp(node, _ctx=nil)
                RegistryObserver_mixin::OP_registryUp.invoke(self, [node], _ctx)
            end

            def registryDown(name, _ctx=nil)
                RegistryObserver_mixin::OP_registryDown.invoke(self, [name], _ctx)
            end
        end
        class RegistryObserverPrx < ::Ice::ObjectPrx
            include RegistryObserverPrx_mixin

            def RegistryObserverPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::RegistryObserver', facetOrCtx, _ctx)
            end

            def RegistryObserverPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_RegistryObserver)
            T_RegistryObserver = ::Ice::__declareClass('::IceGrid::RegistryObserver')
            T_RegistryObserverPrx = ::Ice::__declareProxy('::IceGrid::RegistryObserver')
        end

        T_RegistryObserver.defineClass(nil, true, nil, [], [])
        RegistryObserver_mixin::ICE_TYPE = T_RegistryObserver

        T_RegistryObserverPrx.defineProxy(RegistryObserverPrx, T_RegistryObserver)
        RegistryObserverPrx::ICE_TYPE = T_RegistryObserverPrx

        RegistryObserver_mixin::OP_registryInit = ::Ice::__defineOperation('registryInit', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_RegistryInfoSeq], [], nil, [])
        RegistryObserver_mixin::OP_registryUp = ::Ice::__defineOperation('registryUp', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_RegistryInfo], [], nil, [])
        RegistryObserver_mixin::OP_registryDown = ::Ice::__defineOperation('registryDown', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [])
    end
end
