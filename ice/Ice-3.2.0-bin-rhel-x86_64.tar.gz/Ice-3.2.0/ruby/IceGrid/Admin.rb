# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Admin.ice'

require 'Ice'
require 'Ice/Identity.rb'
require 'Ice/BuiltinSequences.rb'
require 'Ice/SliceChecksumDict.rb'
require 'Glacier2/Session.rb'
require 'IceGrid/Exception.rb'
require 'IceGrid/Descriptor.rb'

module IceGrid

    if not defined?(::IceGrid::ServerState)
        class ServerState
            include Comparable

            def initialize(val)
                fail("invalid value #{val} for ServerState") unless(val >= 0 and val < 7)
                @val = val
            end

            def ServerState.from_int(val)
                raise IndexError, "#{val} is out of range 0..6" if(val < 0 || val > 6)
                @@_values[val]
            end

            def to_s
                @@_names[@val]
            end

            def to_i
                @val
            end

            def <=>(other)
                other.is_a?(ServerState) or raise ArgumentError, "value must be a ServerState"
                @val <=> other.to_i
            end

            def hash
                @val.hash
            end

            def inspect
                @@_names[@val] + "(#{@val})"
            end

            def ServerState.each(&block)
                @@_values.each(&block)
            end

            @@_names = ['Inactive', 'Activating', 'ActivationTimedOut', 'Active', 'Deactivating', 'Destroying', 'Destroyed']
            @@_values = [ServerState.new(0), ServerState.new(1), ServerState.new(2), ServerState.new(3), ServerState.new(4), ServerState.new(5), ServerState.new(6)]

            Inactive = @@_values[0]
            Activating = @@_values[1]
            ActivationTimedOut = @@_values[2]
            Active = @@_values[3]
            Deactivating = @@_values[4]
            Destroying = @@_values[5]
            Destroyed = @@_values[6]

            private_class_method :new
        end

        T_ServerState = ::Ice::__defineEnum('::IceGrid::ServerState', ServerState, [ServerState::Inactive, ServerState::Activating, ServerState::ActivationTimedOut, ServerState::Active, ServerState::Deactivating, ServerState::Destroying, ServerState::Destroyed])
    end

    if not defined?(::IceGrid::T_StringObjectProxyDict)
        T_StringObjectProxyDict = ::Ice::__defineDictionary('::IceGrid::StringObjectProxyDict', ::Ice::T_string, ::Ice::T_ObjectPrx)
    end

    if not defined?(::IceGrid::ObjectInfo)
        class ObjectInfo
            def initialize(proxy=nil, type='')
                @proxy = proxy
                @type = type
            end

            def hash
                _h = 0
                _h = 5 * _h + @proxy.hash
                _h = 5 * _h + @type.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @proxy != other.proxy or
                    @type != other.type
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ObjectInfo)
            end

            attr_accessor :proxy, :type
        end

        T_ObjectInfo = ::Ice::__defineStruct('::IceGrid::ObjectInfo', ObjectInfo, [
            ["proxy", ::Ice::T_ObjectPrx],
            ["type", ::Ice::T_string]
        ])
    end

    if not defined?(::IceGrid::T_ObjectInfoSeq)
        T_ObjectInfoSeq = ::Ice::__defineSequence('::IceGrid::ObjectInfoSeq', ::IceGrid::T_ObjectInfo)
    end

    if not defined?(::IceGrid::AdapterInfo)
        class AdapterInfo
            def initialize(id='', proxy=nil, replicaGroupId='')
                @id = id
                @proxy = proxy
                @replicaGroupId = replicaGroupId
            end

            def hash
                _h = 0
                _h = 5 * _h + @id.hash
                _h = 5 * _h + @proxy.hash
                _h = 5 * _h + @replicaGroupId.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @id != other.id or
                    @proxy != other.proxy or
                    @replicaGroupId != other.replicaGroupId
                true
            end

            def inspect
                ::Ice::__stringify(self, T_AdapterInfo)
            end

            attr_accessor :id, :proxy, :replicaGroupId
        end

        T_AdapterInfo = ::Ice::__defineStruct('::IceGrid::AdapterInfo', AdapterInfo, [
            ["id", ::Ice::T_string],
            ["proxy", ::Ice::T_ObjectPrx],
            ["replicaGroupId", ::Ice::T_string]
        ])
    end

    if not defined?(::IceGrid::T_AdapterInfoSeq)
        T_AdapterInfoSeq = ::Ice::__defineSequence('::IceGrid::AdapterInfoSeq', ::IceGrid::T_AdapterInfo)
    end

    if not defined?(::IceGrid::ServerInfo)
        class ServerInfo
            def initialize(application='', uuid='', revision=0, node='', descriptor=nil, sessionId='')
                @application = application
                @uuid = uuid
                @revision = revision
                @node = node
                @descriptor = descriptor
                @sessionId = sessionId
            end

            def hash
                _h = 0
                _h = 5 * _h + @application.hash
                _h = 5 * _h + @uuid.hash
                _h = 5 * _h + @revision.hash
                _h = 5 * _h + @node.hash
                _h = 5 * _h + @descriptor.hash
                _h = 5 * _h + @sessionId.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @application != other.application or
                    @uuid != other.uuid or
                    @revision != other.revision or
                    @node != other.node or
                    @descriptor != other.descriptor or
                    @sessionId != other.sessionId
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ServerInfo)
            end

            attr_accessor :application, :uuid, :revision, :node, :descriptor, :sessionId
        end

        T_ServerInfo = ::Ice::__defineStruct('::IceGrid::ServerInfo', ServerInfo, [
            ["application", ::Ice::T_string],
            ["uuid", ::Ice::T_string],
            ["revision", ::Ice::T_int],
            ["node", ::Ice::T_string],
            ["descriptor", ::IceGrid::T_ServerDescriptor],
            ["sessionId", ::Ice::T_string]
        ])
    end

    if not defined?(::IceGrid::NodeInfo)
        class NodeInfo
            def initialize(name='', os='', hostname='', release='', version='', machine='', nProcessors=0, dataDir='')
                @name = name
                @os = os
                @hostname = hostname
                @release = release
                @version = version
                @machine = machine
                @nProcessors = nProcessors
                @dataDir = dataDir
            end

            def hash
                _h = 0
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @os.hash
                _h = 5 * _h + @hostname.hash
                _h = 5 * _h + @release.hash
                _h = 5 * _h + @version.hash
                _h = 5 * _h + @machine.hash
                _h = 5 * _h + @nProcessors.hash
                _h = 5 * _h + @dataDir.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @name != other.name or
                    @os != other.os or
                    @hostname != other.hostname or
                    @release != other.release or
                    @version != other.version or
                    @machine != other.machine or
                    @nProcessors != other.nProcessors or
                    @dataDir != other.dataDir
                true
            end

            def inspect
                ::Ice::__stringify(self, T_NodeInfo)
            end

            attr_accessor :name, :os, :hostname, :release, :version, :machine, :nProcessors, :dataDir
        end

        T_NodeInfo = ::Ice::__defineStruct('::IceGrid::NodeInfo', NodeInfo, [
            ["name", ::Ice::T_string],
            ["os", ::Ice::T_string],
            ["hostname", ::Ice::T_string],
            ["release", ::Ice::T_string],
            ["version", ::Ice::T_string],
            ["machine", ::Ice::T_string],
            ["nProcessors", ::Ice::T_int],
            ["dataDir", ::Ice::T_string]
        ])
    end

    if not defined?(::IceGrid::RegistryInfo)
        class RegistryInfo
            def initialize(name='', hostname='')
                @name = name
                @hostname = hostname
            end

            def hash
                _h = 0
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @hostname.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @name != other.name or
                    @hostname != other.hostname
                true
            end

            def inspect
                ::Ice::__stringify(self, T_RegistryInfo)
            end

            attr_accessor :name, :hostname
        end

        T_RegistryInfo = ::Ice::__defineStruct('::IceGrid::RegistryInfo', RegistryInfo, [
            ["name", ::Ice::T_string],
            ["hostname", ::Ice::T_string]
        ])
    end

    if not defined?(::IceGrid::T_RegistryInfoSeq)
        T_RegistryInfoSeq = ::Ice::__defineSequence('::IceGrid::RegistryInfoSeq', ::IceGrid::T_RegistryInfo)
    end

    if not defined?(::IceGrid::LoadInfo)
        class LoadInfo
            def initialize(avg1=0.0, avg5=0.0, avg15=0.0)
                @avg1 = avg1
                @avg5 = avg5
                @avg15 = avg15
            end

            def hash
                _h = 0
                _h = 5 * _h + @avg1.hash
                _h = 5 * _h + @avg5.hash
                _h = 5 * _h + @avg15.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @avg1 != other.avg1 or
                    @avg5 != other.avg5 or
                    @avg15 != other.avg15
                true
            end

            def inspect
                ::Ice::__stringify(self, T_LoadInfo)
            end

            attr_accessor :avg1, :avg5, :avg15
        end

        T_LoadInfo = ::Ice::__defineStruct('::IceGrid::LoadInfo', LoadInfo, [
            ["avg1", ::Ice::T_float],
            ["avg5", ::Ice::T_float],
            ["avg15", ::Ice::T_float]
        ])
    end

    if not defined?(::IceGrid::ApplicationInfo)
        class ApplicationInfo
            def initialize(uuid='', createTime=0, createUser='', updateTime=0, updateUser='', revision=0, descriptor=::IceGrid::ApplicationDescriptor.new)
                @uuid = uuid
                @createTime = createTime
                @createUser = createUser
                @updateTime = updateTime
                @updateUser = updateUser
                @revision = revision
                @descriptor = descriptor
            end

            def hash
                _h = 0
                _h = 5 * _h + @uuid.hash
                _h = 5 * _h + @createTime.hash
                _h = 5 * _h + @createUser.hash
                _h = 5 * _h + @updateTime.hash
                _h = 5 * _h + @updateUser.hash
                _h = 5 * _h + @revision.hash
                _h = 5 * _h + @descriptor.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @uuid != other.uuid or
                    @createTime != other.createTime or
                    @createUser != other.createUser or
                    @updateTime != other.updateTime or
                    @updateUser != other.updateUser or
                    @revision != other.revision or
                    @descriptor != other.descriptor
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ApplicationInfo)
            end

            attr_accessor :uuid, :createTime, :createUser, :updateTime, :updateUser, :revision, :descriptor
        end

        T_ApplicationInfo = ::Ice::__defineStruct('::IceGrid::ApplicationInfo', ApplicationInfo, [
            ["uuid", ::Ice::T_string],
            ["createTime", ::Ice::T_long],
            ["createUser", ::Ice::T_string],
            ["updateTime", ::Ice::T_long],
            ["updateUser", ::Ice::T_string],
            ["revision", ::Ice::T_int],
            ["descriptor", ::IceGrid::T_ApplicationDescriptor]
        ])
    end

    if not defined?(::IceGrid::T_ApplicationInfoSeq)
        T_ApplicationInfoSeq = ::Ice::__defineSequence('::IceGrid::ApplicationInfoSeq', ::IceGrid::T_ApplicationInfo)
    end

    if not defined?(::IceGrid::ApplicationUpdateInfo)
        class ApplicationUpdateInfo
            def initialize(updateTime=0, updateUser='', revision=0, descriptor=::IceGrid::ApplicationUpdateDescriptor.new)
                @updateTime = updateTime
                @updateUser = updateUser
                @revision = revision
                @descriptor = descriptor
            end

            def hash
                _h = 0
                _h = 5 * _h + @updateTime.hash
                _h = 5 * _h + @updateUser.hash
                _h = 5 * _h + @revision.hash
                _h = 5 * _h + @descriptor.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @updateTime != other.updateTime or
                    @updateUser != other.updateUser or
                    @revision != other.revision or
                    @descriptor != other.descriptor
                true
            end

            def inspect
                ::Ice::__stringify(self, T_ApplicationUpdateInfo)
            end

            attr_accessor :updateTime, :updateUser, :revision, :descriptor
        end

        T_ApplicationUpdateInfo = ::Ice::__defineStruct('::IceGrid::ApplicationUpdateInfo', ApplicationUpdateInfo, [
            ["updateTime", ::Ice::T_long],
            ["updateUser", ::Ice::T_string],
            ["revision", ::Ice::T_int],
            ["descriptor", ::IceGrid::T_ApplicationUpdateDescriptor]
        ])
    end

    if not defined?(::IceGrid::Admin_mixin)
        module Admin_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::Admin']
            end

            def ice_id(current=nil)
                '::IceGrid::Admin'
            end

            #
            # Operation signatures.
            #
            # def addApplication(descriptor, current=nil)
            # def syncApplication(descriptor, current=nil)
            # def updateApplication(descriptor, current=nil)
            # def removeApplication(name, current=nil)
            # def instantiateServer(application, node, desc, current=nil)
            # def patchApplication(name, shutdown, current=nil)
            # def getApplicationInfo(name, current=nil)
            # def getDefaultApplicationDescriptor(current=nil)
            # def getAllApplicationNames(current=nil)
            # def getServerInfo(id, current=nil)
            # def getServerState(id, current=nil)
            # def getServerPid(id, current=nil)
            # def enableServer(id, enabled, current=nil)
            # def isServerEnabled(id, current=nil)
            # def startServer(id, current=nil)
            # def stopServer(id, current=nil)
            # def patchServer(id, shutdown, current=nil)
            # def sendSignal(id, signal, current=nil)
            # def writeMessage(id, message, fd, current=nil)
            # def getAllServerIds(current=nil)
            # def getAdapterInfo(id, current=nil)
            # def removeAdapter(adapterId, current=nil)
            # def getAllAdapterIds(current=nil)
            # def addObject(obj, current=nil)
            # def updateObject(obj, current=nil)
            # def addObjectWithType(obj, type, current=nil)
            # def removeObject(id, current=nil)
            # def getObjectInfo(id, current=nil)
            # def getObjectInfosByType(type, current=nil)
            # def getAllObjectInfos(expr, current=nil)
            # def pingNode(name, current=nil)
            # def getNodeLoad(name, current=nil)
            # def getNodeInfo(name, current=nil)
            # def shutdownNode(name, current=nil)
            # def getNodeHostname(name, current=nil)
            # def getAllNodeNames(current=nil)
            # def pingRegistry(name, current=nil)
            # def getRegistryInfo(name, current=nil)
            # def shutdownRegistry(name, current=nil)
            # def getAllRegistryNames(current=nil)
            # def shutdown(current=nil)
            # def getSliceChecksums(current=nil)

            def inspect
                ::Ice::__stringify(self, T_Admin)
            end
        end
        module AdminPrx_mixin

            def addApplication(descriptor, _ctx=nil)
                Admin_mixin::OP_addApplication.invoke(self, [descriptor], _ctx)
            end

            def addApplication_async(_cb, descriptor, _ctx=nil)
                Admin_mixin::OP_addApplication.invokeAsync(self, _cb, [descriptor, ], _ctx)
            end

            def syncApplication(descriptor, _ctx=nil)
                Admin_mixin::OP_syncApplication.invoke(self, [descriptor], _ctx)
            end

            def syncApplication_async(_cb, descriptor, _ctx=nil)
                Admin_mixin::OP_syncApplication.invokeAsync(self, _cb, [descriptor, ], _ctx)
            end

            def updateApplication(descriptor, _ctx=nil)
                Admin_mixin::OP_updateApplication.invoke(self, [descriptor], _ctx)
            end

            def updateApplication_async(_cb, descriptor, _ctx=nil)
                Admin_mixin::OP_updateApplication.invokeAsync(self, _cb, [descriptor, ], _ctx)
            end

            def removeApplication(name, _ctx=nil)
                Admin_mixin::OP_removeApplication.invoke(self, [name], _ctx)
            end

            def removeApplication_async(_cb, name, _ctx=nil)
                Admin_mixin::OP_removeApplication.invokeAsync(self, _cb, [name, ], _ctx)
            end

            def instantiateServer(application, node, desc, _ctx=nil)
                Admin_mixin::OP_instantiateServer.invoke(self, [application, node, desc], _ctx)
            end

            def patchApplication(name, shutdown, _ctx=nil)
                Admin_mixin::OP_patchApplication.invoke(self, [name, shutdown], _ctx)
            end

            def patchApplication_async(_cb, name, shutdown, _ctx=nil)
                Admin_mixin::OP_patchApplication.invokeAsync(self, _cb, [name, shutdown], _ctx)
            end

            def getApplicationInfo(name, _ctx=nil)
                Admin_mixin::OP_getApplicationInfo.invoke(self, [name], _ctx)
            end

            def getDefaultApplicationDescriptor(_ctx=nil)
                Admin_mixin::OP_getDefaultApplicationDescriptor.invoke(self, [], _ctx)
            end

            def getAllApplicationNames(_ctx=nil)
                Admin_mixin::OP_getAllApplicationNames.invoke(self, [], _ctx)
            end

            def getServerInfo(id, _ctx=nil)
                Admin_mixin::OP_getServerInfo.invoke(self, [id], _ctx)
            end

            def getServerState(id, _ctx=nil)
                Admin_mixin::OP_getServerState.invoke(self, [id], _ctx)
            end

            def getServerPid(id, _ctx=nil)
                Admin_mixin::OP_getServerPid.invoke(self, [id], _ctx)
            end

            def enableServer(id, enabled, _ctx=nil)
                Admin_mixin::OP_enableServer.invoke(self, [id, enabled], _ctx)
            end

            def enableServer_async(_cb, id, enabled, _ctx=nil)
                Admin_mixin::OP_enableServer.invokeAsync(self, _cb, [id, enabled], _ctx)
            end

            def isServerEnabled(id, _ctx=nil)
                Admin_mixin::OP_isServerEnabled.invoke(self, [id], _ctx)
            end

            def startServer(id, _ctx=nil)
                Admin_mixin::OP_startServer.invoke(self, [id], _ctx)
            end

            def startServer_async(_cb, id, _ctx=nil)
                Admin_mixin::OP_startServer.invokeAsync(self, _cb, [id, ], _ctx)
            end

            def stopServer(id, _ctx=nil)
                Admin_mixin::OP_stopServer.invoke(self, [id], _ctx)
            end

            def stopServer_async(_cb, id, _ctx=nil)
                Admin_mixin::OP_stopServer.invokeAsync(self, _cb, [id, ], _ctx)
            end

            def patchServer(id, shutdown, _ctx=nil)
                Admin_mixin::OP_patchServer.invoke(self, [id, shutdown], _ctx)
            end

            def patchServer_async(_cb, id, shutdown, _ctx=nil)
                Admin_mixin::OP_patchServer.invokeAsync(self, _cb, [id, shutdown], _ctx)
            end

            def sendSignal(id, signal, _ctx=nil)
                Admin_mixin::OP_sendSignal.invoke(self, [id, signal], _ctx)
            end

            def sendSignal_async(_cb, id, signal, _ctx=nil)
                Admin_mixin::OP_sendSignal.invokeAsync(self, _cb, [id, signal], _ctx)
            end

            def writeMessage(id, message, fd, _ctx=nil)
                Admin_mixin::OP_writeMessage.invoke(self, [id, message, fd], _ctx)
            end

            def writeMessage_async(_cb, id, message, fd, _ctx=nil)
                Admin_mixin::OP_writeMessage.invokeAsync(self, _cb, [id, message, fd], _ctx)
            end

            def getAllServerIds(_ctx=nil)
                Admin_mixin::OP_getAllServerIds.invoke(self, [], _ctx)
            end

            def getAdapterInfo(id, _ctx=nil)
                Admin_mixin::OP_getAdapterInfo.invoke(self, [id], _ctx)
            end

            def removeAdapter(adapterId, _ctx=nil)
                Admin_mixin::OP_removeAdapter.invoke(self, [adapterId], _ctx)
            end

            def removeAdapter_async(_cb, adapterId, _ctx=nil)
                Admin_mixin::OP_removeAdapter.invokeAsync(self, _cb, [adapterId, ], _ctx)
            end

            def getAllAdapterIds(_ctx=nil)
                Admin_mixin::OP_getAllAdapterIds.invoke(self, [], _ctx)
            end

            def addObject(obj, _ctx=nil)
                Admin_mixin::OP_addObject.invoke(self, [obj], _ctx)
            end

            def addObject_async(_cb, obj, _ctx=nil)
                Admin_mixin::OP_addObject.invokeAsync(self, _cb, [obj, ], _ctx)
            end

            def updateObject(obj, _ctx=nil)
                Admin_mixin::OP_updateObject.invoke(self, [obj], _ctx)
            end

            def addObjectWithType(obj, type, _ctx=nil)
                Admin_mixin::OP_addObjectWithType.invoke(self, [obj, type], _ctx)
            end

            def addObjectWithType_async(_cb, obj, type, _ctx=nil)
                Admin_mixin::OP_addObjectWithType.invokeAsync(self, _cb, [obj, type], _ctx)
            end

            def removeObject(id, _ctx=nil)
                Admin_mixin::OP_removeObject.invoke(self, [id], _ctx)
            end

            def removeObject_async(_cb, id, _ctx=nil)
                Admin_mixin::OP_removeObject.invokeAsync(self, _cb, [id, ], _ctx)
            end

            def getObjectInfo(id, _ctx=nil)
                Admin_mixin::OP_getObjectInfo.invoke(self, [id], _ctx)
            end

            def getObjectInfosByType(type, _ctx=nil)
                Admin_mixin::OP_getObjectInfosByType.invoke(self, [type], _ctx)
            end

            def getAllObjectInfos(expr, _ctx=nil)
                Admin_mixin::OP_getAllObjectInfos.invoke(self, [expr], _ctx)
            end

            def pingNode(name, _ctx=nil)
                Admin_mixin::OP_pingNode.invoke(self, [name], _ctx)
            end

            def getNodeLoad(name, _ctx=nil)
                Admin_mixin::OP_getNodeLoad.invoke(self, [name], _ctx)
            end

            def getNodeLoad_async(_cb, name, _ctx=nil)
                Admin_mixin::OP_getNodeLoad.invokeAsync(self, _cb, [name, ], _ctx)
            end

            def getNodeInfo(name, _ctx=nil)
                Admin_mixin::OP_getNodeInfo.invoke(self, [name], _ctx)
            end

            def shutdownNode(name, _ctx=nil)
                Admin_mixin::OP_shutdownNode.invoke(self, [name], _ctx)
            end

            def shutdownNode_async(_cb, name, _ctx=nil)
                Admin_mixin::OP_shutdownNode.invokeAsync(self, _cb, [name, ], _ctx)
            end

            def getNodeHostname(name, _ctx=nil)
                Admin_mixin::OP_getNodeHostname.invoke(self, [name], _ctx)
            end

            def getAllNodeNames(_ctx=nil)
                Admin_mixin::OP_getAllNodeNames.invoke(self, [], _ctx)
            end

            def pingRegistry(name, _ctx=nil)
                Admin_mixin::OP_pingRegistry.invoke(self, [name], _ctx)
            end

            def getRegistryInfo(name, _ctx=nil)
                Admin_mixin::OP_getRegistryInfo.invoke(self, [name], _ctx)
            end

            def shutdownRegistry(name, _ctx=nil)
                Admin_mixin::OP_shutdownRegistry.invoke(self, [name], _ctx)
            end

            def shutdownRegistry_async(_cb, name, _ctx=nil)
                Admin_mixin::OP_shutdownRegistry.invokeAsync(self, _cb, [name, ], _ctx)
            end

            def getAllRegistryNames(_ctx=nil)
                Admin_mixin::OP_getAllRegistryNames.invoke(self, [], _ctx)
            end

            def shutdown(_ctx=nil)
                Admin_mixin::OP_shutdown.invoke(self, [], _ctx)
            end

            def getSliceChecksums(_ctx=nil)
                Admin_mixin::OP_getSliceChecksums.invoke(self, [], _ctx)
            end
        end
        class AdminPrx < ::Ice::ObjectPrx
            include AdminPrx_mixin

            def AdminPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::Admin', facetOrCtx, _ctx)
            end

            def AdminPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_Admin)
            T_Admin = ::Ice::__declareClass('::IceGrid::Admin')
            T_AdminPrx = ::Ice::__declareProxy('::IceGrid::Admin')
        end

        T_Admin.defineClass(nil, true, nil, [], [])
        Admin_mixin::ICE_TYPE = T_Admin

        T_AdminPrx.defineProxy(AdminPrx, T_Admin)
        AdminPrx::ICE_TYPE = T_AdminPrx

        Admin_mixin::OP_addApplication = ::Ice::__defineOperation('addApplication', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_ApplicationDescriptor], [], nil, [::IceGrid::T_AccessDeniedException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_syncApplication = ::Ice::__defineOperation('syncApplication', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_ApplicationDescriptor], [], nil, [::IceGrid::T_AccessDeniedException, ::IceGrid::T_DeploymentException, ::IceGrid::T_ApplicationNotExistException])
        Admin_mixin::OP_updateApplication = ::Ice::__defineOperation('updateApplication', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceGrid::T_ApplicationUpdateDescriptor], [], nil, [::IceGrid::T_AccessDeniedException, ::IceGrid::T_DeploymentException, ::IceGrid::T_ApplicationNotExistException])
        Admin_mixin::OP_removeApplication = ::Ice::__defineOperation('removeApplication', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [::IceGrid::T_AccessDeniedException, ::IceGrid::T_DeploymentException, ::IceGrid::T_ApplicationNotExistException])
        Admin_mixin::OP_instantiateServer = ::Ice::__defineOperation('instantiateServer', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_string, ::IceGrid::T_ServerInstanceDescriptor], [], nil, [::IceGrid::T_AccessDeniedException, ::IceGrid::T_ApplicationNotExistException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_patchApplication = ::Ice::__defineOperation('patchApplication', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, true, [::Ice::T_string, ::Ice::T_bool], [], nil, [::IceGrid::T_ApplicationNotExistException, ::IceGrid::T_PatchException])
        Admin_mixin::OP_getApplicationInfo = ::Ice::__defineOperation('getApplicationInfo', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::IceGrid::T_ApplicationInfo, [::IceGrid::T_ApplicationNotExistException])
        Admin_mixin::OP_getDefaultApplicationDescriptor = ::Ice::__defineOperation('getDefaultApplicationDescriptor', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::IceGrid::T_ApplicationDescriptor, [::IceGrid::T_DeploymentException])
        Admin_mixin::OP_getAllApplicationNames = ::Ice::__defineOperation('getAllApplicationNames', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_StringSeq, [])
        Admin_mixin::OP_getServerInfo = ::Ice::__defineOperation('getServerInfo', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::IceGrid::T_ServerInfo, [::IceGrid::T_ServerNotExistException])
        Admin_mixin::OP_getServerState = ::Ice::__defineOperation('getServerState', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::IceGrid::T_ServerState, [::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_getServerPid = ::Ice::__defineOperation('getServerPid', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::Ice::T_int, [::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_enableServer = ::Ice::__defineOperation('enableServer', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_string, ::Ice::T_bool], [], nil, [::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_isServerEnabled = ::Ice::__defineOperation('isServerEnabled', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::Ice::T_bool, [::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_startServer = ::Ice::__defineOperation('startServer', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [::IceGrid::T_ServerNotExistException, ::IceGrid::T_ServerStartException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_stopServer = ::Ice::__defineOperation('stopServer', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [::IceGrid::T_ServerNotExistException, ::IceGrid::T_ServerStopException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_patchServer = ::Ice::__defineOperation('patchServer', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, true, [::Ice::T_string, ::Ice::T_bool], [], nil, [::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException, ::IceGrid::T_PatchException])
        Admin_mixin::OP_sendSignal = ::Ice::__defineOperation('sendSignal', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_string], [], nil, [::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException, ::IceGrid::T_BadSignalException])
        Admin_mixin::OP_writeMessage = ::Ice::__defineOperation('writeMessage', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_string, ::Ice::T_int], [], nil, [::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_getAllServerIds = ::Ice::__defineOperation('getAllServerIds', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_StringSeq, [])
        Admin_mixin::OP_getAdapterInfo = ::Ice::__defineOperation('getAdapterInfo', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::IceGrid::T_AdapterInfoSeq, [::IceGrid::T_AdapterNotExistException])
        Admin_mixin::OP_removeAdapter = ::Ice::__defineOperation('removeAdapter', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [::IceGrid::T_AdapterNotExistException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_getAllAdapterIds = ::Ice::__defineOperation('getAllAdapterIds', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_StringSeq, [])
        Admin_mixin::OP_addObject = ::Ice::__defineOperation('addObject', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_ObjectPrx], [], nil, [::IceGrid::T_ObjectExistsException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_updateObject = ::Ice::__defineOperation('updateObject', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_ObjectPrx], [], nil, [::IceGrid::T_ObjectNotRegisteredException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_addObjectWithType = ::Ice::__defineOperation('addObjectWithType', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_ObjectPrx, ::Ice::T_string], [], nil, [::IceGrid::T_ObjectExistsException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_removeObject = ::Ice::__defineOperation('removeObject', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_Identity], [], nil, [::IceGrid::T_ObjectNotRegisteredException, ::IceGrid::T_DeploymentException])
        Admin_mixin::OP_getObjectInfo = ::Ice::__defineOperation('getObjectInfo', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_Identity], [], ::IceGrid::T_ObjectInfo, [::IceGrid::T_ObjectNotRegisteredException])
        Admin_mixin::OP_getObjectInfosByType = ::Ice::__defineOperation('getObjectInfosByType', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::IceGrid::T_ObjectInfoSeq, [])
        Admin_mixin::OP_getAllObjectInfos = ::Ice::__defineOperation('getAllObjectInfos', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::IceGrid::T_ObjectInfoSeq, [])
        Admin_mixin::OP_pingNode = ::Ice::__defineOperation('pingNode', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::Ice::T_bool, [::IceGrid::T_NodeNotExistException])
        Admin_mixin::OP_getNodeLoad = ::Ice::__defineOperation('getNodeLoad', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::IceGrid::T_LoadInfo, [::IceGrid::T_NodeNotExistException, ::IceGrid::T_NodeUnreachableException])
        Admin_mixin::OP_getNodeInfo = ::Ice::__defineOperation('getNodeInfo', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::IceGrid::T_NodeInfo, [::IceGrid::T_NodeNotExistException, ::IceGrid::T_NodeUnreachableException])
        Admin_mixin::OP_shutdownNode = ::Ice::__defineOperation('shutdownNode', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [::IceGrid::T_NodeNotExistException, ::IceGrid::T_NodeUnreachableException])
        Admin_mixin::OP_getNodeHostname = ::Ice::__defineOperation('getNodeHostname', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::Ice::T_string, [::IceGrid::T_NodeNotExistException, ::IceGrid::T_NodeUnreachableException])
        Admin_mixin::OP_getAllNodeNames = ::Ice::__defineOperation('getAllNodeNames', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_StringSeq, [])
        Admin_mixin::OP_pingRegistry = ::Ice::__defineOperation('pingRegistry', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_string], [], ::Ice::T_bool, [::IceGrid::T_RegistryNotExistException])
        Admin_mixin::OP_getRegistryInfo = ::Ice::__defineOperation('getRegistryInfo', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_string], [], ::IceGrid::T_RegistryInfo, [::IceGrid::T_RegistryNotExistException, ::IceGrid::T_RegistryUnreachableException])
        Admin_mixin::OP_shutdownRegistry = ::Ice::__defineOperation('shutdownRegistry', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_string], [], nil, [::IceGrid::T_RegistryNotExistException, ::IceGrid::T_RegistryUnreachableException])
        Admin_mixin::OP_getAllRegistryNames = ::Ice::__defineOperation('getAllRegistryNames', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [], [], ::Ice::T_StringSeq, [])
        Admin_mixin::OP_shutdown = ::Ice::__defineOperation('shutdown', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [])
        Admin_mixin::OP_getSliceChecksums = ::Ice::__defineOperation('getSliceChecksums', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_SliceChecksumDict, [])
    end

    if not defined?(::IceGrid::FileIterator_mixin)
        module FileIterator_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::FileIterator']
            end

            def ice_id(current=nil)
                '::IceGrid::FileIterator'
            end

            #
            # Operation signatures.
            #
            # def read(size, current=nil)
            # def destroy(current=nil)

            def inspect
                ::Ice::__stringify(self, T_FileIterator)
            end
        end
        module FileIteratorPrx_mixin

            def read(size, _ctx=nil)
                FileIterator_mixin::OP_read.invoke(self, [size], _ctx)
            end

            def destroy(_ctx=nil)
                FileIterator_mixin::OP_destroy.invoke(self, [], _ctx)
            end
        end
        class FileIteratorPrx < ::Ice::ObjectPrx
            include FileIteratorPrx_mixin

            def FileIteratorPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::FileIterator', facetOrCtx, _ctx)
            end

            def FileIteratorPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_FileIterator)
            T_FileIterator = ::Ice::__declareClass('::IceGrid::FileIterator')
            T_FileIteratorPrx = ::Ice::__declareProxy('::IceGrid::FileIterator')
        end

        T_FileIterator.defineClass(nil, true, nil, [], [])
        FileIterator_mixin::ICE_TYPE = T_FileIterator

        T_FileIteratorPrx.defineProxy(FileIteratorPrx, T_FileIterator)
        FileIteratorPrx::ICE_TYPE = T_FileIteratorPrx

        FileIterator_mixin::OP_read = ::Ice::__defineOperation('read', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_int], [::Ice::T_StringSeq], ::Ice::T_bool, [::IceGrid::T_FileNotAvailableException])
        FileIterator_mixin::OP_destroy = ::Ice::__defineOperation('destroy', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [])
    end

    if not defined?(::IceGrid::T_RegistryObserver)
        T_RegistryObserver = ::Ice::__declareClass('::IceGrid::RegistryObserver')
        T_RegistryObserverPrx = ::Ice::__declareProxy('::IceGrid::RegistryObserver')
    end

    if not defined?(::IceGrid::T_NodeObserver)
        T_NodeObserver = ::Ice::__declareClass('::IceGrid::NodeObserver')
        T_NodeObserverPrx = ::Ice::__declareProxy('::IceGrid::NodeObserver')
    end

    if not defined?(::IceGrid::T_ApplicationObserver)
        T_ApplicationObserver = ::Ice::__declareClass('::IceGrid::ApplicationObserver')
        T_ApplicationObserverPrx = ::Ice::__declareProxy('::IceGrid::ApplicationObserver')
    end

    if not defined?(::IceGrid::T_AdapterObserver)
        T_AdapterObserver = ::Ice::__declareClass('::IceGrid::AdapterObserver')
        T_AdapterObserverPrx = ::Ice::__declareProxy('::IceGrid::AdapterObserver')
    end

    if not defined?(::IceGrid::T_ObjectObserver)
        T_ObjectObserver = ::Ice::__declareClass('::IceGrid::ObjectObserver')
        T_ObjectObserverPrx = ::Ice::__declareProxy('::IceGrid::ObjectObserver')
    end

    if not defined?(::IceGrid::AdminSession_mixin)
        module AdminSession_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::Session', '::Ice::Object', '::IceGrid::AdminSession']
            end

            def ice_id(current=nil)
                '::IceGrid::AdminSession'
            end

            #
            # Operation signatures.
            #
            # def keepAlive(current=nil)
            # def getAdmin(current=nil)
            # def setObservers(registryObs, nodeObs, appObs, adptObs, objObs, current=nil)
            # def setObserversByIdentity(registryObs, nodeObs, appObs, adptObs, objObs, current=nil)
            # def startUpdate(current=nil)
            # def finishUpdate(current=nil)
            # def getReplicaName(current=nil)
            # def openServerLog(id, path, count, current=nil)
            # def openServerStdErr(id, count, current=nil)
            # def openServerStdOut(id, count, current=nil)
            # def openNodeStdErr(name, count, current=nil)
            # def openNodeStdOut(name, count, current=nil)
            # def openRegistryStdErr(name, count, current=nil)
            # def openRegistryStdOut(name, count, current=nil)

            def inspect
                ::Ice::__stringify(self, T_AdminSession)
            end
        end
        module AdminSessionPrx_mixin
            include ::Glacier2::SessionPrx_mixin

            def keepAlive(_ctx=nil)
                AdminSession_mixin::OP_keepAlive.invoke(self, [], _ctx)
            end

            def getAdmin(_ctx=nil)
                AdminSession_mixin::OP_getAdmin.invoke(self, [], _ctx)
            end

            def setObservers(registryObs, nodeObs, appObs, adptObs, objObs, _ctx=nil)
                AdminSession_mixin::OP_setObservers.invoke(self, [registryObs, nodeObs, appObs, adptObs, objObs], _ctx)
            end

            def setObserversByIdentity(registryObs, nodeObs, appObs, adptObs, objObs, _ctx=nil)
                AdminSession_mixin::OP_setObserversByIdentity.invoke(self, [registryObs, nodeObs, appObs, adptObs, objObs], _ctx)
            end

            def startUpdate(_ctx=nil)
                AdminSession_mixin::OP_startUpdate.invoke(self, [], _ctx)
            end

            def finishUpdate(_ctx=nil)
                AdminSession_mixin::OP_finishUpdate.invoke(self, [], _ctx)
            end

            def getReplicaName(_ctx=nil)
                AdminSession_mixin::OP_getReplicaName.invoke(self, [], _ctx)
            end

            def openServerLog(id, path, count, _ctx=nil)
                AdminSession_mixin::OP_openServerLog.invoke(self, [id, path, count], _ctx)
            end

            def openServerStdErr(id, count, _ctx=nil)
                AdminSession_mixin::OP_openServerStdErr.invoke(self, [id, count], _ctx)
            end

            def openServerStdOut(id, count, _ctx=nil)
                AdminSession_mixin::OP_openServerStdOut.invoke(self, [id, count], _ctx)
            end

            def openNodeStdErr(name, count, _ctx=nil)
                AdminSession_mixin::OP_openNodeStdErr.invoke(self, [name, count], _ctx)
            end

            def openNodeStdOut(name, count, _ctx=nil)
                AdminSession_mixin::OP_openNodeStdOut.invoke(self, [name, count], _ctx)
            end

            def openRegistryStdErr(name, count, _ctx=nil)
                AdminSession_mixin::OP_openRegistryStdErr.invoke(self, [name, count], _ctx)
            end

            def openRegistryStdOut(name, count, _ctx=nil)
                AdminSession_mixin::OP_openRegistryStdOut.invoke(self, [name, count], _ctx)
            end
        end
        class AdminSessionPrx < ::Ice::ObjectPrx
            include AdminSessionPrx_mixin

            def AdminSessionPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::AdminSession', facetOrCtx, _ctx)
            end

            def AdminSessionPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_AdminSession)
            T_AdminSession = ::Ice::__declareClass('::IceGrid::AdminSession')
            T_AdminSessionPrx = ::Ice::__declareProxy('::IceGrid::AdminSession')
        end

        T_AdminSession.defineClass(nil, true, nil, [::Glacier2::T_Session], [])
        AdminSession_mixin::ICE_TYPE = T_AdminSession

        T_AdminSessionPrx.defineProxy(AdminSessionPrx, T_AdminSession)
        AdminSessionPrx::ICE_TYPE = T_AdminSessionPrx

        AdminSession_mixin::OP_keepAlive = ::Ice::__defineOperation('keepAlive', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [], [], nil, [])
        AdminSession_mixin::OP_getAdmin = ::Ice::__defineOperation('getAdmin', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::IceGrid::T_AdminPrx, [])
        AdminSession_mixin::OP_setObservers = ::Ice::__defineOperation('setObservers', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::IceGrid::T_RegistryObserverPrx, ::IceGrid::T_NodeObserverPrx, ::IceGrid::T_ApplicationObserverPrx, ::IceGrid::T_AdapterObserverPrx, ::IceGrid::T_ObjectObserverPrx], [], nil, [::IceGrid::T_ObserverAlreadyRegisteredException])
        AdminSession_mixin::OP_setObserversByIdentity = ::Ice::__defineOperation('setObserversByIdentity', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_Identity, ::Ice::T_Identity, ::Ice::T_Identity, ::Ice::T_Identity, ::Ice::T_Identity], [], nil, [::IceGrid::T_ObserverAlreadyRegisteredException])
        AdminSession_mixin::OP_startUpdate = ::Ice::__defineOperation('startUpdate', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], ::Ice::T_int, [::IceGrid::T_AccessDeniedException])
        AdminSession_mixin::OP_finishUpdate = ::Ice::__defineOperation('finishUpdate', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [::IceGrid::T_AccessDeniedException])
        AdminSession_mixin::OP_getReplicaName = ::Ice::__defineOperation('getReplicaName', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [], [], ::Ice::T_string, [])
        AdminSession_mixin::OP_openServerLog = ::Ice::__defineOperation('openServerLog', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_string, ::Ice::T_int], [], ::IceGrid::T_FileIteratorPrx, [::IceGrid::T_FileNotAvailableException, ::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        AdminSession_mixin::OP_openServerStdErr = ::Ice::__defineOperation('openServerStdErr', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_int], [], ::IceGrid::T_FileIteratorPrx, [::IceGrid::T_FileNotAvailableException, ::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        AdminSession_mixin::OP_openServerStdOut = ::Ice::__defineOperation('openServerStdOut', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_int], [], ::IceGrid::T_FileIteratorPrx, [::IceGrid::T_FileNotAvailableException, ::IceGrid::T_ServerNotExistException, ::IceGrid::T_NodeUnreachableException, ::IceGrid::T_DeploymentException])
        AdminSession_mixin::OP_openNodeStdErr = ::Ice::__defineOperation('openNodeStdErr', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_int], [], ::IceGrid::T_FileIteratorPrx, [::IceGrid::T_FileNotAvailableException, ::IceGrid::T_NodeNotExistException, ::IceGrid::T_NodeUnreachableException])
        AdminSession_mixin::OP_openNodeStdOut = ::Ice::__defineOperation('openNodeStdOut', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_int], [], ::IceGrid::T_FileIteratorPrx, [::IceGrid::T_FileNotAvailableException, ::IceGrid::T_NodeNotExistException, ::IceGrid::T_NodeUnreachableException])
        AdminSession_mixin::OP_openRegistryStdErr = ::Ice::__defineOperation('openRegistryStdErr', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_int], [], ::IceGrid::T_FileIteratorPrx, [::IceGrid::T_FileNotAvailableException, ::IceGrid::T_RegistryNotExistException, ::IceGrid::T_RegistryUnreachableException])
        AdminSession_mixin::OP_openRegistryStdOut = ::Ice::__defineOperation('openRegistryStdOut', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_int], [], ::IceGrid::T_FileIteratorPrx, [::IceGrid::T_FileNotAvailableException, ::IceGrid::T_RegistryNotExistException, ::IceGrid::T_RegistryUnreachableException])
    end
end
