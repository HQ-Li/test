# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Locator.ice'

require 'Ice'
require 'Ice/Locator.rb'

module IceGrid

    if not defined?(::IceGrid::T_Registry)
        T_Registry = ::Ice::__declareClass('::IceGrid::Registry')
        T_RegistryPrx = ::Ice::__declareProxy('::IceGrid::Registry')
    end

    if not defined?(::IceGrid::T_Query)
        T_Query = ::Ice::__declareClass('::IceGrid::Query')
        T_QueryPrx = ::Ice::__declareProxy('::IceGrid::Query')
    end

    if not defined?(::IceGrid::Locator_mixin)
        module Locator_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Locator', '::Ice::Object', '::IceGrid::Locator']
            end

            def ice_id(current=nil)
                '::IceGrid::Locator'
            end

            #
            # Operation signatures.
            #
            # def getLocalRegistry(current=nil)
            # def getLocalQuery(current=nil)

            def inspect
                ::Ice::__stringify(self, T_Locator)
            end
        end
        module LocatorPrx_mixin
            include ::Ice::LocatorPrx_mixin

            def getLocalRegistry(_ctx=nil)
                Locator_mixin::OP_getLocalRegistry.invoke(self, [], _ctx)
            end

            def getLocalQuery(_ctx=nil)
                Locator_mixin::OP_getLocalQuery.invoke(self, [], _ctx)
            end
        end
        class LocatorPrx < ::Ice::ObjectPrx
            include LocatorPrx_mixin

            def LocatorPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::Locator', facetOrCtx, _ctx)
            end

            def LocatorPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_Locator)
            T_Locator = ::Ice::__declareClass('::IceGrid::Locator')
            T_LocatorPrx = ::Ice::__declareProxy('::IceGrid::Locator')
        end

        T_Locator.defineClass(nil, true, nil, [::Ice::T_Locator], [])
        Locator_mixin::ICE_TYPE = T_Locator

        T_LocatorPrx.defineProxy(LocatorPrx, T_Locator)
        LocatorPrx::ICE_TYPE = T_LocatorPrx

        Locator_mixin::OP_getLocalRegistry = ::Ice::__defineOperation('getLocalRegistry', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [], [], ::IceGrid::T_RegistryPrx, [])
        Locator_mixin::OP_getLocalQuery = ::Ice::__defineOperation('getLocalQuery', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [], [], ::IceGrid::T_QueryPrx, [])
    end
end
