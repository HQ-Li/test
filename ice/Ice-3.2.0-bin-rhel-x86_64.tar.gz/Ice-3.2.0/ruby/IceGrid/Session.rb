# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Session.ice'

require 'Ice'
require 'Glacier2/Session.rb'
require 'IceGrid/Exception.rb'

module IceGrid

    if not defined?(::IceGrid::Session_mixin)
        module Session_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::Session', '::Ice::Object', '::IceGrid::Session']
            end

            def ice_id(current=nil)
                '::IceGrid::Session'
            end

            #
            # Operation signatures.
            #
            # def keepAlive(current=nil)
            # def allocateObjectById(id, current=nil)
            # def allocateObjectByType(type, current=nil)
            # def releaseObject(id, current=nil)
            # def setAllocationTimeout(timeout, current=nil)

            def inspect
                ::Ice::__stringify(self, T_Session)
            end
        end
        module SessionPrx_mixin
            include ::Glacier2::SessionPrx_mixin

            def keepAlive(_ctx=nil)
                Session_mixin::OP_keepAlive.invoke(self, [], _ctx)
            end

            def allocateObjectById(id, _ctx=nil)
                Session_mixin::OP_allocateObjectById.invoke(self, [id], _ctx)
            end

            def allocateObjectById_async(_cb, id, _ctx=nil)
                Session_mixin::OP_allocateObjectById.invokeAsync(self, _cb, [id, ], _ctx)
            end

            def allocateObjectByType(type, _ctx=nil)
                Session_mixin::OP_allocateObjectByType.invoke(self, [type], _ctx)
            end

            def allocateObjectByType_async(_cb, type, _ctx=nil)
                Session_mixin::OP_allocateObjectByType.invokeAsync(self, _cb, [type, ], _ctx)
            end

            def releaseObject(id, _ctx=nil)
                Session_mixin::OP_releaseObject.invoke(self, [id], _ctx)
            end

            def setAllocationTimeout(timeout, _ctx=nil)
                Session_mixin::OP_setAllocationTimeout.invoke(self, [timeout], _ctx)
            end
        end
        class SessionPrx < ::Ice::ObjectPrx
            include SessionPrx_mixin

            def SessionPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::Session', facetOrCtx, _ctx)
            end

            def SessionPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_Session)
            T_Session = ::Ice::__declareClass('::IceGrid::Session')
            T_SessionPrx = ::Ice::__declareProxy('::IceGrid::Session')
        end

        T_Session.defineClass(nil, true, nil, [::Glacier2::T_Session], [])
        Session_mixin::ICE_TYPE = T_Session

        T_SessionPrx.defineProxy(SessionPrx, T_Session)
        SessionPrx::ICE_TYPE = T_SessionPrx

        Session_mixin::OP_keepAlive = ::Ice::__defineOperation('keepAlive', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [], [], nil, [])
        Session_mixin::OP_allocateObjectById = ::Ice::__defineOperation('allocateObjectById', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, true, [::Ice::T_Identity], [], ::Ice::T_ObjectPrx, [::IceGrid::T_ObjectNotRegisteredException, ::IceGrid::T_AllocationException])
        Session_mixin::OP_allocateObjectByType = ::Ice::__defineOperation('allocateObjectByType', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, true, [::Ice::T_string], [], ::Ice::T_ObjectPrx, [::IceGrid::T_AllocationException])
        Session_mixin::OP_releaseObject = ::Ice::__defineOperation('releaseObject', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_Identity], [], nil, [::IceGrid::T_ObjectNotRegisteredException, ::IceGrid::T_AllocationException])
        Session_mixin::OP_setAllocationTimeout = ::Ice::__defineOperation('setAllocationTimeout', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_int], [], nil, [])
    end
end
