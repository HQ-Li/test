# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `UserAccountMapper.ice'

require 'Ice'

module IceGrid

    if not defined?(::IceGrid::UserAccountNotFoundException)
        class UserAccountNotFoundException < Ice::UserException
            def initialize
            end

            def to_s
                'IceGrid::UserAccountNotFoundException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_UserAccountNotFoundException = ::Ice::__defineException('::IceGrid::UserAccountNotFoundException', UserAccountNotFoundException, nil, [])
        UserAccountNotFoundException::ICE_TYPE = T_UserAccountNotFoundException
    end

    if not defined?(::IceGrid::UserAccountMapper_mixin)
        module UserAccountMapper_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::UserAccountMapper']
            end

            def ice_id(current=nil)
                '::IceGrid::UserAccountMapper'
            end

            #
            # Operation signatures.
            #
            # def getUserAccount(user, current=nil)

            def inspect
                ::Ice::__stringify(self, T_UserAccountMapper)
            end
        end
        module UserAccountMapperPrx_mixin

            def getUserAccount(user, _ctx=nil)
                UserAccountMapper_mixin::OP_getUserAccount.invoke(self, [user], _ctx)
            end
        end
        class UserAccountMapperPrx < ::Ice::ObjectPrx
            include UserAccountMapperPrx_mixin

            def UserAccountMapperPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::UserAccountMapper', facetOrCtx, _ctx)
            end

            def UserAccountMapperPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_UserAccountMapper)
            T_UserAccountMapper = ::Ice::__declareClass('::IceGrid::UserAccountMapper')
            T_UserAccountMapperPrx = ::Ice::__declareProxy('::IceGrid::UserAccountMapper')
        end

        T_UserAccountMapper.defineClass(nil, true, nil, [], [])
        UserAccountMapper_mixin::ICE_TYPE = T_UserAccountMapper

        T_UserAccountMapperPrx.defineProxy(UserAccountMapperPrx, T_UserAccountMapper)
        UserAccountMapperPrx::ICE_TYPE = T_UserAccountMapperPrx

        UserAccountMapper_mixin::OP_getUserAccount = ::Ice::__defineOperation('getUserAccount', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], ::Ice::T_string, [::IceGrid::T_UserAccountNotFoundException])
    end
end
