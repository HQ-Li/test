# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `FileParser.ice'

require 'Ice'
require 'IceGrid/Admin.rb'

module IceGrid

    if not defined?(::IceGrid::ParseException)
        class ParseException < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'IceGrid::ParseException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_ParseException = ::Ice::__defineException('::IceGrid::ParseException', ParseException, nil, [["reason", ::Ice::T_string]])
        ParseException::ICE_TYPE = T_ParseException
    end

    if not defined?(::IceGrid::FileParser_mixin)
        module FileParser_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceGrid::FileParser']
            end

            def ice_id(current=nil)
                '::IceGrid::FileParser'
            end

            #
            # Operation signatures.
            #
            # def parse(xmlFile, adminProxy, current=nil)

            def inspect
                ::Ice::__stringify(self, T_FileParser)
            end
        end
        module FileParserPrx_mixin

            def parse(xmlFile, adminProxy, _ctx=nil)
                FileParser_mixin::OP_parse.invoke(self, [xmlFile, adminProxy], _ctx)
            end
        end
        class FileParserPrx < ::Ice::ObjectPrx
            include FileParserPrx_mixin

            def FileParserPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceGrid::FileParser', facetOrCtx, _ctx)
            end

            def FileParserPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceGrid::T_FileParser)
            T_FileParser = ::Ice::__declareClass('::IceGrid::FileParser')
            T_FileParserPrx = ::Ice::__declareProxy('::IceGrid::FileParser')
        end

        T_FileParser.defineClass(nil, true, nil, [], [])
        FileParser_mixin::ICE_TYPE = T_FileParser

        T_FileParserPrx.defineProxy(FileParserPrx, T_FileParser)
        FileParserPrx::ICE_TYPE = T_FileParserPrx

        FileParser_mixin::OP_parse = ::Ice::__defineOperation('parse', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_string, ::IceGrid::T_AdminPrx], [], ::IceGrid::T_ApplicationDescriptor, [::IceGrid::T_ParseException])
    end
end
