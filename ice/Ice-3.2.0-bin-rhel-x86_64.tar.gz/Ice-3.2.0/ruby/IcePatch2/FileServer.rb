# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `FileServer.ice'

require 'Ice'
require 'IcePatch2/FileInfo.rb'

module IcePatch2

    if not defined?(::IcePatch2::T_ByteSeqSeq)
        T_ByteSeqSeq = ::Ice::__defineSequence('::IcePatch2::ByteSeqSeq', ::Ice::T_ByteSeq)
    end

    if not defined?(::IcePatch2::PartitionOutOfRangeException)
        class PartitionOutOfRangeException < Ice::UserException
            def initialize
            end

            def to_s
                'IcePatch2::PartitionOutOfRangeException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_PartitionOutOfRangeException = ::Ice::__defineException('::IcePatch2::PartitionOutOfRangeException', PartitionOutOfRangeException, nil, [])
        PartitionOutOfRangeException::ICE_TYPE = T_PartitionOutOfRangeException
    end

    if not defined?(::IcePatch2::FileAccessException)
        class FileAccessException < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'IcePatch2::FileAccessException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_FileAccessException = ::Ice::__defineException('::IcePatch2::FileAccessException', FileAccessException, nil, [["reason", ::Ice::T_string]])
        FileAccessException::ICE_TYPE = T_FileAccessException
    end

    if not defined?(::IcePatch2::FileServer_mixin)
        module FileServer_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IcePatch2::FileServer']
            end

            def ice_id(current=nil)
                '::IcePatch2::FileServer'
            end

            #
            # Operation signatures.
            #
            # def getFileInfoSeq(partition, current=nil)
            # def getChecksumSeq(current=nil)
            # def getChecksum(current=nil)
            # def getFileCompressed(path, pos, num, current=nil)

            def inspect
                ::Ice::__stringify(self, T_FileServer)
            end
        end
        module FileServerPrx_mixin

            def getFileInfoSeq(partition, _ctx=nil)
                FileServer_mixin::OP_getFileInfoSeq.invoke(self, [partition], _ctx)
            end

            def getFileInfoSeq_async(_cb, partition, _ctx=nil)
                FileServer_mixin::OP_getFileInfoSeq.invokeAsync(self, _cb, [partition, ], _ctx)
            end

            def getChecksumSeq(_ctx=nil)
                FileServer_mixin::OP_getChecksumSeq.invoke(self, [], _ctx)
            end

            def getChecksum(_ctx=nil)
                FileServer_mixin::OP_getChecksum.invoke(self, [], _ctx)
            end

            def getFileCompressed(path, pos, num, _ctx=nil)
                FileServer_mixin::OP_getFileCompressed.invoke(self, [path, pos, num], _ctx)
            end

            def getFileCompressed_async(_cb, path, pos, num, _ctx=nil)
                FileServer_mixin::OP_getFileCompressed.invokeAsync(self, _cb, [path, pos, num], _ctx)
            end
        end
        class FileServerPrx < ::Ice::ObjectPrx
            include FileServerPrx_mixin

            def FileServerPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IcePatch2::FileServer', facetOrCtx, _ctx)
            end

            def FileServerPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IcePatch2::T_FileServer)
            T_FileServer = ::Ice::__declareClass('::IcePatch2::FileServer')
            T_FileServerPrx = ::Ice::__declareProxy('::IcePatch2::FileServer')
        end

        T_FileServer.defineClass(nil, true, nil, [], [])
        FileServer_mixin::ICE_TYPE = T_FileServer

        T_FileServerPrx.defineProxy(FileServerPrx, T_FileServer)
        FileServerPrx::ICE_TYPE = T_FileServerPrx

        FileServer_mixin::OP_getFileInfoSeq = ::Ice::__defineOperation('getFileInfoSeq', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_int], [], ::IcePatch2::T_FileInfoSeq, [::IcePatch2::T_PartitionOutOfRangeException])
        FileServer_mixin::OP_getChecksumSeq = ::Ice::__defineOperation('getChecksumSeq', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::IcePatch2::T_ByteSeqSeq, [])
        FileServer_mixin::OP_getChecksum = ::Ice::__defineOperation('getChecksum', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_ByteSeq, [])
        FileServer_mixin::OP_getFileCompressed = ::Ice::__defineOperation('getFileCompressed', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, true, [::Ice::T_string, ::Ice::T_int, ::Ice::T_int], [], ::Ice::T_ByteSeq, [::IcePatch2::T_FileAccessException])
    end

    if not defined?(::IcePatch2::Admin_mixin)
        module Admin_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IcePatch2::Admin']
            end

            def ice_id(current=nil)
                '::IcePatch2::Admin'
            end

            #
            # Operation signatures.
            #
            # def shutdown(current=nil)

            def inspect
                ::Ice::__stringify(self, T_Admin)
            end
        end
        module AdminPrx_mixin

            def shutdown(_ctx=nil)
                Admin_mixin::OP_shutdown.invoke(self, [], _ctx)
            end
        end
        class AdminPrx < ::Ice::ObjectPrx
            include AdminPrx_mixin

            def AdminPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IcePatch2::Admin', facetOrCtx, _ctx)
            end

            def AdminPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IcePatch2::T_Admin)
            T_Admin = ::Ice::__declareClass('::IcePatch2::Admin')
            T_AdminPrx = ::Ice::__declareProxy('::IcePatch2::Admin')
        end

        T_Admin.defineClass(nil, true, nil, [], [])
        Admin_mixin::ICE_TYPE = T_Admin

        T_AdminPrx.defineProxy(AdminPrx, T_Admin)
        AdminPrx::ICE_TYPE = T_AdminPrx

        Admin_mixin::OP_shutdown = ::Ice::__defineOperation('shutdown', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [])
    end
end
