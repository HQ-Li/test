# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `FileInfo.ice'

require 'Ice'
require 'Ice/BuiltinSequences.rb'

module IcePatch2

    if not defined?(::IcePatch2::FileInfo)
        class FileInfo
            def initialize(path='', checksum=nil, size=0, executable=false)
                @path = path
                @checksum = checksum
                @size = size
                @executable = executable
            end

            def hash
                _h = 0
                _h = 5 * _h + @path.hash
                _h = 5 * _h + @checksum.hash
                _h = 5 * _h + @size.hash
                _h = 5 * _h + @executable.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @path != other.path or
                    @checksum != other.checksum or
                    @size != other.size or
                    @executable != other.executable
                true
            end

            def inspect
                ::Ice::__stringify(self, T_FileInfo)
            end

            attr_accessor :path, :checksum, :size, :executable
        end

        T_FileInfo = ::Ice::__defineStruct('::IcePatch2::FileInfo', FileInfo, [
            ["path", ::Ice::T_string],
            ["checksum", ::Ice::T_ByteSeq],
            ["size", ::Ice::T_int],
            ["executable", ::Ice::T_bool]
        ])
    end

    if not defined?(::IcePatch2::T_FileInfoSeq)
        T_FileInfoSeq = ::Ice::__defineSequence('::IcePatch2::FileInfoSeq', ::IcePatch2::T_FileInfo)
    end
end
