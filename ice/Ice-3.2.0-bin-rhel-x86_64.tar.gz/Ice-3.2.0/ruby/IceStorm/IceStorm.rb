# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `IceStorm.ice'

require 'Ice'
require 'Ice/SliceChecksumDict.rb'
require 'Ice/Identity.rb'

module IceStorm

    if not defined?(::IceStorm::T_Topic)
        T_Topic = ::Ice::__declareClass('::IceStorm::Topic')
        T_TopicPrx = ::Ice::__declareProxy('::IceStorm::Topic')
    end

    if not defined?(::IceStorm::LinkInfo)
        class LinkInfo
            def initialize(theTopic=nil, name='', cost=0)
                @theTopic = theTopic
                @name = name
                @cost = cost
            end

            def hash
                _h = 0
                _h = 5 * _h + @theTopic.hash
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @cost.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @theTopic != other.theTopic or
                    @name != other.name or
                    @cost != other.cost
                true
            end

            def inspect
                ::Ice::__stringify(self, T_LinkInfo)
            end

            attr_accessor :theTopic, :name, :cost
        end

        T_LinkInfo = ::Ice::__defineStruct('::IceStorm::LinkInfo', LinkInfo, [
            ["theTopic", ::IceStorm::T_TopicPrx],
            ["name", ::Ice::T_string],
            ["cost", ::Ice::T_int]
        ])
    end

    if not defined?(::IceStorm::T_LinkInfoSeq)
        T_LinkInfoSeq = ::Ice::__defineSequence('::IceStorm::LinkInfoSeq', ::IceStorm::T_LinkInfo)
    end

    if not defined?(::IceStorm::T_QoS)
        T_QoS = ::Ice::__defineDictionary('::IceStorm::QoS', ::Ice::T_string, ::Ice::T_string)
    end

    if not defined?(::IceStorm::LinkExists)
        class LinkExists < Ice::UserException
            def initialize(name='')
                @name = name
            end

            def to_s
                'IceStorm::LinkExists'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name
        end

        T_LinkExists = ::Ice::__defineException('::IceStorm::LinkExists', LinkExists, nil, [["name", ::Ice::T_string]])
        LinkExists::ICE_TYPE = T_LinkExists
    end

    if not defined?(::IceStorm::NoSuchLink)
        class NoSuchLink < Ice::UserException
            def initialize(name='')
                @name = name
            end

            def to_s
                'IceStorm::NoSuchLink'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name
        end

        T_NoSuchLink = ::Ice::__defineException('::IceStorm::NoSuchLink', NoSuchLink, nil, [["name", ::Ice::T_string]])
        NoSuchLink::ICE_TYPE = T_NoSuchLink
    end

    if not defined?(::IceStorm::AlreadySubscribed)
        class AlreadySubscribed < Ice::UserException
            def initialize
            end

            def to_s
                'IceStorm::AlreadySubscribed'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_AlreadySubscribed = ::Ice::__defineException('::IceStorm::AlreadySubscribed', AlreadySubscribed, nil, [])
        AlreadySubscribed::ICE_TYPE = T_AlreadySubscribed
    end

    if not defined?(::IceStorm::BadQoS)
        class BadQoS < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'IceStorm::BadQoS'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_BadQoS = ::Ice::__defineException('::IceStorm::BadQoS', BadQoS, nil, [["reason", ::Ice::T_string]])
        BadQoS::ICE_TYPE = T_BadQoS
    end

    if not defined?(::IceStorm::Topic_mixin)
        module Topic_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceStorm::Topic']
            end

            def ice_id(current=nil)
                '::IceStorm::Topic'
            end

            #
            # Operation signatures.
            #
            # def getName(current=nil)
            # def getPublisher(current=nil)
            # def subscribe(theQoS, subscriber, current=nil)
            # def subscribeAndGetPublisher(theQoS, subscriber, current=nil)
            # def unsubscribe(subscriber, current=nil)
            # def link(linkTo, cost, current=nil)
            # def unlink(linkTo, current=nil)
            # def getLinkInfoSeq(current=nil)
            # def destroy(current=nil)

            def inspect
                ::Ice::__stringify(self, T_Topic)
            end
        end
        module TopicPrx_mixin

            def getName(_ctx=nil)
                Topic_mixin::OP_getName.invoke(self, [], _ctx)
            end

            def getPublisher(_ctx=nil)
                Topic_mixin::OP_getPublisher.invoke(self, [], _ctx)
            end

            def subscribe(theQoS, subscriber, _ctx=nil)
                Topic_mixin::OP_subscribe.invoke(self, [theQoS, subscriber], _ctx)
            end

            def subscribeAndGetPublisher(theQoS, subscriber, _ctx=nil)
                Topic_mixin::OP_subscribeAndGetPublisher.invoke(self, [theQoS, subscriber], _ctx)
            end

            def unsubscribe(subscriber, _ctx=nil)
                Topic_mixin::OP_unsubscribe.invoke(self, [subscriber], _ctx)
            end

            def link(linkTo, cost, _ctx=nil)
                Topic_mixin::OP_link.invoke(self, [linkTo, cost], _ctx)
            end

            def unlink(linkTo, _ctx=nil)
                Topic_mixin::OP_unlink.invoke(self, [linkTo], _ctx)
            end

            def getLinkInfoSeq(_ctx=nil)
                Topic_mixin::OP_getLinkInfoSeq.invoke(self, [], _ctx)
            end

            def destroy(_ctx=nil)
                Topic_mixin::OP_destroy.invoke(self, [], _ctx)
            end
        end
        class TopicPrx < ::Ice::ObjectPrx
            include TopicPrx_mixin

            def TopicPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceStorm::Topic', facetOrCtx, _ctx)
            end

            def TopicPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceStorm::T_Topic)
            T_Topic = ::Ice::__declareClass('::IceStorm::Topic')
            T_TopicPrx = ::Ice::__declareProxy('::IceStorm::Topic')
        end

        T_Topic.defineClass(nil, true, nil, [], [])
        Topic_mixin::ICE_TYPE = T_Topic

        T_TopicPrx.defineProxy(TopicPrx, T_Topic)
        TopicPrx::ICE_TYPE = T_TopicPrx

        Topic_mixin::OP_getName = ::Ice::__defineOperation('getName', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_string, [])
        Topic_mixin::OP_getPublisher = ::Ice::__defineOperation('getPublisher', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_ObjectPrx, [])
        Topic_mixin::OP_subscribe = ::Ice::__defineOperation('subscribe', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceStorm::T_QoS, ::Ice::T_ObjectPrx], [], nil, [])
        Topic_mixin::OP_subscribe.deprecate("subscribe is deprecated, use subscribeAndGetPublisher instead")
        Topic_mixin::OP_subscribeAndGetPublisher = ::Ice::__defineOperation('subscribeAndGetPublisher', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceStorm::T_QoS, ::Ice::T_ObjectPrx], [], ::Ice::T_ObjectPrx, [::IceStorm::T_AlreadySubscribed, ::IceStorm::T_BadQoS])
        Topic_mixin::OP_unsubscribe = ::Ice::__defineOperation('unsubscribe', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_ObjectPrx], [], nil, [])
        Topic_mixin::OP_link = ::Ice::__defineOperation('link', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceStorm::T_TopicPrx, ::Ice::T_int], [], nil, [::IceStorm::T_LinkExists])
        Topic_mixin::OP_unlink = ::Ice::__defineOperation('unlink', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::IceStorm::T_TopicPrx], [], nil, [::IceStorm::T_NoSuchLink])
        Topic_mixin::OP_getLinkInfoSeq = ::Ice::__defineOperation('getLinkInfoSeq', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::IceStorm::T_LinkInfoSeq, [])
        Topic_mixin::OP_destroy = ::Ice::__defineOperation('destroy', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [])
    end

    if not defined?(::IceStorm::T_TopicDict)
        T_TopicDict = ::Ice::__defineDictionary('::IceStorm::TopicDict', ::Ice::T_string, ::IceStorm::T_TopicPrx)
    end

    if not defined?(::IceStorm::TopicExists)
        class TopicExists < Ice::UserException
            def initialize(name='')
                @name = name
            end

            def to_s
                'IceStorm::TopicExists'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name
        end

        T_TopicExists = ::Ice::__defineException('::IceStorm::TopicExists', TopicExists, nil, [["name", ::Ice::T_string]])
        TopicExists::ICE_TYPE = T_TopicExists
    end

    if not defined?(::IceStorm::NoSuchTopic)
        class NoSuchTopic < Ice::UserException
            def initialize(name='')
                @name = name
            end

            def to_s
                'IceStorm::NoSuchTopic'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name
        end

        T_NoSuchTopic = ::Ice::__defineException('::IceStorm::NoSuchTopic', NoSuchTopic, nil, [["name", ::Ice::T_string]])
        NoSuchTopic::ICE_TYPE = T_NoSuchTopic
    end

    if not defined?(::IceStorm::TopicManager_mixin)
        module TopicManager_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceStorm::TopicManager']
            end

            def ice_id(current=nil)
                '::IceStorm::TopicManager'
            end

            #
            # Operation signatures.
            #
            # def create(name, current=nil)
            # def retrieve(name, current=nil)
            # def retrieveAll(current=nil)
            # def getSliceChecksums(current=nil)

            def inspect
                ::Ice::__stringify(self, T_TopicManager)
            end
        end
        module TopicManagerPrx_mixin

            def create(name, _ctx=nil)
                TopicManager_mixin::OP_create.invoke(self, [name], _ctx)
            end

            def retrieve(name, _ctx=nil)
                TopicManager_mixin::OP_retrieve.invoke(self, [name], _ctx)
            end

            def retrieveAll(_ctx=nil)
                TopicManager_mixin::OP_retrieveAll.invoke(self, [], _ctx)
            end

            def getSliceChecksums(_ctx=nil)
                TopicManager_mixin::OP_getSliceChecksums.invoke(self, [], _ctx)
            end
        end
        class TopicManagerPrx < ::Ice::ObjectPrx
            include TopicManagerPrx_mixin

            def TopicManagerPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceStorm::TopicManager', facetOrCtx, _ctx)
            end

            def TopicManagerPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceStorm::T_TopicManager)
            T_TopicManager = ::Ice::__declareClass('::IceStorm::TopicManager')
            T_TopicManagerPrx = ::Ice::__declareProxy('::IceStorm::TopicManager')
        end

        T_TopicManager.defineClass(nil, true, nil, [], [])
        TopicManager_mixin::ICE_TYPE = T_TopicManager

        T_TopicManagerPrx.defineProxy(TopicManagerPrx, T_TopicManager)
        TopicManagerPrx::ICE_TYPE = T_TopicManagerPrx

        TopicManager_mixin::OP_create = ::Ice::__defineOperation('create', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], ::IceStorm::T_TopicPrx, [::IceStorm::T_TopicExists])
        TopicManager_mixin::OP_retrieve = ::Ice::__defineOperation('retrieve', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string], [], ::IceStorm::T_TopicPrx, [::IceStorm::T_NoSuchTopic])
        TopicManager_mixin::OP_retrieveAll = ::Ice::__defineOperation('retrieveAll', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::IceStorm::T_TopicDict, [])
        TopicManager_mixin::OP_getSliceChecksums = ::Ice::__defineOperation('getSliceChecksums', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_SliceChecksumDict, [])
    end
end
