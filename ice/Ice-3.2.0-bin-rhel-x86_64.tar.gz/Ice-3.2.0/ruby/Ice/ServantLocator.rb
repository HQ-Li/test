# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `ServantLocator.ice'

require 'Ice'
require 'Ice/ObjectAdapterF.rb'
require 'Ice/Current.rb'

module Ice

    if not defined?(::Ice::ServantLocator_mixin)
        module ServantLocator_mixin

            #
            # Operation signatures.
            #
            # def locate(curr)
            # def finished(curr, servant, cookie)
            # def deactivate(category)

            def inspect
                ::Ice::__stringify(self, T_ServantLocator)
            end
        end

        if not defined?(::Ice::T_ServantLocator)
            T_ServantLocator = ::Ice::__declareClass('::Ice::ServantLocator')
        end

        T_ServantLocator.defineClass(nil, true, nil, [], [])
        ServantLocator_mixin::ICE_TYPE = T_ServantLocator
    end
end
