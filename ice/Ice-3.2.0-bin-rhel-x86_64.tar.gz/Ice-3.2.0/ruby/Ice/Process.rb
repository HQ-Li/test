# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Process.ice'

require 'Ice'

module Ice

    if not defined?(::Ice::Process_mixin)
        module Process_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::Ice::Process']
            end

            def ice_id(current=nil)
                '::Ice::Process'
            end

            #
            # Operation signatures.
            #
            # def shutdown(current=nil)
            # def writeMessage(message, fd, current=nil)

            def inspect
                ::Ice::__stringify(self, T_Process)
            end
        end
        module ProcessPrx_mixin

            def shutdown(_ctx=nil)
                Process_mixin::OP_shutdown.invoke(self, [], _ctx)
            end

            def shutdown_async(_cb, _ctx=nil)
                Process_mixin::OP_shutdown.invokeAsync(self, _cb, [], _ctx)
            end

            def writeMessage(message, fd, _ctx=nil)
                Process_mixin::OP_writeMessage.invoke(self, [message, fd], _ctx)
            end
        end
        class ProcessPrx < ::Ice::ObjectPrx
            include ProcessPrx_mixin

            def ProcessPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Ice::Process', facetOrCtx, _ctx)
            end

            def ProcessPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Ice::T_Process)
            T_Process = ::Ice::__declareClass('::Ice::Process')
            T_ProcessPrx = ::Ice::__declareProxy('::Ice::Process')
        end

        T_Process.defineClass(nil, true, nil, [], [])
        Process_mixin::ICE_TYPE = T_Process

        T_ProcessPrx.defineProxy(ProcessPrx, T_Process)
        ProcessPrx::ICE_TYPE = T_ProcessPrx

        Process_mixin::OP_shutdown = ::Ice::__defineOperation('shutdown', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [])
        Process_mixin::OP_writeMessage = ::Ice::__defineOperation('writeMessage', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_int], [], nil, [])
    end
end
