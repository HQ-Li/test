# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Router.ice'

require 'Ice'
require 'Ice/BuiltinSequences.rb'

module Ice

    if not defined?(::Ice::Router_mixin)
        module Router_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::Ice::Router']
            end

            def ice_id(current=nil)
                '::Ice::Router'
            end

            #
            # Operation signatures.
            #
            # def getClientProxy(current=nil)
            # def getServerProxy(current=nil)
            # def addProxy(proxy, current=nil)
            # def addProxies(proxies, current=nil)

            def inspect
                ::Ice::__stringify(self, T_Router)
            end
        end
        module RouterPrx_mixin

            def getClientProxy(_ctx=nil)
                Router_mixin::OP_getClientProxy.invoke(self, [], _ctx)
            end

            def getServerProxy(_ctx=nil)
                Router_mixin::OP_getServerProxy.invoke(self, [], _ctx)
            end

            def addProxy(proxy, _ctx=nil)
                Router_mixin::OP_addProxy.invoke(self, [proxy], _ctx)
            end

            def addProxies(proxies, _ctx=nil)
                Router_mixin::OP_addProxies.invoke(self, [proxies], _ctx)
            end
        end
        class RouterPrx < ::Ice::ObjectPrx
            include RouterPrx_mixin

            def RouterPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Ice::Router', facetOrCtx, _ctx)
            end

            def RouterPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Ice::T_Router)
            T_Router = ::Ice::__declareClass('::Ice::Router')
            T_RouterPrx = ::Ice::__declareProxy('::Ice::Router')
        end

        T_Router.defineClass(nil, true, nil, [], [])
        Router_mixin::ICE_TYPE = T_Router

        T_RouterPrx.defineProxy(RouterPrx, T_Router)
        RouterPrx::ICE_TYPE = T_RouterPrx

        Router_mixin::OP_getClientProxy = ::Ice::__defineOperation('getClientProxy', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_ObjectPrx, [])
        Router_mixin::OP_getServerProxy = ::Ice::__defineOperation('getServerProxy', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_ObjectPrx, [])
        Router_mixin::OP_addProxy = ::Ice::__defineOperation('addProxy', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_ObjectPrx], [], nil, [])
        Router_mixin::OP_addProxy.deprecate("addProxy() is deprecated, use addProxies() instead.")
        Router_mixin::OP_addProxies = ::Ice::__defineOperation('addProxies', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_ObjectProxySeq], [], ::Ice::T_ObjectProxySeq, [])
    end
end
