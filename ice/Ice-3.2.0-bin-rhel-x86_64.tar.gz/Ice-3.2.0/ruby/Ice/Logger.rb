# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Logger.ice'

require 'Ice'

module Ice

    if not defined?(::Ice::Logger_mixin)
        module Logger_mixin

            #
            # Operation signatures.
            #
            # def print(message)
            # def trace(category, message)
            # def warning(message)
            # def error(message)

            def inspect
                ::Ice::__stringify(self, T_Logger)
            end
        end

        if not defined?(::Ice::T_Logger)
            T_Logger = ::Ice::__declareClass('::Ice::Logger')
        end

        T_Logger.defineClass(nil, true, nil, [], [])
        Logger_mixin::ICE_TYPE = T_Logger
    end
end
