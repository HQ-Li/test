# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Stats.ice'

require 'Ice'

module Ice

    if not defined?(::Ice::Stats_mixin)
        module Stats_mixin

            #
            # Operation signatures.
            #
            # def bytesSent(protocol, num)
            # def bytesReceived(protocol, num)

            def inspect
                ::Ice::__stringify(self, T_Stats)
            end
        end

        if not defined?(::Ice::T_Stats)
            T_Stats = ::Ice::__declareClass('::Ice::Stats')
        end

        T_Stats.defineClass(nil, true, nil, [], [])
        Stats_mixin::ICE_TYPE = T_Stats
    end
end
