# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Identity.ice'

require 'Ice'

module Ice

    if not defined?(::Ice::Identity)
        class Identity
            def initialize(name='', category='')
                @name = name
                @category = category
            end

            def hash
                _h = 0
                _h = 5 * _h + @name.hash
                _h = 5 * _h + @category.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @name != other.name or
                    @category != other.category
                true
            end

            def inspect
                ::Ice::__stringify(self, T_Identity)
            end

            attr_accessor :name, :category
        end

        T_Identity = ::Ice::__defineStruct('::Ice::Identity', Identity, [
            ["name", ::Ice::T_string],
            ["category", ::Ice::T_string]
        ])
    end

    if not defined?(::Ice::T_ObjectDict)
        T_ObjectDict = ::Ice::__defineDictionary('::Ice::ObjectDict', ::Ice::T_Identity, ::Ice::T_Object)
    end

    if not defined?(::Ice::T_IdentitySeq)
        T_IdentitySeq = ::Ice::__defineSequence('::Ice::IdentitySeq', ::Ice::T_Identity)
    end
end
