# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Communicator.ice'

require 'Ice'
require 'Ice/LoggerF.rb'
require 'Ice/StatsF.rb'
require 'Ice/ObjectAdapterF.rb'
require 'Ice/PropertiesF.rb'
require 'Ice/ObjectFactoryF.rb'
require 'Ice/RouterF.rb'
require 'Ice/LocatorF.rb'
require 'Ice/PluginF.rb'
require 'Ice/ImplicitContextF.rb'
require 'Ice/Current.rb'

module Ice

    if not defined?(::Ice::Communicator_mixin)
        module Communicator_mixin

            #
            # Operation signatures.
            #
            # def destroy()
            # def shutdown()
            # def waitForShutdown()
            # def isShutdown()
            # def stringToProxy(str)
            # def proxyToString(obj)
            # def propertyToProxy(property)
            # def stringToIdentity(str)
            # def identityToString(ident)
            # def createObjectAdapter(name)
            # def createObjectAdapterWithEndpoints(name, endpoints)
            # def createObjectAdapterWithRouter(name, rtr)
            # def addObjectFactory(factory, id)
            # def findObjectFactory(id)
            # def getDefaultContext()
            # def setDefaultContext(ctx)
            # def getImplicitContext()
            # def getProperties()
            # def getLogger()
            # def getStats()
            # def getDefaultRouter()
            # def setDefaultRouter(rtr)
            # def getDefaultLocator()
            # def setDefaultLocator(loc)
            # def getPluginManager()
            # def flushBatchRequests()

            def inspect
                ::Ice::__stringify(self, T_Communicator)
            end
        end

        if not defined?(::Ice::T_Communicator)
            T_Communicator = ::Ice::__declareClass('::Ice::Communicator')
        end

        T_Communicator.defineClass(nil, true, nil, [], [])
        Communicator_mixin::ICE_TYPE = T_Communicator
    end
end
