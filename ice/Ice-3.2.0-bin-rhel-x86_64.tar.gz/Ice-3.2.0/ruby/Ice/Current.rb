# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Current.ice'

require 'Ice'
require 'Ice/ObjectAdapterF.rb'
require 'Ice/ConnectionF.rb'
require 'Ice/Identity.rb'

module Ice

    if not defined?(::Ice::T_Context)
        T_Context = ::Ice::__defineDictionary('::Ice::Context', ::Ice::T_string, ::Ice::T_string)
    end

    if not defined?(::Ice::OperationMode)
        class OperationMode
            include Comparable

            def initialize(val)
                fail("invalid value #{val} for OperationMode") unless(val >= 0 and val < 3)
                @val = val
            end

            def OperationMode.from_int(val)
                raise IndexError, "#{val} is out of range 0..2" if(val < 0 || val > 2)
                @@_values[val]
            end

            def to_s
                @@_names[@val]
            end

            def to_i
                @val
            end

            def <=>(other)
                other.is_a?(OperationMode) or raise ArgumentError, "value must be a OperationMode"
                @val <=> other.to_i
            end

            def hash
                @val.hash
            end

            def inspect
                @@_names[@val] + "(#{@val})"
            end

            def OperationMode.each(&block)
                @@_values.each(&block)
            end

            @@_names = ['Normal', 'Nonmutating', 'Idempotent']
            @@_values = [OperationMode.new(0), OperationMode.new(1), OperationMode.new(2)]

            Normal = @@_values[0]
            Nonmutating = @@_values[1]
            Idempotent = @@_values[2]

            private_class_method :new
        end

        T_OperationMode = ::Ice::__defineEnum('::Ice::OperationMode', OperationMode, [OperationMode::Normal, OperationMode::Nonmutating, OperationMode::Idempotent])
    end

    if not defined?(::Ice::Current)
        class Current
            def initialize(adapter=nil, con=nil, id=::Ice::Identity.new, facet='', operation='', mode=::Ice::OperationMode::Normal, ctx=nil, requestId=0)
                @adapter = adapter
                @con = con
                @id = id
                @facet = facet
                @operation = operation
                @mode = mode
                @ctx = ctx
                @requestId = requestId
            end

            def hash
                _h = 0
                _h = 5 * _h + @adapter.hash
                _h = 5 * _h + @con.hash
                _h = 5 * _h + @id.hash
                _h = 5 * _h + @facet.hash
                _h = 5 * _h + @operation.hash
                _h = 5 * _h + @mode.hash
                _h = 5 * _h + @ctx.hash
                _h = 5 * _h + @requestId.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @adapter != other.adapter or
                    @con != other.con or
                    @id != other.id or
                    @facet != other.facet or
                    @operation != other.operation or
                    @mode != other.mode or
                    @ctx != other.ctx or
                    @requestId != other.requestId
                true
            end

            def inspect
                ::Ice::__stringify(self, T_Current)
            end

            attr_accessor :adapter, :con, :id, :facet, :operation, :mode, :ctx, :requestId
        end

        T_Current = ::Ice::__defineStruct('::Ice::Current', Current, [
            ["adapter", ::Ice::T_ObjectAdapter],
            ["con", ::Ice::T_Connection],
            ["id", ::Ice::T_Identity],
            ["facet", ::Ice::T_string],
            ["operation", ::Ice::T_string],
            ["mode", ::Ice::T_OperationMode],
            ["ctx", ::Ice::T_Context],
            ["requestId", ::Ice::T_int]
        ])
    end
end
