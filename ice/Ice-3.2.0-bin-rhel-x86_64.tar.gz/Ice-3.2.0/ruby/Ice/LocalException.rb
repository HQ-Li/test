# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `LocalException.ice'

require 'Ice'
require 'Ice/Identity.rb'
require 'Ice/BuiltinSequences.rb'

module Ice

    if not defined?(::Ice::InitializationException)
        class InitializationException < Ice::LocalException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'Ice::InitializationException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_InitializationException = ::Ice::__defineException('::Ice::InitializationException', InitializationException, nil, [["reason", ::Ice::T_string]])
        InitializationException::ICE_TYPE = T_InitializationException
    end

    if not defined?(::Ice::PluginInitializationException)
        class PluginInitializationException < Ice::LocalException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'Ice::PluginInitializationException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_PluginInitializationException = ::Ice::__defineException('::Ice::PluginInitializationException', PluginInitializationException, nil, [["reason", ::Ice::T_string]])
        PluginInitializationException::ICE_TYPE = T_PluginInitializationException
    end

    if not defined?(::Ice::CollocationOptimizationException)
        class CollocationOptimizationException < Ice::LocalException
            def initialize
            end

            def to_s
                'Ice::CollocationOptimizationException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_CollocationOptimizationException = ::Ice::__defineException('::Ice::CollocationOptimizationException', CollocationOptimizationException, nil, [])
        CollocationOptimizationException::ICE_TYPE = T_CollocationOptimizationException
    end

    if not defined?(::Ice::AlreadyRegisteredException)
        class AlreadyRegisteredException < Ice::LocalException
            def initialize(kindOfObject='', id='')
                @kindOfObject = kindOfObject
                @id = id
            end

            def to_s
                'Ice::AlreadyRegisteredException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :kindOfObject, :id
        end

        T_AlreadyRegisteredException = ::Ice::__defineException('::Ice::AlreadyRegisteredException', AlreadyRegisteredException, nil, [
            ["kindOfObject", ::Ice::T_string],
            ["id", ::Ice::T_string]
        ])
        AlreadyRegisteredException::ICE_TYPE = T_AlreadyRegisteredException
    end

    if not defined?(::Ice::NotRegisteredException)
        class NotRegisteredException < Ice::LocalException
            def initialize(kindOfObject='', id='')
                @kindOfObject = kindOfObject
                @id = id
            end

            def to_s
                'Ice::NotRegisteredException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :kindOfObject, :id
        end

        T_NotRegisteredException = ::Ice::__defineException('::Ice::NotRegisteredException', NotRegisteredException, nil, [
            ["kindOfObject", ::Ice::T_string],
            ["id", ::Ice::T_string]
        ])
        NotRegisteredException::ICE_TYPE = T_NotRegisteredException
    end

    if not defined?(::Ice::TwowayOnlyException)
        class TwowayOnlyException < Ice::LocalException
            def initialize(operation='')
                @operation = operation
            end

            def to_s
                'Ice::TwowayOnlyException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :operation
        end

        T_TwowayOnlyException = ::Ice::__defineException('::Ice::TwowayOnlyException', TwowayOnlyException, nil, [["operation", ::Ice::T_string]])
        TwowayOnlyException::ICE_TYPE = T_TwowayOnlyException
    end

    if not defined?(::Ice::CloneNotImplementedException)
        class CloneNotImplementedException < Ice::LocalException
            def initialize
            end

            def to_s
                'Ice::CloneNotImplementedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_CloneNotImplementedException = ::Ice::__defineException('::Ice::CloneNotImplementedException', CloneNotImplementedException, nil, [])
        CloneNotImplementedException::ICE_TYPE = T_CloneNotImplementedException
    end

    if not defined?(::Ice::UnknownException)
        class UnknownException < Ice::LocalException
            def initialize(unknown='')
                @unknown = unknown
            end

            def to_s
                'Ice::UnknownException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :unknown
        end

        T_UnknownException = ::Ice::__defineException('::Ice::UnknownException', UnknownException, nil, [["unknown", ::Ice::T_string]])
        UnknownException::ICE_TYPE = T_UnknownException
    end

    if not defined?(::Ice::UnknownLocalException)
        class UnknownLocalException < ::Ice::UnknownException
            def initialize(unknown='')
                super(unknown)
            end

            def to_s
                'Ice::UnknownLocalException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_UnknownLocalException = ::Ice::__defineException('::Ice::UnknownLocalException', UnknownLocalException, ::Ice::T_UnknownException, [])
        UnknownLocalException::ICE_TYPE = T_UnknownLocalException
    end

    if not defined?(::Ice::UnknownUserException)
        class UnknownUserException < ::Ice::UnknownException
            def initialize(unknown='')
                super(unknown)
            end

            def to_s
                'Ice::UnknownUserException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_UnknownUserException = ::Ice::__defineException('::Ice::UnknownUserException', UnknownUserException, ::Ice::T_UnknownException, [])
        UnknownUserException::ICE_TYPE = T_UnknownUserException
    end

    if not defined?(::Ice::VersionMismatchException)
        class VersionMismatchException < Ice::LocalException
            def initialize
            end

            def to_s
                'Ice::VersionMismatchException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_VersionMismatchException = ::Ice::__defineException('::Ice::VersionMismatchException', VersionMismatchException, nil, [])
        VersionMismatchException::ICE_TYPE = T_VersionMismatchException
    end

    if not defined?(::Ice::CommunicatorDestroyedException)
        class CommunicatorDestroyedException < Ice::LocalException
            def initialize
            end

            def to_s
                'Ice::CommunicatorDestroyedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_CommunicatorDestroyedException = ::Ice::__defineException('::Ice::CommunicatorDestroyedException', CommunicatorDestroyedException, nil, [])
        CommunicatorDestroyedException::ICE_TYPE = T_CommunicatorDestroyedException
    end

    if not defined?(::Ice::ObjectAdapterDeactivatedException)
        class ObjectAdapterDeactivatedException < Ice::LocalException
            def initialize(name='')
                @name = name
            end

            def to_s
                'Ice::ObjectAdapterDeactivatedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :name
        end

        T_ObjectAdapterDeactivatedException = ::Ice::__defineException('::Ice::ObjectAdapterDeactivatedException', ObjectAdapterDeactivatedException, nil, [["name", ::Ice::T_string]])
        ObjectAdapterDeactivatedException::ICE_TYPE = T_ObjectAdapterDeactivatedException
    end

    if not defined?(::Ice::ObjectAdapterIdInUseException)
        class ObjectAdapterIdInUseException < Ice::LocalException
            def initialize(id='')
                @id = id
            end

            def to_s
                'Ice::ObjectAdapterIdInUseException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id
        end

        T_ObjectAdapterIdInUseException = ::Ice::__defineException('::Ice::ObjectAdapterIdInUseException', ObjectAdapterIdInUseException, nil, [["id", ::Ice::T_string]])
        ObjectAdapterIdInUseException::ICE_TYPE = T_ObjectAdapterIdInUseException
    end

    if not defined?(::Ice::NoEndpointException)
        class NoEndpointException < Ice::LocalException
            def initialize(proxy='')
                @proxy = proxy
            end

            def to_s
                'Ice::NoEndpointException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :proxy
        end

        T_NoEndpointException = ::Ice::__defineException('::Ice::NoEndpointException', NoEndpointException, nil, [["proxy", ::Ice::T_string]])
        NoEndpointException::ICE_TYPE = T_NoEndpointException
    end

    if not defined?(::Ice::EndpointParseException)
        class EndpointParseException < Ice::LocalException
            def initialize(str='')
                @str = str
            end

            def to_s
                'Ice::EndpointParseException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :str
        end

        T_EndpointParseException = ::Ice::__defineException('::Ice::EndpointParseException', EndpointParseException, nil, [["str", ::Ice::T_string]])
        EndpointParseException::ICE_TYPE = T_EndpointParseException
    end

    if not defined?(::Ice::EndpointSelectionTypeParseException)
        class EndpointSelectionTypeParseException < Ice::LocalException
            def initialize(str='')
                @str = str
            end

            def to_s
                'Ice::EndpointSelectionTypeParseException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :str
        end

        T_EndpointSelectionTypeParseException = ::Ice::__defineException('::Ice::EndpointSelectionTypeParseException', EndpointSelectionTypeParseException, nil, [["str", ::Ice::T_string]])
        EndpointSelectionTypeParseException::ICE_TYPE = T_EndpointSelectionTypeParseException
    end

    if not defined?(::Ice::IdentityParseException)
        class IdentityParseException < Ice::LocalException
            def initialize(str='')
                @str = str
            end

            def to_s
                'Ice::IdentityParseException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :str
        end

        T_IdentityParseException = ::Ice::__defineException('::Ice::IdentityParseException', IdentityParseException, nil, [["str", ::Ice::T_string]])
        IdentityParseException::ICE_TYPE = T_IdentityParseException
    end

    if not defined?(::Ice::ProxyParseException)
        class ProxyParseException < Ice::LocalException
            def initialize(str='')
                @str = str
            end

            def to_s
                'Ice::ProxyParseException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :str
        end

        T_ProxyParseException = ::Ice::__defineException('::Ice::ProxyParseException', ProxyParseException, nil, [["str", ::Ice::T_string]])
        ProxyParseException::ICE_TYPE = T_ProxyParseException
    end

    if not defined?(::Ice::IllegalIdentityException)
        class IllegalIdentityException < Ice::LocalException
            def initialize(id=::Ice::Identity.new)
                @id = id
            end

            def to_s
                'Ice::IllegalIdentityException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id
        end

        T_IllegalIdentityException = ::Ice::__defineException('::Ice::IllegalIdentityException', IllegalIdentityException, nil, [["id", ::Ice::T_Identity]])
        IllegalIdentityException::ICE_TYPE = T_IllegalIdentityException
    end

    if not defined?(::Ice::RequestFailedException)
        class RequestFailedException < Ice::LocalException
            def initialize(id=::Ice::Identity.new, facet='', operation='')
                @id = id
                @facet = facet
                @operation = operation
            end

            def to_s
                'Ice::RequestFailedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :id, :facet, :operation
        end

        T_RequestFailedException = ::Ice::__defineException('::Ice::RequestFailedException', RequestFailedException, nil, [
            ["id", ::Ice::T_Identity],
            ["facet", ::Ice::T_string],
            ["operation", ::Ice::T_string]
        ])
        RequestFailedException::ICE_TYPE = T_RequestFailedException
    end

    if not defined?(::Ice::ObjectNotExistException)
        class ObjectNotExistException < ::Ice::RequestFailedException
            def initialize(id=::Ice::Identity.new, facet='', operation='')
                super(id, facet, operation)
            end

            def to_s
                'Ice::ObjectNotExistException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ObjectNotExistException = ::Ice::__defineException('::Ice::ObjectNotExistException', ObjectNotExistException, ::Ice::T_RequestFailedException, [])
        ObjectNotExistException::ICE_TYPE = T_ObjectNotExistException
    end

    if not defined?(::Ice::FacetNotExistException)
        class FacetNotExistException < ::Ice::RequestFailedException
            def initialize(id=::Ice::Identity.new, facet='', operation='')
                super(id, facet, operation)
            end

            def to_s
                'Ice::FacetNotExistException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_FacetNotExistException = ::Ice::__defineException('::Ice::FacetNotExistException', FacetNotExistException, ::Ice::T_RequestFailedException, [])
        FacetNotExistException::ICE_TYPE = T_FacetNotExistException
    end

    if not defined?(::Ice::OperationNotExistException)
        class OperationNotExistException < ::Ice::RequestFailedException
            def initialize(id=::Ice::Identity.new, facet='', operation='')
                super(id, facet, operation)
            end

            def to_s
                'Ice::OperationNotExistException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_OperationNotExistException = ::Ice::__defineException('::Ice::OperationNotExistException', OperationNotExistException, ::Ice::T_RequestFailedException, [])
        OperationNotExistException::ICE_TYPE = T_OperationNotExistException
    end

    if not defined?(::Ice::SyscallException)
        class SyscallException < Ice::LocalException
            def initialize(error=0)
                @error = error
            end

            def to_s
                'Ice::SyscallException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :error
        end

        T_SyscallException = ::Ice::__defineException('::Ice::SyscallException', SyscallException, nil, [["error", ::Ice::T_int]])
        SyscallException::ICE_TYPE = T_SyscallException
    end

    if not defined?(::Ice::SocketException)
        class SocketException < ::Ice::SyscallException
            def initialize(error=0)
                super(error)
            end

            def to_s
                'Ice::SocketException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_SocketException = ::Ice::__defineException('::Ice::SocketException', SocketException, ::Ice::T_SyscallException, [])
        SocketException::ICE_TYPE = T_SocketException
    end

    if not defined?(::Ice::FileException)
        class FileException < ::Ice::SyscallException
            def initialize(error=0, path='')
                super(error)
                @path = path
            end

            def to_s
                'Ice::FileException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :path
        end

        T_FileException = ::Ice::__defineException('::Ice::FileException', FileException, ::Ice::T_SyscallException, [["path", ::Ice::T_string]])
        FileException::ICE_TYPE = T_FileException
    end

    if not defined?(::Ice::ConnectFailedException)
        class ConnectFailedException < ::Ice::SocketException
            def initialize(error=0)
                super(error)
            end

            def to_s
                'Ice::ConnectFailedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ConnectFailedException = ::Ice::__defineException('::Ice::ConnectFailedException', ConnectFailedException, ::Ice::T_SocketException, [])
        ConnectFailedException::ICE_TYPE = T_ConnectFailedException
    end

    if not defined?(::Ice::ConnectionRefusedException)
        class ConnectionRefusedException < ::Ice::ConnectFailedException
            def initialize(error=0)
                super(error)
            end

            def to_s
                'Ice::ConnectionRefusedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ConnectionRefusedException = ::Ice::__defineException('::Ice::ConnectionRefusedException', ConnectionRefusedException, ::Ice::T_ConnectFailedException, [])
        ConnectionRefusedException::ICE_TYPE = T_ConnectionRefusedException
    end

    if not defined?(::Ice::ConnectionLostException)
        class ConnectionLostException < ::Ice::SocketException
            def initialize(error=0)
                super(error)
            end

            def to_s
                'Ice::ConnectionLostException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ConnectionLostException = ::Ice::__defineException('::Ice::ConnectionLostException', ConnectionLostException, ::Ice::T_SocketException, [])
        ConnectionLostException::ICE_TYPE = T_ConnectionLostException
    end

    if not defined?(::Ice::DNSException)
        class DNSException < Ice::LocalException
            def initialize(error=0, host='')
                @error = error
                @host = host
            end

            def to_s
                'Ice::DNSException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :error, :host
        end

        T_DNSException = ::Ice::__defineException('::Ice::DNSException', DNSException, nil, [
            ["error", ::Ice::T_int],
            ["host", ::Ice::T_string]
        ])
        DNSException::ICE_TYPE = T_DNSException
    end

    if not defined?(::Ice::TimeoutException)
        class TimeoutException < Ice::LocalException
            def initialize
            end

            def to_s
                'Ice::TimeoutException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_TimeoutException = ::Ice::__defineException('::Ice::TimeoutException', TimeoutException, nil, [])
        TimeoutException::ICE_TYPE = T_TimeoutException
    end

    if not defined?(::Ice::ConnectTimeoutException)
        class ConnectTimeoutException < ::Ice::TimeoutException
            def initialize
            end

            def to_s
                'Ice::ConnectTimeoutException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ConnectTimeoutException = ::Ice::__defineException('::Ice::ConnectTimeoutException', ConnectTimeoutException, ::Ice::T_TimeoutException, [])
        ConnectTimeoutException::ICE_TYPE = T_ConnectTimeoutException
    end

    if not defined?(::Ice::CloseTimeoutException)
        class CloseTimeoutException < ::Ice::TimeoutException
            def initialize
            end

            def to_s
                'Ice::CloseTimeoutException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_CloseTimeoutException = ::Ice::__defineException('::Ice::CloseTimeoutException', CloseTimeoutException, ::Ice::T_TimeoutException, [])
        CloseTimeoutException::ICE_TYPE = T_CloseTimeoutException
    end

    if not defined?(::Ice::ConnectionTimeoutException)
        class ConnectionTimeoutException < ::Ice::TimeoutException
            def initialize
            end

            def to_s
                'Ice::ConnectionTimeoutException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ConnectionTimeoutException = ::Ice::__defineException('::Ice::ConnectionTimeoutException', ConnectionTimeoutException, ::Ice::T_TimeoutException, [])
        ConnectionTimeoutException::ICE_TYPE = T_ConnectionTimeoutException
    end

    if not defined?(::Ice::ProtocolException)
        class ProtocolException < Ice::LocalException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'Ice::ProtocolException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_ProtocolException = ::Ice::__defineException('::Ice::ProtocolException', ProtocolException, nil, [["reason", ::Ice::T_string]])
        ProtocolException::ICE_TYPE = T_ProtocolException
    end

    if not defined?(::Ice::BadMagicException)
        class BadMagicException < ::Ice::ProtocolException
            def initialize(reason='', badMagic=nil)
                super(reason)
                @badMagic = badMagic
            end

            def to_s
                'Ice::BadMagicException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :badMagic
        end

        T_BadMagicException = ::Ice::__defineException('::Ice::BadMagicException', BadMagicException, ::Ice::T_ProtocolException, [["badMagic", ::Ice::T_ByteSeq]])
        BadMagicException::ICE_TYPE = T_BadMagicException
    end

    if not defined?(::Ice::UnsupportedProtocolException)
        class UnsupportedProtocolException < ::Ice::ProtocolException
            def initialize(reason='', badMajor=0, badMinor=0, major=0, minor=0)
                super(reason)
                @badMajor = badMajor
                @badMinor = badMinor
                @major = major
                @minor = minor
            end

            def to_s
                'Ice::UnsupportedProtocolException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :badMajor, :badMinor, :major, :minor
        end

        T_UnsupportedProtocolException = ::Ice::__defineException('::Ice::UnsupportedProtocolException', UnsupportedProtocolException, ::Ice::T_ProtocolException, [
            ["badMajor", ::Ice::T_int],
            ["badMinor", ::Ice::T_int],
            ["major", ::Ice::T_int],
            ["minor", ::Ice::T_int]
        ])
        UnsupportedProtocolException::ICE_TYPE = T_UnsupportedProtocolException
    end

    if not defined?(::Ice::UnsupportedEncodingException)
        class UnsupportedEncodingException < ::Ice::ProtocolException
            def initialize(reason='', badMajor=0, badMinor=0, major=0, minor=0)
                super(reason)
                @badMajor = badMajor
                @badMinor = badMinor
                @major = major
                @minor = minor
            end

            def to_s
                'Ice::UnsupportedEncodingException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :badMajor, :badMinor, :major, :minor
        end

        T_UnsupportedEncodingException = ::Ice::__defineException('::Ice::UnsupportedEncodingException', UnsupportedEncodingException, ::Ice::T_ProtocolException, [
            ["badMajor", ::Ice::T_int],
            ["badMinor", ::Ice::T_int],
            ["major", ::Ice::T_int],
            ["minor", ::Ice::T_int]
        ])
        UnsupportedEncodingException::ICE_TYPE = T_UnsupportedEncodingException
    end

    if not defined?(::Ice::UnknownMessageException)
        class UnknownMessageException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::UnknownMessageException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_UnknownMessageException = ::Ice::__defineException('::Ice::UnknownMessageException', UnknownMessageException, ::Ice::T_ProtocolException, [])
        UnknownMessageException::ICE_TYPE = T_UnknownMessageException
    end

    if not defined?(::Ice::ConnectionNotValidatedException)
        class ConnectionNotValidatedException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::ConnectionNotValidatedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ConnectionNotValidatedException = ::Ice::__defineException('::Ice::ConnectionNotValidatedException', ConnectionNotValidatedException, ::Ice::T_ProtocolException, [])
        ConnectionNotValidatedException::ICE_TYPE = T_ConnectionNotValidatedException
    end

    if not defined?(::Ice::UnknownRequestIdException)
        class UnknownRequestIdException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::UnknownRequestIdException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_UnknownRequestIdException = ::Ice::__defineException('::Ice::UnknownRequestIdException', UnknownRequestIdException, ::Ice::T_ProtocolException, [])
        UnknownRequestIdException::ICE_TYPE = T_UnknownRequestIdException
    end

    if not defined?(::Ice::UnknownReplyStatusException)
        class UnknownReplyStatusException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::UnknownReplyStatusException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_UnknownReplyStatusException = ::Ice::__defineException('::Ice::UnknownReplyStatusException', UnknownReplyStatusException, ::Ice::T_ProtocolException, [])
        UnknownReplyStatusException::ICE_TYPE = T_UnknownReplyStatusException
    end

    if not defined?(::Ice::CloseConnectionException)
        class CloseConnectionException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::CloseConnectionException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_CloseConnectionException = ::Ice::__defineException('::Ice::CloseConnectionException', CloseConnectionException, ::Ice::T_ProtocolException, [])
        CloseConnectionException::ICE_TYPE = T_CloseConnectionException
    end

    if not defined?(::Ice::ForcedCloseConnectionException)
        class ForcedCloseConnectionException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::ForcedCloseConnectionException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ForcedCloseConnectionException = ::Ice::__defineException('::Ice::ForcedCloseConnectionException', ForcedCloseConnectionException, ::Ice::T_ProtocolException, [])
        ForcedCloseConnectionException::ICE_TYPE = T_ForcedCloseConnectionException
    end

    if not defined?(::Ice::IllegalMessageSizeException)
        class IllegalMessageSizeException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::IllegalMessageSizeException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_IllegalMessageSizeException = ::Ice::__defineException('::Ice::IllegalMessageSizeException', IllegalMessageSizeException, ::Ice::T_ProtocolException, [])
        IllegalMessageSizeException::ICE_TYPE = T_IllegalMessageSizeException
    end

    if not defined?(::Ice::CompressionException)
        class CompressionException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::CompressionException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_CompressionException = ::Ice::__defineException('::Ice::CompressionException', CompressionException, ::Ice::T_ProtocolException, [])
        CompressionException::ICE_TYPE = T_CompressionException
    end

    if not defined?(::Ice::DatagramLimitException)
        class DatagramLimitException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::DatagramLimitException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_DatagramLimitException = ::Ice::__defineException('::Ice::DatagramLimitException', DatagramLimitException, ::Ice::T_ProtocolException, [])
        DatagramLimitException::ICE_TYPE = T_DatagramLimitException
    end

    if not defined?(::Ice::MarshalException)
        class MarshalException < ::Ice::ProtocolException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::MarshalException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_MarshalException = ::Ice::__defineException('::Ice::MarshalException', MarshalException, ::Ice::T_ProtocolException, [])
        MarshalException::ICE_TYPE = T_MarshalException
    end

    if not defined?(::Ice::ProxyUnmarshalException)
        class ProxyUnmarshalException < ::Ice::MarshalException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::ProxyUnmarshalException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ProxyUnmarshalException = ::Ice::__defineException('::Ice::ProxyUnmarshalException', ProxyUnmarshalException, ::Ice::T_MarshalException, [])
        ProxyUnmarshalException::ICE_TYPE = T_ProxyUnmarshalException
    end

    if not defined?(::Ice::UnmarshalOutOfBoundsException)
        class UnmarshalOutOfBoundsException < ::Ice::MarshalException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::UnmarshalOutOfBoundsException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_UnmarshalOutOfBoundsException = ::Ice::__defineException('::Ice::UnmarshalOutOfBoundsException', UnmarshalOutOfBoundsException, ::Ice::T_MarshalException, [])
        UnmarshalOutOfBoundsException::ICE_TYPE = T_UnmarshalOutOfBoundsException
    end

    if not defined?(::Ice::IllegalIndirectionException)
        class IllegalIndirectionException < ::Ice::MarshalException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::IllegalIndirectionException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_IllegalIndirectionException = ::Ice::__defineException('::Ice::IllegalIndirectionException', IllegalIndirectionException, ::Ice::T_MarshalException, [])
        IllegalIndirectionException::ICE_TYPE = T_IllegalIndirectionException
    end

    if not defined?(::Ice::NoObjectFactoryException)
        class NoObjectFactoryException < ::Ice::MarshalException
            def initialize(reason='', type='')
                super(reason)
                @type = type
            end

            def to_s
                'Ice::NoObjectFactoryException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :type
        end

        T_NoObjectFactoryException = ::Ice::__defineException('::Ice::NoObjectFactoryException', NoObjectFactoryException, ::Ice::T_MarshalException, [["type", ::Ice::T_string]])
        NoObjectFactoryException::ICE_TYPE = T_NoObjectFactoryException
    end

    if not defined?(::Ice::UnexpectedObjectException)
        class UnexpectedObjectException < ::Ice::MarshalException
            def initialize(reason='', type='', expectedType='')
                super(reason)
                @type = type
                @expectedType = expectedType
            end

            def to_s
                'Ice::UnexpectedObjectException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :type, :expectedType
        end

        T_UnexpectedObjectException = ::Ice::__defineException('::Ice::UnexpectedObjectException', UnexpectedObjectException, ::Ice::T_MarshalException, [
            ["type", ::Ice::T_string],
            ["expectedType", ::Ice::T_string]
        ])
        UnexpectedObjectException::ICE_TYPE = T_UnexpectedObjectException
    end

    if not defined?(::Ice::MemoryLimitException)
        class MemoryLimitException < ::Ice::MarshalException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::MemoryLimitException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_MemoryLimitException = ::Ice::__defineException('::Ice::MemoryLimitException', MemoryLimitException, ::Ice::T_MarshalException, [])
        MemoryLimitException::ICE_TYPE = T_MemoryLimitException
    end

    if not defined?(::Ice::StringConversionException)
        class StringConversionException < ::Ice::MarshalException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::StringConversionException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_StringConversionException = ::Ice::__defineException('::Ice::StringConversionException', StringConversionException, ::Ice::T_MarshalException, [])
        StringConversionException::ICE_TYPE = T_StringConversionException
    end

    if not defined?(::Ice::EncapsulationException)
        class EncapsulationException < ::Ice::MarshalException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::EncapsulationException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_EncapsulationException = ::Ice::__defineException('::Ice::EncapsulationException', EncapsulationException, ::Ice::T_MarshalException, [])
        EncapsulationException::ICE_TYPE = T_EncapsulationException
    end

    if not defined?(::Ice::NegativeSizeException)
        class NegativeSizeException < ::Ice::MarshalException
            def initialize(reason='')
                super(reason)
            end

            def to_s
                'Ice::NegativeSizeException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_NegativeSizeException = ::Ice::__defineException('::Ice::NegativeSizeException', NegativeSizeException, ::Ice::T_MarshalException, [])
        NegativeSizeException::ICE_TYPE = T_NegativeSizeException
    end

    if not defined?(::Ice::FeatureNotSupportedException)
        class FeatureNotSupportedException < Ice::LocalException
            def initialize(unsupportedFeature='')
                @unsupportedFeature = unsupportedFeature
            end

            def to_s
                'Ice::FeatureNotSupportedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :unsupportedFeature
        end

        T_FeatureNotSupportedException = ::Ice::__defineException('::Ice::FeatureNotSupportedException', FeatureNotSupportedException, nil, [["unsupportedFeature", ::Ice::T_string]])
        FeatureNotSupportedException::ICE_TYPE = T_FeatureNotSupportedException
    end

    if not defined?(::Ice::SecurityException)
        class SecurityException < Ice::LocalException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'Ice::SecurityException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_SecurityException = ::Ice::__defineException('::Ice::SecurityException', SecurityException, nil, [["reason", ::Ice::T_string]])
        SecurityException::ICE_TYPE = T_SecurityException
    end

    if not defined?(::Ice::FixedProxyException)
        class FixedProxyException < Ice::LocalException
            def initialize
            end

            def to_s
                'Ice::FixedProxyException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_FixedProxyException = ::Ice::__defineException('::Ice::FixedProxyException', FixedProxyException, nil, [])
        FixedProxyException::ICE_TYPE = T_FixedProxyException
    end
end
