# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Locator.ice'

require 'Ice'
require 'Ice/Identity.rb'
require 'Ice/ProcessF.rb'

module Ice

    if not defined?(::Ice::AdapterNotFoundException)
        class AdapterNotFoundException < Ice::UserException
            def initialize
            end

            def to_s
                'Ice::AdapterNotFoundException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_AdapterNotFoundException = ::Ice::__defineException('::Ice::AdapterNotFoundException', AdapterNotFoundException, nil, [])
        AdapterNotFoundException::ICE_TYPE = T_AdapterNotFoundException
    end

    if not defined?(::Ice::InvalidReplicaGroupIdException)
        class InvalidReplicaGroupIdException < Ice::UserException
            def initialize
            end

            def to_s
                'Ice::InvalidReplicaGroupIdException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_InvalidReplicaGroupIdException = ::Ice::__defineException('::Ice::InvalidReplicaGroupIdException', InvalidReplicaGroupIdException, nil, [])
        InvalidReplicaGroupIdException::ICE_TYPE = T_InvalidReplicaGroupIdException
    end

    if not defined?(::Ice::AdapterAlreadyActiveException)
        class AdapterAlreadyActiveException < Ice::UserException
            def initialize
            end

            def to_s
                'Ice::AdapterAlreadyActiveException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_AdapterAlreadyActiveException = ::Ice::__defineException('::Ice::AdapterAlreadyActiveException', AdapterAlreadyActiveException, nil, [])
        AdapterAlreadyActiveException::ICE_TYPE = T_AdapterAlreadyActiveException
    end

    if not defined?(::Ice::ObjectNotFoundException)
        class ObjectNotFoundException < Ice::UserException
            def initialize
            end

            def to_s
                'Ice::ObjectNotFoundException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ObjectNotFoundException = ::Ice::__defineException('::Ice::ObjectNotFoundException', ObjectNotFoundException, nil, [])
        ObjectNotFoundException::ICE_TYPE = T_ObjectNotFoundException
    end

    if not defined?(::Ice::ServerNotFoundException)
        class ServerNotFoundException < Ice::UserException
            def initialize
            end

            def to_s
                'Ice::ServerNotFoundException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_ServerNotFoundException = ::Ice::__defineException('::Ice::ServerNotFoundException', ServerNotFoundException, nil, [])
        ServerNotFoundException::ICE_TYPE = T_ServerNotFoundException
    end

    if not defined?(::Ice::T_LocatorRegistry)
        T_LocatorRegistry = ::Ice::__declareClass('::Ice::LocatorRegistry')
        T_LocatorRegistryPrx = ::Ice::__declareProxy('::Ice::LocatorRegistry')
    end

    if not defined?(::Ice::Locator_mixin)
        module Locator_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Locator', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Ice::Locator'
            end

            #
            # Operation signatures.
            #
            # def findObjectById(id, current=nil)
            # def findAdapterById(id, current=nil)
            # def getRegistry(current=nil)

            def inspect
                ::Ice::__stringify(self, T_Locator)
            end
        end
        module LocatorPrx_mixin

            def findObjectById(id, _ctx=nil)
                Locator_mixin::OP_findObjectById.invoke(self, [id], _ctx)
            end

            def findAdapterById(id, _ctx=nil)
                Locator_mixin::OP_findAdapterById.invoke(self, [id], _ctx)
            end

            def getRegistry(_ctx=nil)
                Locator_mixin::OP_getRegistry.invoke(self, [], _ctx)
            end
        end
        class LocatorPrx < ::Ice::ObjectPrx
            include LocatorPrx_mixin

            def LocatorPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Ice::Locator', facetOrCtx, _ctx)
            end

            def LocatorPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Ice::T_Locator)
            T_Locator = ::Ice::__declareClass('::Ice::Locator')
            T_LocatorPrx = ::Ice::__declareProxy('::Ice::Locator')
        end

        T_Locator.defineClass(nil, true, nil, [], [])
        Locator_mixin::ICE_TYPE = T_Locator

        T_LocatorPrx.defineProxy(LocatorPrx, T_Locator)
        LocatorPrx::ICE_TYPE = T_LocatorPrx

        Locator_mixin::OP_findObjectById = ::Ice::__defineOperation('findObjectById', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, true, [::Ice::T_Identity], [], ::Ice::T_ObjectPrx, [::Ice::T_ObjectNotFoundException])
        Locator_mixin::OP_findAdapterById = ::Ice::__defineOperation('findAdapterById', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, true, [::Ice::T_string], [], ::Ice::T_ObjectPrx, [::Ice::T_AdapterNotFoundException])
        Locator_mixin::OP_getRegistry = ::Ice::__defineOperation('getRegistry', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_LocatorRegistryPrx, [])
    end

    if not defined?(::Ice::LocatorRegistry_mixin)
        module LocatorRegistry_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::LocatorRegistry', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Ice::LocatorRegistry'
            end

            #
            # Operation signatures.
            #
            # def setAdapterDirectProxy(id, proxy, current=nil)
            # def setReplicatedAdapterDirectProxy(adapterId, replicaGroupId, p, current=nil)
            # def setServerProcessProxy(id, proxy, current=nil)

            def inspect
                ::Ice::__stringify(self, T_LocatorRegistry)
            end
        end
        module LocatorRegistryPrx_mixin

            def setAdapterDirectProxy(id, proxy, _ctx=nil)
                LocatorRegistry_mixin::OP_setAdapterDirectProxy.invoke(self, [id, proxy], _ctx)
            end

            def setAdapterDirectProxy_async(_cb, id, proxy, _ctx=nil)
                LocatorRegistry_mixin::OP_setAdapterDirectProxy.invokeAsync(self, _cb, [id, proxy], _ctx)
            end

            def setReplicatedAdapterDirectProxy(adapterId, replicaGroupId, p, _ctx=nil)
                LocatorRegistry_mixin::OP_setReplicatedAdapterDirectProxy.invoke(self, [adapterId, replicaGroupId, p], _ctx)
            end

            def setReplicatedAdapterDirectProxy_async(_cb, adapterId, replicaGroupId, p, _ctx=nil)
                LocatorRegistry_mixin::OP_setReplicatedAdapterDirectProxy.invokeAsync(self, _cb, [adapterId, replicaGroupId, p], _ctx)
            end

            def setServerProcessProxy(id, proxy, _ctx=nil)
                LocatorRegistry_mixin::OP_setServerProcessProxy.invoke(self, [id, proxy], _ctx)
            end
        end
        class LocatorRegistryPrx < ::Ice::ObjectPrx
            include LocatorRegistryPrx_mixin

            def LocatorRegistryPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Ice::LocatorRegistry', facetOrCtx, _ctx)
            end

            def LocatorRegistryPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Ice::T_LocatorRegistry)
            T_LocatorRegistry = ::Ice::__declareClass('::Ice::LocatorRegistry')
            T_LocatorRegistryPrx = ::Ice::__declareProxy('::Ice::LocatorRegistry')
        end

        T_LocatorRegistry.defineClass(nil, true, nil, [], [])
        LocatorRegistry_mixin::ICE_TYPE = T_LocatorRegistry

        T_LocatorRegistryPrx.defineProxy(LocatorRegistryPrx, T_LocatorRegistry)
        LocatorRegistryPrx::ICE_TYPE = T_LocatorRegistryPrx

        LocatorRegistry_mixin::OP_setAdapterDirectProxy = ::Ice::__defineOperation('setAdapterDirectProxy', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, true, [::Ice::T_string, ::Ice::T_ObjectPrx], [], nil, [::Ice::T_AdapterNotFoundException, ::Ice::T_AdapterAlreadyActiveException])
        LocatorRegistry_mixin::OP_setReplicatedAdapterDirectProxy = ::Ice::__defineOperation('setReplicatedAdapterDirectProxy', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, true, [::Ice::T_string, ::Ice::T_string, ::Ice::T_ObjectPrx], [], nil, [::Ice::T_AdapterNotFoundException, ::Ice::T_AdapterAlreadyActiveException, ::Ice::T_InvalidReplicaGroupIdException])
        LocatorRegistry_mixin::OP_setServerProcessProxy = ::Ice::__defineOperation('setServerProcessProxy', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, true, [::Ice::T_string, ::Ice::T_ProcessPrx], [], nil, [::Ice::T_ServerNotFoundException])
    end
end
