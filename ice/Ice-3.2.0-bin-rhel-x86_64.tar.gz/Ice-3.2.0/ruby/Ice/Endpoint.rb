# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Endpoint.ice'

require 'Ice'

module Ice

    if not defined?(::Ice::EndpointSelectionType)
        class EndpointSelectionType
            include Comparable

            def initialize(val)
                fail("invalid value #{val} for EndpointSelectionType") unless(val >= 0 and val < 2)
                @val = val
            end

            def EndpointSelectionType.from_int(val)
                raise IndexError, "#{val} is out of range 0..1" if(val < 0 || val > 1)
                @@_values[val]
            end

            def to_s
                @@_names[@val]
            end

            def to_i
                @val
            end

            def <=>(other)
                other.is_a?(EndpointSelectionType) or raise ArgumentError, "value must be a EndpointSelectionType"
                @val <=> other.to_i
            end

            def hash
                @val.hash
            end

            def inspect
                @@_names[@val] + "(#{@val})"
            end

            def EndpointSelectionType.each(&block)
                @@_values.each(&block)
            end

            @@_names = ['Random', 'Ordered']
            @@_values = [EndpointSelectionType.new(0), EndpointSelectionType.new(1)]

            Random = @@_values[0]
            Ordered = @@_values[1]

            private_class_method :new
        end

        T_EndpointSelectionType = ::Ice::__defineEnum('::Ice::EndpointSelectionType', EndpointSelectionType, [EndpointSelectionType::Random, EndpointSelectionType::Ordered])
    end

    if not defined?(::Ice::Endpoint_mixin)
        module Endpoint_mixin

            #
            # Operation signatures.
            #
            # def toString()

            def inspect
                ::Ice::__stringify(self, T_Endpoint)
            end
        end

        if not defined?(::Ice::T_Endpoint)
            T_Endpoint = ::Ice::__declareClass('::Ice::Endpoint')
        end

        T_Endpoint.defineClass(nil, true, nil, [], [])
        Endpoint_mixin::ICE_TYPE = T_Endpoint
    end

    if not defined?(::Ice::T_EndpointSeq)
        T_EndpointSeq = ::Ice::__defineSequence('::Ice::EndpointSeq', ::Ice::T_Endpoint)
    end
end
