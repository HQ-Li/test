# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Properties.ice'

require 'Ice'
require 'Ice/BuiltinSequences.rb'

module Ice

    if not defined?(::Ice::T_PropertyDict)
        T_PropertyDict = ::Ice::__defineDictionary('::Ice::PropertyDict', ::Ice::T_string, ::Ice::T_string)
    end

    if not defined?(::Ice::Properties_mixin)
        module Properties_mixin

            #
            # Operation signatures.
            #
            # def getProperty(key)
            # def getPropertyWithDefault(key, value)
            # def getPropertyAsInt(key)
            # def getPropertyAsIntWithDefault(key, value)
            # def getPropertiesForPrefix(prefix)
            # def setProperty(key, value)
            # def getCommandLineOptions()
            # def parseCommandLineOptions(prefix, options)
            # def parseIceCommandLineOptions(options)
            # def load(file)
            # def _clone()

            def inspect
                ::Ice::__stringify(self, T_Properties)
            end
        end

        if not defined?(::Ice::T_Properties)
            T_Properties = ::Ice::__declareClass('::Ice::Properties')
        end

        T_Properties.defineClass(nil, true, nil, [], [])
        Properties_mixin::ICE_TYPE = T_Properties
    end
end
