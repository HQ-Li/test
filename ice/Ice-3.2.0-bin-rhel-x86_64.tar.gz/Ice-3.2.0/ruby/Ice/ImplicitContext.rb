# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `ImplicitContext.ice'

require 'Ice'
require 'Ice/LocalException.rb'
require 'Ice/Current.rb'

module Ice

    if not defined?(::Ice::ImplicitContext_mixin)
        module ImplicitContext_mixin

            #
            # Operation signatures.
            #
            # def getContext()
            # def setContext(newContext)
            # def containsKey(key)
            # def get(key)
            # def put(key, value)
            # def remove(key)

            def inspect
                ::Ice::__stringify(self, T_ImplicitContext)
            end
        end

        if not defined?(::Ice::T_ImplicitContext)
            T_ImplicitContext = ::Ice::__declareClass('::Ice::ImplicitContext')
        end

        T_ImplicitContext.defineClass(nil, true, nil, [], [])
        ImplicitContext_mixin::ICE_TYPE = T_ImplicitContext
    end
end
