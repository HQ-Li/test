# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `LocatorF.ice'

require 'Ice'

module Ice

    if not defined?(::Ice::T_Locator)
        T_Locator = ::Ice::__declareClass('::Ice::Locator')
        T_LocatorPrx = ::Ice::__declareProxy('::Ice::Locator')
    end

    if not defined?(::Ice::T_LocatorRegistry)
        T_LocatorRegistry = ::Ice::__declareClass('::Ice::LocatorRegistry')
        T_LocatorRegistryPrx = ::Ice::__declareProxy('::Ice::LocatorRegistry')
    end
end
