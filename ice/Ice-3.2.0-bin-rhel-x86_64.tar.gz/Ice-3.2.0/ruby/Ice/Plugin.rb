# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Plugin.ice'

require 'Ice'

module Ice

    if not defined?(::Ice::Plugin_mixin)
        module Plugin_mixin

            #
            # Operation signatures.
            #
            # def initialize()
            # def destroy()

            def inspect
                ::Ice::__stringify(self, T_Plugin)
            end
        end

        if not defined?(::Ice::T_Plugin)
            T_Plugin = ::Ice::__declareClass('::Ice::Plugin')
        end

        T_Plugin.defineClass(nil, true, nil, [], [])
        Plugin_mixin::ICE_TYPE = T_Plugin
    end

    if not defined?(::Ice::PluginManager_mixin)
        module PluginManager_mixin

            #
            # Operation signatures.
            #
            # def initializePlugins()
            # def getPlugin(name)
            # def addPlugin(name, pi)
            # def destroy()

            def inspect
                ::Ice::__stringify(self, T_PluginManager)
            end
        end

        if not defined?(::Ice::T_PluginManager)
            T_PluginManager = ::Ice::__declareClass('::Ice::PluginManager')
        end

        T_PluginManager.defineClass(nil, true, nil, [], [])
        PluginManager_mixin::ICE_TYPE = T_PluginManager
    end
end
