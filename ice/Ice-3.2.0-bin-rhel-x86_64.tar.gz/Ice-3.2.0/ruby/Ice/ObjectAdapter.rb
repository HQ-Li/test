# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `ObjectAdapter.ice'

require 'Ice'
require 'Ice/CommunicatorF.rb'
require 'Ice/ServantLocatorF.rb'
require 'Ice/RouterF.rb'
require 'Ice/LocatorF.rb'
require 'Ice/Identity.rb'
require 'Ice/FacetMap.rb'
require 'Ice/Locator.rb'

module Ice

    if not defined?(::Ice::ObjectAdapter_mixin)
        module ObjectAdapter_mixin

            #
            # Operation signatures.
            #
            # def getName()
            # def getCommunicator()
            # def activate()
            # def hold()
            # def waitForHold()
            # def deactivate()
            # def waitForDeactivate()
            # def isDeactivated()
            # def destroy()
            # def add(servant, id)
            # def addFacet(servant, id, facet)
            # def addWithUUID(servant)
            # def addFacetWithUUID(servant, facet)
            # def remove(id)
            # def removeFacet(id, facet)
            # def removeAllFacets(id)
            # def find(id)
            # def findFacet(id, facet)
            # def findAllFacets(id)
            # def findByProxy(proxy)
            # def addServantLocator(locator, category)
            # def findServantLocator(category)
            # def createProxy(id)
            # def createDirectProxy(id)
            # def createIndirectProxy(id)
            # def createReverseProxy(id)
            # def setLocator(loc)

            def inspect
                ::Ice::__stringify(self, T_ObjectAdapter)
            end
        end

        if not defined?(::Ice::T_ObjectAdapter)
            T_ObjectAdapter = ::Ice::__declareClass('::Ice::ObjectAdapter')
        end

        T_ObjectAdapter.defineClass(nil, true, nil, [], [])
        ObjectAdapter_mixin::ICE_TYPE = T_ObjectAdapter
    end
end
