# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Connection.ice'

require 'Ice'
require 'Ice/ObjectAdapterF.rb'
require 'Ice/Identity.rb'

module Ice

    if not defined?(::Ice::Connection_mixin)
        module Connection_mixin

            #
            # Operation signatures.
            #
            # def close(force)
            # def createProxy(id)
            # def setAdapter(adapter)
            # def getAdapter()
            # def flushBatchRequests()
            # def type()
            # def timeout()
            # def toString()

            def inspect
                ::Ice::__stringify(self, T_Connection)
            end
        end

        if not defined?(::Ice::T_Connection)
            T_Connection = ::Ice::__declareClass('::Ice::Connection')
        end

        T_Connection.defineClass(nil, true, nil, [], [])
        Connection_mixin::ICE_TYPE = T_Connection
    end
end
