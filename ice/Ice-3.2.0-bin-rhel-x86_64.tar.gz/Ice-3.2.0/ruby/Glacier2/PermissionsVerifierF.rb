# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `PermissionsVerifierF.ice'

require 'Ice'

module Glacier2

    if not defined?(::Glacier2::T_PermissionsVerifier)
        T_PermissionsVerifier = ::Ice::__declareClass('::Glacier2::PermissionsVerifier')
        T_PermissionsVerifierPrx = ::Ice::__declareProxy('::Glacier2::PermissionsVerifier')
    end

    if not defined?(::Glacier2::T_SSLPermissionsVerifier)
        T_SSLPermissionsVerifier = ::Ice::__declareClass('::Glacier2::SSLPermissionsVerifier')
        T_SSLPermissionsVerifierPrx = ::Ice::__declareProxy('::Glacier2::SSLPermissionsVerifier')
    end
end
