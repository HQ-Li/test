# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Session.ice'

require 'Ice'
require 'Ice/BuiltinSequences.rb'
require 'Ice/Identity.rb'
require 'Glacier2/SSLInfo.rb'

module Glacier2

    if not defined?(::Glacier2::CannotCreateSessionException)
        class CannotCreateSessionException < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'Glacier2::CannotCreateSessionException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_CannotCreateSessionException = ::Ice::__defineException('::Glacier2::CannotCreateSessionException', CannotCreateSessionException, nil, [["reason", ::Ice::T_string]])
        CannotCreateSessionException::ICE_TYPE = T_CannotCreateSessionException
    end

    if not defined?(::Glacier2::Session_mixin)
        module Session_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::Session', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Glacier2::Session'
            end

            #
            # Operation signatures.
            #
            # def destroy(current=nil)

            def inspect
                ::Ice::__stringify(self, T_Session)
            end
        end
        module SessionPrx_mixin

            def destroy(_ctx=nil)
                Session_mixin::OP_destroy.invoke(self, [], _ctx)
            end
        end
        class SessionPrx < ::Ice::ObjectPrx
            include SessionPrx_mixin

            def SessionPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::Session', facetOrCtx, _ctx)
            end

            def SessionPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_Session)
            T_Session = ::Ice::__declareClass('::Glacier2::Session')
            T_SessionPrx = ::Ice::__declareProxy('::Glacier2::Session')
        end

        T_Session.defineClass(nil, true, nil, [], [])
        Session_mixin::ICE_TYPE = T_Session

        T_SessionPrx.defineProxy(SessionPrx, T_Session)
        SessionPrx::ICE_TYPE = T_SessionPrx

        Session_mixin::OP_destroy = ::Ice::__defineOperation('destroy', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [])
    end

    if not defined?(::Glacier2::StringSet_mixin)
        module StringSet_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::StringSet', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Glacier2::StringSet'
            end

            #
            # Operation signatures.
            #
            # def add(additions, current=nil)
            # def remove(deletions, current=nil)
            # def get(current=nil)

            def inspect
                ::Ice::__stringify(self, T_StringSet)
            end
        end
        module StringSetPrx_mixin

            def add(additions, _ctx=nil)
                StringSet_mixin::OP_add.invoke(self, [additions], _ctx)
            end

            def remove(deletions, _ctx=nil)
                StringSet_mixin::OP_remove.invoke(self, [deletions], _ctx)
            end

            def get(_ctx=nil)
                StringSet_mixin::OP_get.invoke(self, [], _ctx)
            end
        end
        class StringSetPrx < ::Ice::ObjectPrx
            include StringSetPrx_mixin

            def StringSetPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::StringSet', facetOrCtx, _ctx)
            end

            def StringSetPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_StringSet)
            T_StringSet = ::Ice::__declareClass('::Glacier2::StringSet')
            T_StringSetPrx = ::Ice::__declareProxy('::Glacier2::StringSet')
        end

        T_StringSet.defineClass(nil, true, nil, [], [])
        StringSet_mixin::ICE_TYPE = T_StringSet

        T_StringSetPrx.defineProxy(StringSetPrx, T_StringSet)
        StringSetPrx::ICE_TYPE = T_StringSetPrx

        StringSet_mixin::OP_add = ::Ice::__defineOperation('add', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_StringSeq], [], nil, [])
        StringSet_mixin::OP_remove = ::Ice::__defineOperation('remove', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_StringSeq], [], nil, [])
        StringSet_mixin::OP_get = ::Ice::__defineOperation('get', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [], [], ::Ice::T_StringSeq, [])
    end

    if not defined?(::Glacier2::IdentitySet_mixin)
        module IdentitySet_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::IdentitySet', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Glacier2::IdentitySet'
            end

            #
            # Operation signatures.
            #
            # def add(additions, current=nil)
            # def remove(deletions, current=nil)
            # def get(current=nil)

            def inspect
                ::Ice::__stringify(self, T_IdentitySet)
            end
        end
        module IdentitySetPrx_mixin

            def add(additions, _ctx=nil)
                IdentitySet_mixin::OP_add.invoke(self, [additions], _ctx)
            end

            def remove(deletions, _ctx=nil)
                IdentitySet_mixin::OP_remove.invoke(self, [deletions], _ctx)
            end

            def get(_ctx=nil)
                IdentitySet_mixin::OP_get.invoke(self, [], _ctx)
            end
        end
        class IdentitySetPrx < ::Ice::ObjectPrx
            include IdentitySetPrx_mixin

            def IdentitySetPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::IdentitySet', facetOrCtx, _ctx)
            end

            def IdentitySetPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_IdentitySet)
            T_IdentitySet = ::Ice::__declareClass('::Glacier2::IdentitySet')
            T_IdentitySetPrx = ::Ice::__declareProxy('::Glacier2::IdentitySet')
        end

        T_IdentitySet.defineClass(nil, true, nil, [], [])
        IdentitySet_mixin::ICE_TYPE = T_IdentitySet

        T_IdentitySetPrx.defineProxy(IdentitySetPrx, T_IdentitySet)
        IdentitySetPrx::ICE_TYPE = T_IdentitySetPrx

        IdentitySet_mixin::OP_add = ::Ice::__defineOperation('add', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_IdentitySeq], [], nil, [])
        IdentitySet_mixin::OP_remove = ::Ice::__defineOperation('remove', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [::Ice::T_IdentitySeq], [], nil, [])
        IdentitySet_mixin::OP_get = ::Ice::__defineOperation('get', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [], [], ::Ice::T_IdentitySeq, [])
    end

    if not defined?(::Glacier2::SessionControl_mixin)
        module SessionControl_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::SessionControl', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Glacier2::SessionControl'
            end

            #
            # Operation signatures.
            #
            # def categories(current=nil)
            # def adapterIds(current=nil)
            # def identities(current=nil)
            # def getSessionTimeout(current=nil)
            # def destroy(current=nil)

            def inspect
                ::Ice::__stringify(self, T_SessionControl)
            end
        end
        module SessionControlPrx_mixin

            def categories(_ctx=nil)
                SessionControl_mixin::OP_categories.invoke(self, [], _ctx)
            end

            def adapterIds(_ctx=nil)
                SessionControl_mixin::OP_adapterIds.invoke(self, [], _ctx)
            end

            def identities(_ctx=nil)
                SessionControl_mixin::OP_identities.invoke(self, [], _ctx)
            end

            def getSessionTimeout(_ctx=nil)
                SessionControl_mixin::OP_getSessionTimeout.invoke(self, [], _ctx)
            end

            def destroy(_ctx=nil)
                SessionControl_mixin::OP_destroy.invoke(self, [], _ctx)
            end

            def destroy_async(_cb, _ctx=nil)
                SessionControl_mixin::OP_destroy.invokeAsync(self, _cb, [], _ctx)
            end
        end
        class SessionControlPrx < ::Ice::ObjectPrx
            include SessionControlPrx_mixin

            def SessionControlPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::SessionControl', facetOrCtx, _ctx)
            end

            def SessionControlPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_SessionControl)
            T_SessionControl = ::Ice::__declareClass('::Glacier2::SessionControl')
            T_SessionControlPrx = ::Ice::__declareProxy('::Glacier2::SessionControl')
        end

        T_SessionControl.defineClass(nil, true, nil, [], [])
        SessionControl_mixin::ICE_TYPE = T_SessionControl

        T_SessionControlPrx.defineProxy(SessionControlPrx, T_SessionControl)
        SessionControlPrx::ICE_TYPE = T_SessionControlPrx

        SessionControl_mixin::OP_categories = ::Ice::__defineOperation('categories', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], ::Glacier2::T_StringSetPrx, [])
        SessionControl_mixin::OP_adapterIds = ::Ice::__defineOperation('adapterIds', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], ::Glacier2::T_StringSetPrx, [])
        SessionControl_mixin::OP_identities = ::Ice::__defineOperation('identities', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], ::Glacier2::T_IdentitySetPrx, [])
        SessionControl_mixin::OP_getSessionTimeout = ::Ice::__defineOperation('getSessionTimeout', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Idempotent, false, [], [], ::Ice::T_int, [])
        SessionControl_mixin::OP_destroy = ::Ice::__defineOperation('destroy', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [])
    end

    if not defined?(::Glacier2::SessionManager_mixin)
        module SessionManager_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::SessionManager', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Glacier2::SessionManager'
            end

            #
            # Operation signatures.
            #
            # def create(userId, control, current=nil)

            def inspect
                ::Ice::__stringify(self, T_SessionManager)
            end
        end
        module SessionManagerPrx_mixin

            def create(userId, control, _ctx=nil)
                SessionManager_mixin::OP_create.invoke(self, [userId, control], _ctx)
            end
        end
        class SessionManagerPrx < ::Ice::ObjectPrx
            include SessionManagerPrx_mixin

            def SessionManagerPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::SessionManager', facetOrCtx, _ctx)
            end

            def SessionManagerPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_SessionManager)
            T_SessionManager = ::Ice::__declareClass('::Glacier2::SessionManager')
            T_SessionManagerPrx = ::Ice::__declareProxy('::Glacier2::SessionManager')
        end

        T_SessionManager.defineClass(nil, true, nil, [], [])
        SessionManager_mixin::ICE_TYPE = T_SessionManager

        T_SessionManagerPrx.defineProxy(SessionManagerPrx, T_SessionManager)
        SessionManagerPrx::ICE_TYPE = T_SessionManagerPrx

        SessionManager_mixin::OP_create = ::Ice::__defineOperation('create', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Glacier2::T_SessionControlPrx], [], ::Glacier2::T_SessionPrx, [::Glacier2::T_CannotCreateSessionException])
    end

    if not defined?(::Glacier2::SSLSessionManager_mixin)
        module SSLSessionManager_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::SSLSessionManager', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Glacier2::SSLSessionManager'
            end

            #
            # Operation signatures.
            #
            # def create(info, control, current=nil)

            def inspect
                ::Ice::__stringify(self, T_SSLSessionManager)
            end
        end
        module SSLSessionManagerPrx_mixin

            def create(info, control, _ctx=nil)
                SSLSessionManager_mixin::OP_create.invoke(self, [info, control], _ctx)
            end
        end
        class SSLSessionManagerPrx < ::Ice::ObjectPrx
            include SSLSessionManagerPrx_mixin

            def SSLSessionManagerPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::SSLSessionManager', facetOrCtx, _ctx)
            end

            def SSLSessionManagerPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_SSLSessionManager)
            T_SSLSessionManager = ::Ice::__declareClass('::Glacier2::SSLSessionManager')
            T_SSLSessionManagerPrx = ::Ice::__declareProxy('::Glacier2::SSLSessionManager')
        end

        T_SSLSessionManager.defineClass(nil, true, nil, [], [])
        SSLSessionManager_mixin::ICE_TYPE = T_SSLSessionManager

        T_SSLSessionManagerPrx.defineProxy(SSLSessionManagerPrx, T_SSLSessionManager)
        SSLSessionManagerPrx::ICE_TYPE = T_SSLSessionManagerPrx

        SSLSessionManager_mixin::OP_create = ::Ice::__defineOperation('create', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Glacier2::T_SSLInfo, ::Glacier2::T_SessionControlPrx], [], ::Glacier2::T_SessionPrx, [::Glacier2::T_CannotCreateSessionException])
    end
end
