# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `Router.ice'

require 'Ice'
require 'Ice/Router.rb'
require 'Glacier2/Session.rb'

module Glacier2

    if not defined?(::Glacier2::PermissionDeniedException)
        class PermissionDeniedException < Ice::UserException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'Glacier2::PermissionDeniedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_PermissionDeniedException = ::Ice::__defineException('::Glacier2::PermissionDeniedException', PermissionDeniedException, nil, [["reason", ::Ice::T_string]])
        PermissionDeniedException::ICE_TYPE = T_PermissionDeniedException
    end

    if not defined?(::Glacier2::SessionNotExistException)
        class SessionNotExistException < Ice::UserException
            def initialize
            end

            def to_s
                'Glacier2::SessionNotExistException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_SessionNotExistException = ::Ice::__defineException('::Glacier2::SessionNotExistException', SessionNotExistException, nil, [])
        SessionNotExistException::ICE_TYPE = T_SessionNotExistException
    end

    if not defined?(::Glacier2::Router_mixin)
        module Router_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::Router', '::Ice::Object', '::Ice::Router']
            end

            def ice_id(current=nil)
                '::Glacier2::Router'
            end

            #
            # Operation signatures.
            #
            # def getCategoryForClient(current=nil)
            # def createSession(userId, password, current=nil)
            # def createSessionFromSecureConnection(current=nil)
            # def destroySession(current=nil)
            # def getSessionTimeout(current=nil)

            def inspect
                ::Ice::__stringify(self, T_Router)
            end
        end
        module RouterPrx_mixin
            include ::Ice::RouterPrx_mixin

            def getCategoryForClient(_ctx=nil)
                Router_mixin::OP_getCategoryForClient.invoke(self, [], _ctx)
            end

            def createSession(userId, password, _ctx=nil)
                Router_mixin::OP_createSession.invoke(self, [userId, password], _ctx)
            end

            def createSessionFromSecureConnection(_ctx=nil)
                Router_mixin::OP_createSessionFromSecureConnection.invoke(self, [], _ctx)
            end

            def destroySession(_ctx=nil)
                Router_mixin::OP_destroySession.invoke(self, [], _ctx)
            end

            def getSessionTimeout(_ctx=nil)
                Router_mixin::OP_getSessionTimeout.invoke(self, [], _ctx)
            end
        end
        class RouterPrx < ::Ice::ObjectPrx
            include RouterPrx_mixin

            def RouterPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::Router', facetOrCtx, _ctx)
            end

            def RouterPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_Router)
            T_Router = ::Ice::__declareClass('::Glacier2::Router')
            T_RouterPrx = ::Ice::__declareProxy('::Glacier2::Router')
        end

        T_Router.defineClass(nil, true, nil, [::Ice::T_Router], [])
        Router_mixin::ICE_TYPE = T_Router

        T_RouterPrx.defineProxy(RouterPrx, T_Router)
        RouterPrx::ICE_TYPE = T_RouterPrx

        Router_mixin::OP_getCategoryForClient = ::Ice::__defineOperation('getCategoryForClient', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_string, [])
        Router_mixin::OP_createSession = ::Ice::__defineOperation('createSession', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string, ::Ice::T_string], [], ::Glacier2::T_SessionPrx, [::Glacier2::T_PermissionDeniedException, ::Glacier2::T_CannotCreateSessionException])
        Router_mixin::OP_createSessionFromSecureConnection = ::Ice::__defineOperation('createSessionFromSecureConnection', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], ::Glacier2::T_SessionPrx, [::Glacier2::T_PermissionDeniedException, ::Glacier2::T_CannotCreateSessionException])
        Router_mixin::OP_destroySession = ::Ice::__defineOperation('destroySession', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [::Glacier2::T_SessionNotExistException])
        Router_mixin::OP_getSessionTimeout = ::Ice::__defineOperation('getSessionTimeout', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_long, [])
    end

    if not defined?(::Glacier2::Admin_mixin)
        module Admin_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::Admin', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Glacier2::Admin'
            end

            #
            # Operation signatures.
            #
            # def shutdown(current=nil)

            def inspect
                ::Ice::__stringify(self, T_Admin)
            end
        end
        module AdminPrx_mixin

            def shutdown(_ctx=nil)
                Admin_mixin::OP_shutdown.invoke(self, [], _ctx)
            end
        end
        class AdminPrx < ::Ice::ObjectPrx
            include AdminPrx_mixin

            def AdminPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::Admin', facetOrCtx, _ctx)
            end

            def AdminPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_Admin)
            T_Admin = ::Ice::__declareClass('::Glacier2::Admin')
            T_AdminPrx = ::Ice::__declareProxy('::Glacier2::Admin')
        end

        T_Admin.defineClass(nil, true, nil, [], [])
        Admin_mixin::ICE_TYPE = T_Admin

        T_AdminPrx.defineProxy(AdminPrx, T_Admin)
        AdminPrx::ICE_TYPE = T_AdminPrx

        Admin_mixin::OP_shutdown = ::Ice::__defineOperation('shutdown', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [])
    end
end
