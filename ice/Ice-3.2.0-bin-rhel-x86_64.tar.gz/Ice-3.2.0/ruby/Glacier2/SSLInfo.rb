# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `SSLInfo.ice'

require 'Ice'
require 'Ice/BuiltinSequences.rb'

module Glacier2

    if not defined?(::Glacier2::SSLInfo)
        class SSLInfo
            def initialize(remoteHost='', remotePort=0, localHost='', localPort=0, cipher='', certs=nil)
                @remoteHost = remoteHost
                @remotePort = remotePort
                @localHost = localHost
                @localPort = localPort
                @cipher = cipher
                @certs = certs
            end

            def hash
                _h = 0
                _h = 5 * _h + @remoteHost.hash
                _h = 5 * _h + @remotePort.hash
                _h = 5 * _h + @localHost.hash
                _h = 5 * _h + @localPort.hash
                _h = 5 * _h + @cipher.hash
                _h = 5 * _h + @certs.hash
                _h % 0x7fffffff
            end

            def ==(other)
                return false if
                    @remoteHost != other.remoteHost or
                    @remotePort != other.remotePort or
                    @localHost != other.localHost or
                    @localPort != other.localPort or
                    @cipher != other.cipher or
                    @certs != other.certs
                true
            end

            def inspect
                ::Ice::__stringify(self, T_SSLInfo)
            end

            attr_accessor :remoteHost, :remotePort, :localHost, :localPort, :cipher, :certs
        end

        T_SSLInfo = ::Ice::__defineStruct('::Glacier2::SSLInfo', SSLInfo, [
            ["remoteHost", ::Ice::T_string],
            ["remotePort", ::Ice::T_int],
            ["localHost", ::Ice::T_string],
            ["localPort", ::Ice::T_int],
            ["cipher", ::Ice::T_string],
            ["certs", ::Ice::T_StringSeq]
        ])
    end
end
