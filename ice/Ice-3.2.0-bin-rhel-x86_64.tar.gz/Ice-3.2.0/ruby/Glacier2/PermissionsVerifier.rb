# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `PermissionsVerifier.ice'

require 'Ice'
require 'Glacier2/SSLInfo.rb'

module Glacier2

    if not defined?(::Glacier2::PermissionsVerifier_mixin)
        module PermissionsVerifier_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::PermissionsVerifier', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Glacier2::PermissionsVerifier'
            end

            #
            # Operation signatures.
            #
            # def checkPermissions(userId, password, current=nil)

            def inspect
                ::Ice::__stringify(self, T_PermissionsVerifier)
            end
        end
        module PermissionsVerifierPrx_mixin

            def checkPermissions(userId, password, _ctx=nil)
                PermissionsVerifier_mixin::OP_checkPermissions.invoke(self, [userId, password], _ctx)
            end
        end
        class PermissionsVerifierPrx < ::Ice::ObjectPrx
            include PermissionsVerifierPrx_mixin

            def PermissionsVerifierPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::PermissionsVerifier', facetOrCtx, _ctx)
            end

            def PermissionsVerifierPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_PermissionsVerifier)
            T_PermissionsVerifier = ::Ice::__declareClass('::Glacier2::PermissionsVerifier')
            T_PermissionsVerifierPrx = ::Ice::__declareProxy('::Glacier2::PermissionsVerifier')
        end

        T_PermissionsVerifier.defineClass(nil, true, nil, [], [])
        PermissionsVerifier_mixin::ICE_TYPE = T_PermissionsVerifier

        T_PermissionsVerifierPrx.defineProxy(PermissionsVerifierPrx, T_PermissionsVerifier)
        PermissionsVerifierPrx::ICE_TYPE = T_PermissionsVerifierPrx

        PermissionsVerifier_mixin::OP_checkPermissions = ::Ice::__defineOperation('checkPermissions', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Ice::T_string, ::Ice::T_string], [::Ice::T_string], ::Ice::T_bool, [])
    end

    if not defined?(::Glacier2::SSLPermissionsVerifier_mixin)
        module SSLPermissionsVerifier_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Glacier2::SSLPermissionsVerifier', '::Ice::Object']
            end

            def ice_id(current=nil)
                '::Glacier2::SSLPermissionsVerifier'
            end

            #
            # Operation signatures.
            #
            # def authorize(info, current=nil)

            def inspect
                ::Ice::__stringify(self, T_SSLPermissionsVerifier)
            end
        end
        module SSLPermissionsVerifierPrx_mixin

            def authorize(info, _ctx=nil)
                SSLPermissionsVerifier_mixin::OP_authorize.invoke(self, [info], _ctx)
            end
        end
        class SSLPermissionsVerifierPrx < ::Ice::ObjectPrx
            include SSLPermissionsVerifierPrx_mixin

            def SSLPermissionsVerifierPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::Glacier2::SSLPermissionsVerifier', facetOrCtx, _ctx)
            end

            def SSLPermissionsVerifierPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::Glacier2::T_SSLPermissionsVerifier)
            T_SSLPermissionsVerifier = ::Ice::__declareClass('::Glacier2::SSLPermissionsVerifier')
            T_SSLPermissionsVerifierPrx = ::Ice::__declareProxy('::Glacier2::SSLPermissionsVerifier')
        end

        T_SSLPermissionsVerifier.defineClass(nil, true, nil, [], [])
        SSLPermissionsVerifier_mixin::ICE_TYPE = T_SSLPermissionsVerifier

        T_SSLPermissionsVerifierPrx.defineProxy(SSLPermissionsVerifierPrx, T_SSLPermissionsVerifier)
        SSLPermissionsVerifierPrx::ICE_TYPE = T_SSLPermissionsVerifierPrx

        SSLPermissionsVerifier_mixin::OP_authorize = ::Ice::__defineOperation('authorize', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [::Glacier2::T_SSLInfo], [::Ice::T_string], ::Ice::T_bool, [])
    end
end
