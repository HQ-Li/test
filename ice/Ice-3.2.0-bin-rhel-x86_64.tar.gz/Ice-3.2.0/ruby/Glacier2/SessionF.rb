# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `SessionF.ice'

require 'Ice'

module Glacier2

    if not defined?(::Glacier2::T_Session)
        T_Session = ::Ice::__declareClass('::Glacier2::Session')
        T_SessionPrx = ::Ice::__declareProxy('::Glacier2::Session')
    end

    if not defined?(::Glacier2::T_SessionManager)
        T_SessionManager = ::Ice::__declareClass('::Glacier2::SessionManager')
        T_SessionManagerPrx = ::Ice::__declareProxy('::Glacier2::SessionManager')
    end

    if not defined?(::Glacier2::T_SSLSessionManager)
        T_SSLSessionManager = ::Ice::__declareClass('::Glacier2::SSLSessionManager')
        T_SSLSessionManagerPrx = ::Ice::__declareProxy('::Glacier2::SSLSessionManager')
    end
end
