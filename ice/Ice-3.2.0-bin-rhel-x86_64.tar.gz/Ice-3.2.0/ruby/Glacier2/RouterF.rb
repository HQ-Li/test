# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `RouterF.ice'

require 'Ice'

module Glacier2

    if not defined?(::Glacier2::T_Router)
        T_Router = ::Ice::__declareClass('::Glacier2::Router')
        T_RouterPrx = ::Ice::__declareProxy('::Glacier2::Router')
    end
end
