# **********************************************************************
#
# Copyright (c) 2003-2007 ZeroC, Inc. All rights reserved.
#
# This copy of Ice is licensed to you under the terms described in the
# ICE_LICENSE file included in this distribution.
#
# **********************************************************************

# Ice version 3.2.0
# Generated from file `IceBox.ice'

require 'Ice'
require 'Ice/BuiltinSequences.rb'
require 'Ice/CommunicatorF.rb'
require 'Ice/PropertiesF.rb'
require 'Ice/SliceChecksumDict.rb'

module IceBox

    if not defined?(::IceBox::FailureException)
        class FailureException < Ice::LocalException
            def initialize(reason='')
                @reason = reason
            end

            def to_s
                'IceBox::FailureException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end

            attr_accessor :reason
        end

        T_FailureException = ::Ice::__defineException('::IceBox::FailureException', FailureException, nil, [["reason", ::Ice::T_string]])
        FailureException::ICE_TYPE = T_FailureException
    end

    if not defined?(::IceBox::AlreadyStartedException)
        class AlreadyStartedException < Ice::UserException
            def initialize
            end

            def to_s
                'IceBox::AlreadyStartedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_AlreadyStartedException = ::Ice::__defineException('::IceBox::AlreadyStartedException', AlreadyStartedException, nil, [])
        AlreadyStartedException::ICE_TYPE = T_AlreadyStartedException
    end

    if not defined?(::IceBox::AlreadyStoppedException)
        class AlreadyStoppedException < Ice::UserException
            def initialize
            end

            def to_s
                'IceBox::AlreadyStoppedException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_AlreadyStoppedException = ::Ice::__defineException('::IceBox::AlreadyStoppedException', AlreadyStoppedException, nil, [])
        AlreadyStoppedException::ICE_TYPE = T_AlreadyStoppedException
    end

    if not defined?(::IceBox::NoSuchServiceException)
        class NoSuchServiceException < Ice::UserException
            def initialize
            end

            def to_s
                'IceBox::NoSuchServiceException'
            end

            def inspect
                return ::Ice::__stringifyException(self)
            end
        end

        T_NoSuchServiceException = ::Ice::__defineException('::IceBox::NoSuchServiceException', NoSuchServiceException, nil, [])
        NoSuchServiceException::ICE_TYPE = T_NoSuchServiceException
    end

    if not defined?(::IceBox::Service_mixin)
        module Service_mixin

            #
            # Operation signatures.
            #
            # def start(name, communicator, args)
            # def stop()

            def inspect
                ::Ice::__stringify(self, T_Service)
            end
        end

        if not defined?(::IceBox::T_Service)
            T_Service = ::Ice::__declareClass('::IceBox::Service')
        end

        T_Service.defineClass(nil, true, nil, [], [])
        Service_mixin::ICE_TYPE = T_Service
    end

    if not defined?(::IceBox::ServiceManager_mixin)
        module ServiceManager_mixin
            include ::Ice::Object_mixin

            def ice_ids(current=nil)
                ['::Ice::Object', '::IceBox::ServiceManager']
            end

            def ice_id(current=nil)
                '::IceBox::ServiceManager'
            end

            #
            # Operation signatures.
            #
            # def getSliceChecksums(current=nil)
            # def startService(service, current=nil)
            # def stopService(service, current=nil)
            # def shutdown(current=nil)

            def inspect
                ::Ice::__stringify(self, T_ServiceManager)
            end
        end
        module ServiceManagerPrx_mixin

            def getSliceChecksums(_ctx=nil)
                ServiceManager_mixin::OP_getSliceChecksums.invoke(self, [], _ctx)
            end

            def startService(service, _ctx=nil)
                ServiceManager_mixin::OP_startService.invoke(self, [service], _ctx)
            end

            def stopService(service, _ctx=nil)
                ServiceManager_mixin::OP_stopService.invoke(self, [service], _ctx)
            end

            def shutdown(_ctx=nil)
                ServiceManager_mixin::OP_shutdown.invoke(self, [], _ctx)
            end
        end
        class ServiceManagerPrx < ::Ice::ObjectPrx
            include ServiceManagerPrx_mixin

            def ServiceManagerPrx.checkedCast(proxy, facetOrCtx=nil, _ctx=nil)
                ice_checkedCast(proxy, '::IceBox::ServiceManager', facetOrCtx, _ctx)
            end

            def ServiceManagerPrx.uncheckedCast(proxy, facet='')
                ice_uncheckedCast(proxy, facet)
            end
        end

        if not defined?(::IceBox::T_ServiceManager)
            T_ServiceManager = ::Ice::__declareClass('::IceBox::ServiceManager')
            T_ServiceManagerPrx = ::Ice::__declareProxy('::IceBox::ServiceManager')
        end

        T_ServiceManager.defineClass(nil, true, nil, [], [])
        ServiceManager_mixin::ICE_TYPE = T_ServiceManager

        T_ServiceManagerPrx.defineProxy(ServiceManagerPrx, T_ServiceManager)
        ServiceManagerPrx::ICE_TYPE = T_ServiceManagerPrx

        ServiceManager_mixin::OP_getSliceChecksums = ::Ice::__defineOperation('getSliceChecksums', ::Ice::OperationMode::Idempotent, ::Ice::OperationMode::Nonmutating, false, [], [], ::Ice::T_SliceChecksumDict, [])
        ServiceManager_mixin::OP_startService = ::Ice::__defineOperation('startService', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [::IceBox::T_AlreadyStartedException, ::IceBox::T_NoSuchServiceException])
        ServiceManager_mixin::OP_stopService = ::Ice::__defineOperation('stopService', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [::Ice::T_string], [], nil, [::IceBox::T_AlreadyStoppedException, ::IceBox::T_NoSuchServiceException])
        ServiceManager_mixin::OP_shutdown = ::Ice::__defineOperation('shutdown', ::Ice::OperationMode::Normal, ::Ice::OperationMode::Normal, false, [], [], nil, [])
    end
end
